#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"

# Load optional user overrides for env vars
ENV_FILE="${HOME}/.bevforge_env"
if [ -f "$ENV_FILE" ]; then
  set -a
  # shellcheck disable=SC1090
  . "$ENV_FILE"
  set +a
fi

# Defaults (overridable)
export LOG_DIR="${LOG_DIR:-backend/logs}"
export LOG_FILE="${LOG_FILE:-app.log}"
export LOG_MAX_MB="${LOG_MAX_MB:-5}"
export LOG_BACKUPS="${LOG_BACKUPS:-5}"
export AUTO_INTERVAL_SEC="${AUTO_INTERVAL_SEC:-2.0}"

python3 -V

# venv
if [ ! -d ".venv" ]; then
  python3 -m venv .venv
fi
. .venv/bin/activate

pip -q install --upgrade pip
pip -q install -r requirements.txt

# ensure runtime dirs
mkdir -p backend/logs backend/data

echo "Starting BevForge OS on :8080"
exec uvicorn bevforge.main:app --app-dir backend --host 0.0.0.0 --port 8080 --reload
