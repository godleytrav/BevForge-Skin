from __future__ import annotations
from typing import Iterator
from sqlmodel import SQLModel, create_engine, Session
from pathlib import Path

DB_PATH = Path("backend/data/bevforge.db")
DB_PATH.parent.mkdir(parents=True, exist_ok=True)

engine = create_engine(f"sqlite:///{DB_PATH}", echo=False, connect_args={"check_same_thread": False})

def ensure_schema() -> None:
    from . import models  # noqa: F401
    SQLModel.metadata.create_all(engine)

    with engine.begin() as conn:
        existing = {
            row[1]
            for row in conn.exec_driver_sql("PRAGMA table_info(widget)")
        }
        if "published_at" not in existing:
            conn.exec_driver_sql("ALTER TABLE widget ADD COLUMN published_at TEXT")

def get_session() -> Iterator[Session]:
    """FastAPI dependency (yields a session)."""
    with Session(engine) as session:
        yield session

def session_factory() -> Session:
    """Callable for background tasks (returns a Session)."""
    return Session(engine)
