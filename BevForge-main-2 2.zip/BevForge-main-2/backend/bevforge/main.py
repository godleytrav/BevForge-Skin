from __future__ import annotations

import asyncio
import contextlib
import logging
import os
from logging.handlers import RotatingFileHandler
from pathlib import Path

from fastapi import FastAPI
from fastapi.responses import RedirectResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from sqlmodel import Session as SQLSession, select

from .addons.loader import scan_and_mount
from .db import ensure_schema, engine
from .models import Widget
from .routers import (
    admin,
    automations,
    dash,
    devices,
    ferments,
    media,
    sensors,
    widgets,
)
from .services.tilt_scanner import TiltScannerService
from .services.pumps import pump_manager
from .utils.logging_setup import setup_logging

LOG_DIR = Path("backend/logs")
LOG_DIR.mkdir(parents=True, exist_ok=True)
LOG_FILE = LOG_DIR / "app.log"

_rot = RotatingFileHandler(LOG_FILE, maxBytes=10_000_000, backupCount=3)
_rot.setLevel(logging.INFO)
_rot.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(name)s: %(message)s"))

root = logging.getLogger()
if not any(isinstance(h, RotatingFileHandler) for h in root.handlers):
    root.addHandler(_rot)

log = logging.getLogger("bevforge.main")

app = FastAPI(title="BevForge OS")
tilt_scanner_service = TiltScannerService(app)
app.state.tilt_ble_runtime_override = False


@app.get("/healthz", include_in_schema=False)
def healthz() -> dict[str, bool]:
    return {"ok": True}

# Configure rotating logs
try:
    _logfile = setup_logging()
    logging.getLogger("bevforge.main").info("Logging to %s", _logfile)
except Exception as e:
    logging.getLogger("bevforge.main").warning("Logging setup failed: %s", e)


# Attach templates and static once at import time
TEMPLATES_DIR = os.path.join(os.path.dirname(__file__), "..", "templates")
STATIC_DIR    = os.path.join(os.path.dirname(__file__), "..", "static")

addons_root = Path(__file__).parent.parent / "addons"
try:
    mounted = scan_and_mount(app, addons_root)
    log.info("Add-ons mounted: %s", [m["slug"] for m in mounted])
except Exception as e:
    log.error("Add-ons scan failed: %s", e)

    
app.state.templates = Jinja2Templates(directory=TEMPLATES_DIR)
app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")

# Routers
_ROUTERS = (
    admin.router,
    automations.router,
    dash.router,
    dash.dashboard_router,
    devices.router,
    ferments.router,
    media.router,
    sensors.router,
    widgets.router,
    widgets.tools_router,
)

for _router in _ROUTERS:
    app.include_router(_router)




@app.on_event("startup")
async def _startup() -> None:
    ensure_schema()

    if not hasattr(app.state, "session_lock"):
        app.state.session_lock = asyncio.Lock()

    uploads_dir = Path(STATIC_DIR) / "uploads"
    uploads_dir.mkdir(parents=True, exist_ok=True)

    if os.getenv("PUMP_ALL_OFF_ON_START", "").strip() == "1":
        try:
            with SQLSession(engine) as session:
                pumps = session.exec(select(Widget).where(Widget.kind == "pump")).all()
                for w in pumps:
                    pump_manager.set_pump(w.id, False)
                log.info("All-Off on startup executed for %d pump(s).", len(pumps))
        except Exception as exc:
            log.error("All-Off on startup failed: %s", exc)

    interval_env = os.getenv("AUTO_INTERVAL_SEC", "2.0")
    try:
        interval = float(interval_env)
    except ValueError:
        log.warning("Invalid AUTO_INTERVAL_SEC=%r; falling back to 2.0", interval_env)
        interval = 2.0

    app.state.auto_last_tick = None
    app.state.auto_task = asyncio.create_task(
        automations.eval_loop(app, interval=interval)
    )
    log.info("Automation eval loop started (interval=%s sec).", interval)

    tilt_env = os.getenv("TILT_BLE_ENABLE", "").strip()
    app.state.tilt_ble_env_enabled = tilt_env == "1"
    app.state.tilt_ble_runtime_override = False
    scanner: TiltScannerService = getattr(app.state, "tilt_scanner", tilt_scanner_service)
    if tilt_env == "1":
        try:
            await scanner.start()
            log.info("Tilt BLE scanner enabled via TILT_BLE_ENABLE=1.")
        except Exception as exc:  # pragma: no cover - defensive logging for deployment
            log.error("Failed to start Tilt BLE scanner: %s", exc)
            scanner.set_last_error(f"startup failure: {exc}")
    else:
        scanner.set_last_error(None)
        scanner.status.clear()
        await scanner.stop()


@app.on_event("shutdown")
async def _shutdown() -> None:
    task: asyncio.Task | None = getattr(app.state, "auto_task", None)
    if task:
        task.cancel()
        with contextlib.suppress(asyncio.CancelledError, Exception):
            await task
        app.state.auto_task = None
        log.info("Automation eval loop stopped.")

    scanner: TiltScannerService | None = getattr(app.state, "tilt_scanner", None)
    if scanner:
        await scanner.stop()
        log.info("Tilt BLE scanner stopped.")

__all__ = ["app"]

@app.get("/tools/devices")
def _tools_devices_alias():
    # Alias to the devices UI page
    return RedirectResponse(url="/devices/ui", status_code=307)


@app.get("/tools/sensors")
def _tools_sensors_alias():
    # Alias to the sensors UI page
    return RedirectResponse(url="/sensors/ui", status_code=307)
