from __future__ import annotations
from fastapi import APIRouter, Request
from fastapi.responses import HTMLResponse

router = APIRouter(prefix="/addons/ferment-tracker", tags=["addons"])

@router.get("", response_class=HTMLResponse)
def home(request: Request):
    # Keep it very simple for v0.1: just prove the add-on mounts & renders.
    return request.app.state.templates.TemplateResponse(
        "ferment_tracker_home.html",
        {"request": request, "title": "Ferment Tracker (Add-on)"},
    )

def mount(app, templates):
    """
    Called by the add-on loader. `templates` is already attached to app.state.
    We just include our router.
    """
    app.include_router(router)
