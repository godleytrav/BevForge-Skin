from __future__ import annotations
import json, importlib.util
from pathlib import Path
from fastapi import FastAPI

def _import_module_from_file(mod_name: str, file_path: Path):
    spec = importlib.util.spec_from_file_location(mod_name, str(file_path))
    if not spec or not spec.loader:
        raise RuntimeError(f"Cannot import {file_path}")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)  # type: ignore
    return mod

def scan_and_mount(app: FastAPI, addons_root: Path) -> list[dict]:
    """
    Looks for backend/addons/*/manifest.json.
    If router.py present, import and mount its 'router' (FastAPI APIRouter).
    Adds menu entries to app.state.tools_menu (list of dicts).
    """
    tools_menu = getattr(app.state, "tools_menu", [])
    mounted = []
    for mf in sorted(addons_root.glob("*/manifest.json")):
        try:
            data = json.loads(mf.read_text())
            name = data.get("name") or mf.parent.name
            slug = data.get("slug") or mf.parent.name
            menu  = data.get("menu", [])
            router_py = mf.parent / "router.py"
            if router_py.exists():
                mod = _import_module_from_file(f"addon_{slug}", router_py)
                router = getattr(mod, "router", None)
                if router is not None:
                    app.include_router(router)
            # Add menu entries to Tools
            for m in menu:
                # m: {"label": "...", "href": "/addons/ferment", "section":"Add-ons"}
                tools_menu.append({"label": m.get("label", name),
                                   "href": m.get("href", "/"),
                                   "section": m.get("section", "Add-ons")})
            mounted.append({"slug": slug, "name": name})
        except Exception as e:
            # don't crash app if an addon is malformed
            app.logger.error(f"Addon '{mf.parent.name}' failed: {e}")
    app.state.tools_menu = tools_menu
    return mounted
