# SENTINEL: DEVICES-ROUTER
from __future__ import annotations

import logging
import time

from fastapi import APIRouter, Body, Depends, HTTPException, Query, Request
from fastapi.responses import HTMLResponse, JSONResponse
from sqlmodel import select

from ..db import Session, get_session
from ..models import Widget
from ..services.pumps import USB_RELAY_ACCESS_ERROR, pump_manager
from ..utils.usbrelay import format_relay_label, normalize_board_id, parse_relay_label

router = APIRouter(prefix="/devices", tags=["devices"])
logger = logging.getLogger("bevforge.devices")


def _coerce_value(value: object) -> object:
    if isinstance(value, str):
        text = value.strip()
        lowered = text.lower()
        if lowered in {"null", "none"}:
            return None
        if lowered == "true":
            return True
        if lowered == "false":
            return False
        if text == "":
            return ""
        try:
            return int(text)
        except (TypeError, ValueError):
            pass
        try:
            return float(text)
        except (TypeError, ValueError):
            return value
    return value


async def _read_payload(request: Request) -> dict[str, object]:
    content_type = request.headers.get("content-type", "")
    if "application/json" in content_type:
        try:
            data = await request.json()
            if isinstance(data, dict):
                return data
        except Exception:
            pass
    form = await request.form()
    payload: dict[str, object] = {}
    for key, value in form.multi_items():
        payload[key] = _coerce_value(value)
    if not payload:
        return {}
    return payload


def _relay_label_from_payload(data: dict[str, object]) -> str | None:
    label = str(data.get("relay_label") or "").strip()
    if label:
        return label
    board = str(data.get("board") or "").strip()
    channel = data.get("channel")
    try:
        channel_int = int(channel) if channel is not None else None
    except (TypeError, ValueError):
        channel_int = None
    if board and channel_int is not None:
        return f"{board}_{channel_int}"
    return None


def _relay_bcm_from_payload(data: dict[str, object]) -> int | None:
    value = data.get("bcm")
    try:
        return int(value) if value is not None else None
    except (TypeError, ValueError):
        return None


def _relay_channel_from_payload(data: dict[str, object]) -> int | None:
    value = data.get("channel")
    try:
        channel = int(value) if value is not None else None
    except (TypeError, ValueError):
        return None
    if channel is None:
        return None
    if 1 <= channel <= 8:
        return channel
    return None


def _relay_board_from_payload(data: dict[str, object]) -> str | None:
    raw = data.get("board")
    if raw in (None, ""):
        return None
    return normalize_board_id(str(raw))


def _usb_driver() -> object | None:
    driver = getattr(pump_manager, "driver", None)
    if driver and hasattr(driver, "set_by_label"):
        return driver
    sub = getattr(driver, "usb", None)
    if sub and hasattr(sub, "set_by_label"):
        return sub
    return None


def _derive_usb_label(
    payload: dict[str, object],
    driver: object,
) -> tuple[str | None, str | None, int | None, str | None]:
    raw_label = _relay_label_from_payload(payload)
    board_hint = _relay_board_from_payload(payload)
    normalized_board = normalize_board_id(board_hint)
    channel_hint = _relay_channel_from_payload(payload)

    board_for_resolution = normalized_board
    if not board_for_resolution:
        default_board = getattr(driver, "default_board", None)
        board_for_resolution = default_board() if callable(default_board) else default_board
        board_for_resolution = normalize_board_id(board_for_resolution)

    resolved_label: str | None = None
    resolver = getattr(driver, "resolve_label", None)
    try:
        if callable(resolver):
            resolved_label = resolver(raw_label, board_id=board_for_resolution, channel=channel_hint)
            if not resolved_label and not raw_label and channel_hint is not None:
                resolved_label = resolver(None, board_id=board_for_resolution, channel=channel_hint)
        else:
            candidate = raw_label
            if not candidate and board_for_resolution and channel_hint is not None:
                try:
                    candidate = format_relay_label(board_for_resolution, channel_hint)
                except ValueError:
                    candidate = None
            if isinstance(candidate, str):
                stripped = candidate.strip()
                resolved_label = stripped.upper() if stripped else None
            else:
                resolved_label = None
    except Exception:
        resolved_label = None

    return resolved_label, board_for_resolution, channel_hint, raw_label


def _method_for_driver(driver: object, candidate: str | None = None) -> str:
    if isinstance(candidate, str) and candidate:
        return candidate
    preferred = getattr(driver, "preferred_method", None)
    if callable(preferred):
        try:
            value = preferred()
            if isinstance(value, str) and value:
                return value
        except Exception:
            pass
    last_method = getattr(driver, "last_method", None)
    if isinstance(last_method, str) and last_method:
        return last_method
    setting = getattr(driver, "method_setting", None)
    if isinstance(setting, str) and setting:
        if setting == "auto":
            if isinstance(last_method, str) and last_method:
                return last_method
            return "hidraw"
        return setting
    return "hidraw"


def _apply_usb_relay_action(
    payload: dict[str, object],
    *,
    action: str,
    session: Session,
) -> dict[str, object] | JSONResponse:
    driver = _usb_driver()
    if not driver:
        return JSONResponse(status_code=503, content={"ok": False, "error": "USB relay backend unavailable"})

    resolved_label, board_hint, channel_hint, raw_label = _derive_usb_label(payload, driver)
    if not resolved_label:
        if raw_label or board_hint or channel_hint is not None:
            return JSONResponse(
                status_code=404,
                content={"ok": False, "error": "unknown relay_label or channel"},
            )
        return JSONResponse(
            status_code=400,
            content={"ok": False, "error": "relay_label or board/channel required for USB relay"},
        )

    parsed = parse_relay_label(resolved_label)
    resolved_board = parsed[0] if parsed else board_hint
    resolved_channel = parsed[1] if parsed else channel_hint

    current_state = None
    if hasattr(driver, "get_label_state"):
        try:
            current_state = driver.get_label_state(resolved_label)
            if current_state is None and isinstance(raw_label, str) and raw_label.strip():
                current_state = driver.get_label_state(raw_label.strip().upper())
        except Exception:
            current_state = None

    if action == "toggle":
        target_state = not bool(current_state)
    else:
        target_state = action == "on"

    method_used: str | None = None
    try:
        method_used = driver.set_by_label(resolved_label, target_state)
    except PermissionError as exc:
        method_used = _method_for_driver(driver, getattr(exc, "method", None))
        logger.error("USB relay permission error for %s: %s", resolved_label, exc)
        return JSONResponse(
            status_code=503,
            content={"ok": False, "error": USB_RELAY_ACCESS_ERROR, "method": method_used},
        )
    except ValueError as exc:
        logger.error("USB relay value error for %s: %s", resolved_label, exc)
        return JSONResponse(
            status_code=404,
            content={"ok": False, "error": "unknown relay_label or channel"},
        )
    except RuntimeError as exc:
        method_used = _method_for_driver(driver, getattr(exc, "method", None))
        logger.error("USB relay runtime error for %s: %s", resolved_label, exc)
        return JSONResponse(
            status_code=503,
            content={"ok": False, "error": USB_RELAY_ACCESS_ERROR, "method": method_used},
        )
    except Exception as exc:
        method_used = _method_for_driver(driver, getattr(exc, "method", None))
        logger.error("USB relay control failed for %s: %s", resolved_label, exc)
        return JSONResponse(
            status_code=503,
            content={"ok": False, "error": "USB relay control failed", "method": method_used},
        )

    final_state = None
    if hasattr(driver, "get_label_state"):
        try:
            final_state = driver.get_label_state(resolved_label)
        except Exception:
            final_state = None

    widget_id = _resolve_widget_id(payload, backend="USB", session=session)

    final_state_bool = bool(final_state if final_state is not None else target_state)
    response: dict[str, object] = {
        "ok": True,
        "state": "on" if final_state_bool else "off",
        "relay_label": resolved_label,
        "backend": "usb",
    }

    response["method"] = _method_for_driver(driver, method_used)
    if widget_id is not None:
        response["widget_id"] = widget_id
    if resolved_board:
        response["board"] = resolved_board
    if resolved_channel is not None:
        response["channel"] = resolved_channel

    logger.info(
        "USB relay action backend=USB action=%s payload=%s resolved_label=%s method=%s outcome=%s",
        action,
        payload,
        resolved_label,
        response["method"],
        response["state"],
    )

    return response


def _resolve_widget_id(
    data: dict[str, object],
    *,
    backend: str,
    session: Session,
) -> int | None:
    for key in ("pump_widget_id", "widget_id", "relay_widget_id", "device_widget_id"):
        if key in data and data[key] not in (None, ""):
            try:
                return int(data[key])
            except (TypeError, ValueError):
                continue

    slug = str(data.get("slug") or "").strip()
    if slug:
        widget = session.exec(select(Widget).where(Widget.slug == slug)).first()
        if widget:
            return widget.id

    backend_upper = backend.upper()
    if backend_upper == "USB":
        label = _relay_label_from_payload(data)
        if not label:
            return None
        for widget_id, mapped_label in pump_manager.usb_map.items():
            if mapped_label == label:
                return widget_id
    elif backend_upper == "GPIO":
        bcm = _relay_bcm_from_payload(data)
        if bcm is None:
            return None
        for widget_id, mapped_pin in pump_manager.gpio_map.items():
            if mapped_pin == bcm:
                return widget_id
    return None


def _apply_relay_action(
    payload: dict[str, object],
    *,
    action: str,
    session: Session,
) -> dict[str, object]:
    backend = str(payload.get("backend") or "").strip().upper()
    if backend not in {"USB", "GPIO"}:
        raise HTTPException(status_code=400, detail="backend must be USB or GPIO")

    if backend == "USB":
        return _apply_usb_relay_action(payload, action=action, session=session)

    widget_id = _resolve_widget_id(payload, backend=backend, session=session)
    if widget_id is None:
        label = _relay_label_from_payload(payload)
        bcm = _relay_bcm_from_payload(payload)
        detail = "Relay mapping not found"
        if backend == "USB" and label:
            detail = f"Relay label {label} is not mapped"
        elif backend == "GPIO" and bcm is not None:
            detail = f"BCM pin {bcm} is not mapped"
        raise HTTPException(status_code=404, detail=detail)

    current_state = bool(pump_manager.get_state(widget_id))
    if action == "toggle":
        target_state = not current_state
    else:
        target_state = action == "on"

    pump_manager.set_pump(widget_id, target_state)
    new_state = bool(pump_manager.get_state(widget_id))
    logger.info(
        "relay %s action %s -> %s (widget %s)",
        backend,
        action,
        "on" if new_state else "off",
        widget_id,
    )

    response: dict[str, object] = {
        "ok": True,
        "state": "on" if new_state else "off",
        "widget_id": widget_id,
        "backend": backend.lower(),
    }

    label = _relay_label_from_payload(payload)
    if label:
        response["relay_label"] = label
    bcm = _relay_bcm_from_payload(payload)
    if bcm is not None:
        response["bcm"] = bcm

    return response


async def _handle_relay(request: Request, action: str, session: Session) -> dict[str, object]:
    payload = await _read_payload(request)
    if not isinstance(payload, dict):
        raise HTTPException(status_code=400, detail="Invalid payload")
    return _apply_relay_action(payload, action=action, session=session)


@router.post("/relay/on")
async def relay_on(request: Request, session: Session = Depends(get_session)):
    return await _handle_relay(request, "on", session)


@router.post("/relay/off")
async def relay_off(request: Request, session: Session = Depends(get_session)):
    return await _handle_relay(request, "off", session)


@router.post("/relay/toggle")
async def relay_toggle(request: Request, session: Session = Depends(get_session)):
    return await _handle_relay(request, "toggle", session)


@router.get("/relay/health")
def relay_health():
    return pump_manager.relay_health()


# --- helper: accept multiple payload shapes and coerce types ---
def _normalize_maps(data: dict) -> tuple[dict[int, int] | None, dict[int, str] | None]:
    """Return sanitized GPIO/USB mapping dictionaries from flexible payloads."""

    def parse_gpio(raw: dict | None) -> dict[int, int]:
        result: dict[int, int] = {}
        for key, value in (raw or {}).items():
            try:
                result[int(key)] = int(value)
            except (TypeError, ValueError):
                continue
        return result

    def parse_usb(raw: dict | None) -> dict[int, str]:
        result: dict[int, str] = {}
        for key, value in (raw or {}).items():
            try:
                result[int(key)] = str(value)
            except (TypeError, ValueError):
                continue
        return result

    gpio_map: dict[int, int] | None = None
    usb_map: dict[int, str] | None = None

    if "gpio" in data:
        parsed = parse_gpio(data.get("gpio"))
        if parsed:
            gpio_map = parsed
    if "usb" in data:
        parsed = parse_usb(data.get("usb"))
        if parsed:
            usb_map = parsed

    if gpio_map is None and usb_map is None and "mapping" in data:
        raw = data.get("mapping") or {}
        backend = (data.get("backend") or "").upper()
        if backend == "GPIO":
            parsed = parse_gpio(raw)
            if parsed:
                gpio_map = parsed
        elif backend == "USB":
            parsed = parse_usb(raw)
            if parsed:
                usb_map = parsed
        else:
            gpio_guess = parse_gpio(raw)
            if gpio_guess:
                gpio_map = gpio_guess
            else:
                usb_guess = parse_usb(raw)
                if usb_guess:
                    usb_map = usb_guess

    return gpio_map, usb_map


def _readback_state(driver: object, widget_id: int) -> tuple[object | None, str | None]:
    """Attempt to read a pump state from the active driver."""

    if driver is None or not hasattr(driver, "get"):
        return None, "driver does not expose get()"
    try:
        raw = driver.get(widget_id)  # type: ignore[attr-defined]
    except Exception as exc:  # pragma: no cover - hardware interaction
        return None, str(exc)
    return raw, None


def _perform_test_sequence(session: Session, seconds: float) -> dict:
    mapped_ids = set(pump_manager.gpio_map.keys()) | set(pump_manager.usb_map.keys())
    widgets_lookup: dict[int, Widget] = {}
    order: list[int] = []

    if mapped_ids:
        widgets = session.exec(select(Widget).where(Widget.id.in_(mapped_ids))).all()
        widgets_lookup = {w.id: w for w in widgets}
        order = sorted(mapped_ids)
    else:
        widgets = session.exec(select(Widget).where(Widget.kind == "pump")).all()
        widgets_lookup = {w.id: w for w in widgets}
        order = [w.id for w in widgets]

    driver = getattr(pump_manager, "driver", None)
    results: list[dict[str, object]] = []

    for widget_id in order:
        widget = widgets_lookup.get(widget_id)
        slug = widget.slug if widget else "(missing)"
        backend = "GPIO" if widget_id in pump_manager.gpio_map else "USB" if widget_id in pump_manager.usb_map else "Unmapped"
        mapping = (
            pump_manager.gpio_map.get(widget_id)
            if backend == "GPIO"
            else pump_manager.usb_map.get(widget_id)
            if backend == "USB"
            else None
        )

        entry: dict[str, object] = {
            "id": widget_id,
            "slug": slug,
            "backend": backend.lower(),
            "mapping": mapping,
            "on_time": seconds,
            "tested": False,
        }

        logger.info("test-all: cycling widget %s (%s) mapped to %s", widget_id, slug, entry["backend"])

        on_error: str | None = None
        off_error: str | None = None

        try:
            pump_manager.set_pump(widget_id, True)
        except Exception as exc:  # pragma: no cover - hardware interaction
            on_error = f"ON failed: {exc}"
            logger.error("test-all: widget %s ON failed: %s", widget_id, exc)
        else:
            logger.info("test-all: widget %s -> ON (%.2fs window)", widget_id, seconds)
            time.sleep(max(seconds, 0.0))
            raw_on, on_read_error = _readback_state(driver, widget_id)
            if on_read_error:
                entry["on_readback_error"] = on_read_error
                logger.warning("test-all: widget %s ON readback error: %s", widget_id, on_read_error)
            else:
                entry["on_state"] = bool(raw_on)
                entry["on_raw"] = repr(raw_on)

        try:
            pump_manager.set_pump(widget_id, False)
        except Exception as exc:  # pragma: no cover - hardware interaction
            off_error = f"OFF failed: {exc}"
            logger.error("test-all: widget %s OFF failed: %s", widget_id, exc)
        else:
            logger.info("test-all: widget %s -> OFF", widget_id)
            raw_off, off_read_error = _readback_state(driver, widget_id)
            if off_read_error:
                entry["off_readback_error"] = off_read_error
                logger.warning("test-all: widget %s OFF readback error: %s", widget_id, off_read_error)
            else:
                entry["off_state"] = bool(raw_off)
                entry["off_raw"] = repr(raw_off)

        errors = [msg for msg in (on_error, off_error, entry.get("on_readback_error"), entry.get("off_readback_error")) if msg]
        if errors:
            entry["error"] = "; ".join(str(e) for e in errors)
        else:
            entry["tested"] = True

        results.append(entry)

    logger.info("test-all: completed (%d devices)", len(results))

    response: dict[str, object] = {"ok": True, "tested": results}
    if not results:
        response["detail"] = "No pump widgets found"
    elif mapped_ids:
        response["detail"] = "Tested mapped devices"
    else:
        response["detail"] = "No mappings detected; tested all pump widgets"
    return response
@router.get("/pumps")
def list_pumps(session: Session = Depends(get_session)):
    pumps = session.exec(select(Widget).where(Widget.kind == "pump")).all()
    return [{"id": w.id, "slug": w.slug, "state": pump_manager.get_state(w.id)} for w in pumps]

@router.post("/pump/{widget_id}/on")
def pump_on(widget_id: int):
    pump_manager.set_pump(widget_id, True)
    return {"id": widget_id, "state": True}

@router.post("/pump/{widget_id}/off")
def pump_off(widget_id: int):
    pump_manager.set_pump(widget_id, False)
    return {"id": widget_id, "state": False}

@router.delete("/pump/{widget_id}")
def delete_pump(widget_id: int, session: Session = Depends(get_session)):
    widget = session.get(Widget, widget_id)
    if widget is None or widget.kind != "pump":
        raise HTTPException(status_code=404, detail="Pump widget not found")

    if hasattr(pump_manager, "unmap"):
        try:
            pump_manager.unmap(widget_id)
        except Exception:
            pass

    session.delete(widget)
    session.commit()
    return {"ok": True, "id": widget_id}

@router.post("/all_off")
def all_off(session: Session = Depends(get_session)):
    pumps = session.exec(select(Widget).where(Widget.kind == "pump")).all()
    for w in pumps:
        pump_manager.set_pump(w.id, False)
    return {"ok": True, "count": len(pumps)}

@router.get("/backend")
def backend_info():
    info = pump_manager.describe()
    return {"driver": info.get("driver"), "backend": info.get("backend"), "slug": info.get("backend_slug")}

@router.get("/list")
def list_devices(session: Session = Depends(get_session)):
    """Return all pump widgets with backend info + state."""
    devices = []
    drv = pump_manager.driver
    gpio_ids = set(getattr(getattr(drv, "gpio", None), "actors", {}).keys()) if hasattr(drv, "gpio") else set()
    usb_ids  = set(getattr(getattr(drv, "usb",  None), "map",    {}).keys()) if hasattr(drv, "usb")  else set()
    for w in session.exec(select(Widget).where(Widget.kind == "pump")).all():
        backend = "gpio" if w.id in gpio_ids else "usb" if w.id in usb_ids else "unknown"
        devices.append({
            "id": w.id,
            "slug": w.slug,
            "state": pump_manager.get_state(w.id),
            "backend": backend,
        })
    return devices

@router.post("/test_all")
def test_all(
    session: Session = Depends(get_session),
    seconds: float = Query(0.5, description="Seconds to hold each pump ON before OFF"),
):
    """Legacy underscore endpoint retained for compatibility."""
    return _perform_test_sequence(session, seconds)


@router.post("/test-all")
def test_all_hyphen(
    session: Session = Depends(get_session),
    seconds: float = Query(0.5, description="Seconds to hold each pump ON before OFF"),
):
    """Cycle mapped pumps ON/OFF and log readbacks for field diagnostics."""
    return _perform_test_sequence(session, seconds)

@router.post("/test/{widget_id}")
def test_single(
    widget_id: int,
    seconds: float = Query(0.5, description="Seconds to hold pump ON before OFF"),
):
    """Cycle one pump ON then OFF once, with configurable ON-time."""
    pump_manager.set_pump(widget_id, True)
    time.sleep(seconds)
    pump_manager.set_pump(widget_id, False)
    return {"id": widget_id, "tested": True, "on_time": seconds}

# ---------- Minimal in-place UI (Add Device form included) ----------
@router.get("/ui", response_class=HTMLResponse)
def devices_ui():
    return """
<!doctype html>
<html>
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>BevForge — Devices</title>
  <style>
    :root { color-scheme: dark; }
    body { font-family: ui-sans-serif, system-ui, -apple-system, Segoe UI, Roboto, sans-serif; 
           background:#0b0f1a; color:#e6e9ef; margin:0; padding:1rem; }
    header { display:flex; align-items:center; gap:.75rem; margin-bottom:1rem; }
    .brand { font-weight:700; font-size:1.15rem; letter-spacing:.5px; }
    .pill { font-size:.8rem; opacity:.8; }
    button, input { background:#111726; border:1px solid #1e2842; color:#e6e9ef; 
                    padding:.5rem .75rem; border-radius:.5rem; }
    button:hover { background:#15203a; cursor:pointer; }
    .accent { border-color:#4158d0; }
    .danger { border-color:#d97706; }
    .row { display:flex; gap:.5rem; flex-wrap:wrap; align-items:center; }
    .col { display:flex; gap:.75rem; flex-wrap:wrap; align-items:center; }
    table { width:100%; border-collapse:collapse; margin-top:1rem; }
    th, td { border-bottom:1px solid #1e2842; padding:.5rem; text-align:left; }
    .badge { padding:.2rem .45rem; border:1px solid #334155; border-radius:.5rem; font-size:.75rem; }
    .ok { border-color:#4158d0; }
    .usb { border-color:#22c55e; }
    .gpio { border-color:#f59e0b; }
    .unknown { border-color:#52525b; }
    .muted { opacity:.7; font-size:.85rem; }
    .card { border:1px solid #1e2842; border-radius:.75rem; padding:.75rem; }
  </style>
</head>
<body>
  <header>
    <div class="brand">BevForge OS — Devices</div>
    <div id="driver" class="pill muted"></div><pre id="maps" class="muted" style="white-space:pre-wrap;margin:0"></pre>
  </header>

  <div class="row">
    <button id="refresh" class="accent">Refresh</button> <button id="reload" class="accent">Reload Maps</button>
    <input type="number" id="seconds" min="0.1" step="0.1" value="0.5" style="width:6rem" />
    <button id="testAll" class="accent">Test All</button>
    <button id="allOff" class="danger">All Off (Safety)</button>
  </div>

  <div class="card" style="margin-top:1rem">
    <div class="col">
      <strong>Add Device</strong>
      <input id="newSlug" placeholder="slug, e.g. pump-2" />
      <button id="addDevice" class="accent">Add Pump</button>
      <span class="muted">Creates a pump widget in the DB. Map it via env (PUMP_GPIO_MAP / PUMP_USB_MAP) and restart.</span>
    </div>
  </div>

  <table id="tbl">
    <thead>
      <tr><th>ID</th><th>Slug</th><th>Backend</th><th>State</th><th>Actions</th></tr>
    </thead>
    <tbody></tbody>
  </table>

<script>
async function api(p, opts={}) {
  const r = await fetch(p, opts);
  if (!r.ok) throw new Error((await r.text()) || r.statusText);
  const ct = r.headers.get("content-type") || "";
  return ct.includes("application/json") ? r.json() : r.text();
}
function badge(txt, cls){ return `<span class="badge ${cls}">${txt}</span>`; }

async function load() {
  try {
    const info = await api("/devices/backend");
    document.getElementById("driver").textContent = "Backend: " + info.driver;
  } catch (e) { document.getElementById("driver").textContent = "Backend: (error)"; }

  const tbody = document.querySelector("#tbl tbody");
  tbody.innerHTML = "";
  const items = await api("/devices/list");
  for (const d of items) {
    const bcls = d.backend === "gpio" ? "gpio" : d.backend === "usb" ? "usb" : "unknown";
    const state = d.state ? badge("ON","ok") : badge("OFF","unknown");
    const row = document.createElement("tr");
    row.innerHTML = `
      <td>${d.id}</td>
      <td>${d.slug}</td>
      <td>${badge(d.backend.toUpperCase(), bcls)}</td>
      <td>${state}</td>
      <td class="row">
        <button data-act="on" data-id="${d.id}">On</button>
        <button data-act="off" data-id="${d.id}">Off</button>
        <button data-act="test" data-id="${d.id}">Test</button>
        <button data-act="delete" data-id="${d.id}">Delete</button>
      </td>`;
    tbody.appendChild(row);
  }
}

addEventListener("click", async (e) => {
  const b = e.target.closest("button");
  if (!b) return;
  try {
    if (b.id === "refresh") return void load();
    if (b.id === "allOff") { await api("/devices/all_off", {method:"POST"}); return void load(); }
    if (b.id === "reload") { await api("/devices/reload", {method:"POST"}); return void load(); }
    if (b.id === "testAll") {
      const s = parseFloat(document.getElementById("seconds").value || "0.5");
      await api("/devices/test_all?seconds="+encodeURIComponent(s), {method:"POST"});
      return void load();
    }
    if (b.id === "addDevice") {
      const slug = (document.getElementById("newSlug").value || "").trim();
      if (!slug) { alert("Enter a slug (e.g. pump-3 or usb-2)"); return; }
      await api("/widgets", {
        method: "POST",
        headers: {"Content-Type":"application/json"},
        body: JSON.stringify({slug, kind:"pump"})
      });
      document.getElementById("newSlug").value = "";
      return void load();
    }
    const id = b.dataset.id;
    if (b.dataset.act === "on")  { await api("/devices/pump/"+id+"/on",  {method:"POST"}); return void load(); }
    if (b.dataset.act === "off") { await api("/devices/pump/"+id+"/off", {method:"POST"}); return void load(); }
    if (b.dataset.act === "test"){
      const s = parseFloat(document.getElementById("seconds").value || "0.5");
      await api("/devices/test/"+id+"?seconds="+encodeURIComponent(s), {method:"POST"});
      return void load();
    }
    if (b.dataset.act === "delete"){
      await api("/devices/pump/"+id, {method:"DELETE"});
      return void load();
    }
  } catch (err) {
    alert("Error: " + err.message);
  }
});
load();
</script>
</body>
</html>
    """

@router.get("/mappings")
def mappings():
    return pump_manager.describe()

@router.post("/reload")
def reload_backend():
    cls = pump_manager.reload()
    return {"ok": True, "backend": cls}


@router.post("/backend/set")
def devices_backend_set(payload: dict = Body(...)):
    """Set the active pump backend: Dummy | GPIO | USB | Mixed"""
    backend = str(payload.get("backend", "Dummy")).strip()
    ok = pump_manager.configure(backend=backend)
    info = pump_manager.describe()
    return {"ok": bool(ok), "backend": info.get("backend"), "driver": info.get("driver")}


@router.post("/apply_map")
def devices_apply_map(payload: dict = Body(...)):
    """Bulk mapping endpoint used by the Devices UI."""
    if not isinstance(payload, dict):
        raise HTTPException(status_code=400, detail="payload must be a JSON object")

    kind = str(payload.get("kind", "pump")).lower()
    if kind and kind != "pump":
        raise HTTPException(status_code=400, detail="only kind=pump supported")

    backend = str(payload.get("backend", "")).strip().upper()
    if backend not in {"", "GPIO", "USB", "MIXED"}:
        raise HTTPException(status_code=400, detail="backend must be GPIO, USB, or Mixed")

    gpio_map, usb_map = _normalize_maps(payload)
    raw_gpio = payload.get("gpio") if isinstance(payload.get("gpio"), dict) else {}
    raw_usb = payload.get("usb") if isinstance(payload.get("usb"), dict) else {}

    new_gpio = dict(pump_manager.gpio_map)
    new_usb = dict(pump_manager.usb_map)
    touched = False

    if backend in {"", "GPIO", "MIXED"}:
        if raw_gpio:
            for key, value in raw_gpio.items():
                if value in ("", None):
                    try:
                        wid = int(key)
                    except (TypeError, ValueError):
                        continue
                    removed = False
                    if wid in new_gpio:
                        new_gpio.pop(wid, None)
                        removed = True
                    if wid in new_usb:
                        new_usb.pop(wid, None)
                        removed = True
                    touched = touched or removed
        if gpio_map:
            touched = True
            for wid, pin in gpio_map.items():
                new_gpio[wid] = pin
                if wid in new_usb:
                    new_usb.pop(wid, None)
                    touched = True

    if backend in {"", "USB", "MIXED"}:
        if raw_usb:
            for key, value in raw_usb.items():
                if value in ("", None):
                    try:
                        wid = int(key)
                    except (TypeError, ValueError):
                        continue
                    removed = False
                    if wid in new_usb:
                        new_usb.pop(wid, None)
                        removed = True
                    if wid in new_gpio:
                        new_gpio.pop(wid, None)
                        removed = True
                    touched = touched or removed
        if usb_map:
            touched = True
            for wid, relay in usb_map.items():
                new_usb[wid] = relay
                if wid in new_gpio:
                    new_gpio.pop(wid, None)
                    touched = True

    if not touched:
        raise HTTPException(status_code=400, detail="no mapping provided")

    ok = pump_manager.update_maps(gpio=new_gpio, usb=new_usb)
    mapping = pump_manager.describe()
    response: dict = {"ok": bool(ok), "mapping": mapping}
    if not ok:
        response["detail"] = "pump driver reload failed; mapping saved for next reload"
    return response


@router.post("/map")
def devices_map(payload: dict = Body(...)):
    """Map pumps to GPIO pins or USB relays (bulk or single widget)."""
    if not isinstance(payload, dict):
        raise HTTPException(status_code=400, detail="payload must be a JSON object")

    if any(key in payload for key in ("mapping", "gpio", "usb")):
        kind = str(payload.get("kind", "pump")).lower()
        if kind and kind != "pump":
            raise HTTPException(status_code=400, detail="only kind=pump supported")
        gpio_map, usb_map = _normalize_maps(payload)
        updated = False
        ok = True
        if gpio_map:
            for wid, pin in gpio_map.items():
                updated = True
                ok = pump_manager.map_gpio(wid, pin) and ok
        if usb_map:
            for wid, relay in usb_map.items():
                updated = True
                ok = pump_manager.map_usb(wid, relay) and ok
        if not updated:
            raise HTTPException(status_code=400, detail="no mapping provided")
        info = pump_manager.describe()
        resp = {"ok": bool(ok), "mapping": info}
        if not ok:
            resp["detail"] = "pump driver reload failed; mapping saved for next reload"
        return resp

    wid = int(payload.get("widget_id") or 0)
    how = str(payload.get("map_as", "")).upper()
    if wid <= 0 or how not in {"GPIO", "USB", "DUMMY"}:
        raise HTTPException(status_code=400, detail="bad parameters")

    success = False
    if how == "GPIO":
        gpio_pin = payload.get("gpio_pin")
        if gpio_pin is None:
            raise HTTPException(status_code=400, detail="gpio_pin required")
        success = pump_manager.map_gpio(wid, gpio_pin)
    elif how == "USB":
        usb_id = payload.get("usb_id")
        if not usb_id:
            raise HTTPException(status_code=400, detail="usb_id required")
        success = pump_manager.map_usb(wid, usb_id)
    else:  # DUMMY
        success = pump_manager.unmap(wid)

    info = pump_manager.describe()
    resp = {"ok": bool(success), "widget_id": wid, "map_as": how, "mapping": info}
    if not success:
        resp["detail"] = "unable to update mapping"
    return resp
