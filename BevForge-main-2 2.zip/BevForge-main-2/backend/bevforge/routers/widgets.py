from __future__ import annotations

import json
from datetime import datetime
from math import isfinite
from typing import Any, Dict, List

from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.encoders import jsonable_encoder
from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse
from sqlmodel import Session, select

from ..db import get_session
from ..models import Widget
from ..utils.usbrelay import format_relay_label

router = APIRouter(prefix="/widgets", tags=["widgets"])
tools_router = APIRouter(prefix="/tools", tags=["tools"])


_TEMPLATE_MAP = {
    "hydrometer": "widgets/hydrometer.html",
    "sensor": "widgets/sensor.html",
    "relay": "widgets/relay.html",
    "weather": "widgets/weather.html",
    "image": "widgets/image.html",
    "text": "widgets/text.html",
    "number": "widgets/text.html",
    "widget": "widgets/text.html",
    "dummy": "widgets/dummy.html",
    "dummy_relay": "widgets/dummy.html",
    "dummy_data": "widgets/dummy.html",
    "dummy_sensor": "widgets/dummy.html",
}

_RELAY_BACKENDS = {"USB", "GPIO"}

_TILT_COLORS = [
    "blue",
    "green",
    "red",
    "orange",
    "yellow",
    "purple",
    "pink",
    "black",
]

_SENSOR_TYPE_LABELS = {
    "hydrometer": "Hydrometer / Tilt",
    "flow": "Flow meter",
    "temp_probe": "Temperature probe",
}

_SENSOR_FIELD_LABELS = {
    "sg": "Specific Gravity",
    "temp_f": "Temperature (°F)",
    "both": "Both (SG + Temp)",
}

_WEATHER_UNITS = {"us", "metric"}


def _coerce_float(value: Any, *, default: float, minimum: float, maximum: float) -> float:
    try:
        parsed = float(value)
    except (TypeError, ValueError):
        parsed = default
    if not isfinite(parsed):
        parsed = default
    if parsed < minimum:
        parsed = minimum
    if parsed > maximum:
        parsed = maximum
    return round(parsed, 4)

_WEATHER_CODE_LABELS = {
    0: "Clear sky",
    1: "Mainly clear",
    2: "Partly cloudy",
    3: "Overcast",
    45: "Fog",
    48: "Depositing rime fog",
    51: "Light drizzle",
    53: "Moderate drizzle",
    55: "Dense drizzle",
    56: "Light freezing drizzle",
    57: "Dense freezing drizzle",
    61: "Slight rain",
    63: "Moderate rain",
    65: "Heavy rain",
    66: "Light freezing rain",
    67: "Heavy freezing rain",
    71: "Slight snowfall",
    73: "Moderate snowfall",
    75: "Heavy snowfall",
    77: "Snow grains",
    80: "Slight rain showers",
    81: "Moderate rain showers",
    82: "Violent rain showers",
    85: "Slight snow showers",
    86: "Heavy snow showers",
    95: "Thunderstorm",
    96: "Thunderstorm with slight hail",
    99: "Thunderstorm with heavy hail",
}


def _format_coord(value: Any) -> str:
    try:
        number = float(value)
    except (TypeError, ValueError):
        return ""
    return f"{number:.4f}"


def _weather_form_defaults(config: Dict[str, Any]) -> Dict[str, Any]:
    manual = config.get("manual_weather") or {}
    manual_temp = manual.get("temp")
    manual_cond_code = manual.get("cond_code")
    manual_is_day = manual.get("is_day")
    return {
        "lat": _format_coord(config.get("lat")),
        "lon": _format_coord(config.get("lon")),
        "units": (str(config.get("units") or "us").lower() if config.get("units") else "us"),
        "location_label": str(config.get("location_label") or "").strip(),
        "refresh_min": int(config.get("refresh_min") or 10),
        "manual": {
            "temp": "" if manual_temp in (None, "") else str(manual_temp),
            "cond_code": manual_cond_code if isinstance(manual_cond_code, int) else "",
            "cond_text": str(manual.get("cond_text") or "").strip(),
            "is_day": bool(manual_is_day),
            "updated_at": manual.get("updated_at"),
        },
    }


def _normalize_weather_config(
    payload: Dict[str, Any],
    *,
    existing: Dict[str, Any] | None = None,
) -> Dict[str, Any]:
    config = dict(existing or {})

    lat_raw = payload.get("lat")
    if lat_raw in (None, "", "null", "None"):
        if "lat" not in config:
            raise HTTPException(status_code=400, detail="Latitude is required for weather widgets.")
        lat_value = config["lat"]
    else:
        try:
            lat_value = float(lat_raw)
        except (TypeError, ValueError):
            raise HTTPException(status_code=400, detail="Latitude must be a number.") from None

    lon_raw = payload.get("lon")
    if lon_raw in (None, "", "null", "None"):
        if "lon" not in config:
            raise HTTPException(status_code=400, detail="Longitude is required for weather widgets.")
        lon_value = config["lon"]
    else:
        try:
            lon_value = float(lon_raw)
        except (TypeError, ValueError):
            raise HTTPException(status_code=400, detail="Longitude must be a number.") from None

    units_raw = payload.get("units") or config.get("units") or "us"
    units_value = str(units_raw).strip().lower()
    if units_value not in _WEATHER_UNITS:
        units_value = "us"

    refresh_raw = payload.get("refresh_min") if "refresh_min" in payload else config.get("refresh_min")
    if refresh_raw in (None, "", "null", "None"):
        refresh_value = int(config.get("refresh_min") or 10)
    else:
        try:
            refresh_value = int(refresh_raw)
        except (TypeError, ValueError):
            raise HTTPException(
                status_code=400,
                detail="Refresh interval must be a whole number of minutes.",
            ) from None
    if refresh_value < 1:
        refresh_value = 1

    location_label = str(
        payload.get("location_label") or config.get("location_label") or ""
    ).strip()

    config.update(
        {
            "lat": lat_value,
            "lon": lon_value,
            "units": units_value,
            "refresh_min": refresh_value,
            "location_label": location_label,
        }
    )

    if "manual_weather" in config and not isinstance(config["manual_weather"], dict):
        config.pop("manual_weather", None)

    return config



def _as_bool(value: Any, *, default: bool = False) -> bool:
    if isinstance(value, str):
        text = value.strip().lower()
        if text in {"1", "true", "on", "yes", "y", "enabled"}:
            return True
        if text in {"0", "false", "off", "no", "n", "disabled"}:
            return False
        if text == "":
            return default
    if value is None:
        return default
    if isinstance(value, (int, float)):
        return bool(value)
    return bool(value)


def _normalize_image_config(
    payload: Dict[str, Any],
    *,
    existing: Dict[str, Any] | None = None,
) -> Dict[str, Any]:
    config = dict(existing or {})
    config.update(payload)

    fit_raw = str(config.get("object_fit") or "cover").strip().lower()
    config["object_fit"] = "contain" if fit_raw == "contain" else "cover"

    current_scale = config.get("scale") if "scale" in config else 1.0
    config["scale"] = _coerce_float(current_scale, default=1.0, minimum=0.5, maximum=2.0)

    offset_x = config.get("offset_x") if "offset_x" in config else 0
    offset_y = config.get("offset_y") if "offset_y" in config else 0

    try:
        offset_x_value = int(float(offset_x))
    except (TypeError, ValueError):
        offset_x_value = 0
    try:
        offset_y_value = int(float(offset_y))
    except (TypeError, ValueError):
        offset_y_value = 0

    config["offset_x"] = max(min(offset_x_value, 2000), -2000)
    config["offset_y"] = max(min(offset_y_value, 2000), -2000)

    layer_raw = str(config.get("layer") or "foreground").strip().lower()
    config["layer"] = "background" if layer_raw == "background" else "foreground"

    svg_mask = _as_bool(config.get("svg_mask"), default=False)
    config["svg_mask"] = svg_mask

    if svg_mask:
        color_raw = config.get("svg_mask_color")
        color_text = str(color_raw).strip() if color_raw not in (None, "") else ""
        config["svg_mask_color"] = color_text or "#0f172a"
    else:
        config.pop("svg_mask_color", None)

    return config



def _parse_config(widget: Widget) -> Dict[str, Any]:
    try:
        return json.loads(widget.config_json or "{}")
    except json.JSONDecodeError:
        return {}


def render_widget(widget: Widget, mode: str) -> str:
    """Return the template used to render a widget tile."""

    kind = (widget.kind or "").strip().lower()
    if kind == "dummy_sensor":
        kind = "dummy_data"
    return _TEMPLATE_MAP.get(kind, "widgets/unknown.html")


def _widget_context(widget: Widget, *, mode: str) -> Dict[str, Any]:
    config = _parse_config(widget)
    supports_draft = all(
        hasattr(widget, field)
        for field in ("draft_x", "draft_y", "draft_w", "draft_h")
    )
    has_draft = False
    draft_values: Dict[str, Any] | None = None
    if supports_draft:
        draft_values = {
            "x": getattr(widget, "draft_x", None),
            "y": getattr(widget, "draft_y", None),
            "w": getattr(widget, "draft_w", None),
            "h": getattr(widget, "draft_h", None),
        }
        has_draft = any(value is not None for value in draft_values.values())

    return {
        "widget": {
            "id": widget.id,
            "slug": widget.slug,
            "kind": widget.kind,
            "config_json": config,
            "has_draft": has_draft,
            "draft": draft_values,
        },
        "mode": mode,
        "is_edit": mode == "edit",
        "dummy_form": _dummy_form_defaults(widget.kind, config),
        "weather_form": _weather_form_defaults(config),
    }


def _relay_form_defaults(config: Dict[str, Any]) -> Dict[str, Any]:
    backend_value = str(config.get("backend") or "USB").upper()
    if backend_value not in _RELAY_BACKENDS:
        backend_value = "USB"

    channel_raw = config.get("channel")
    try:
        channel_value = int(channel_raw)
    except (TypeError, ValueError):
        channel_value = None

    board_value = str(config.get("board") or "").strip()

    bcm_raw = config.get("bcm")
    try:
        bcm_value = int(bcm_raw)
    except (TypeError, ValueError):
        bcm_value = None

    relay_label = str(config.get("relay_label") or "").strip()
    if backend_value == "USB" and board_value and channel_value:
        if not relay_label:
            try:
                relay_label = format_relay_label(board_value, channel_value)
            except ValueError:
                relay_label = ""

    return {
        "backend": backend_value,
        "board": board_value,
        "channel": channel_value,
        "bcm": bcm_value,
        "relay_label": relay_label,
    }


def _normalize_sensor_fields(raw_fields: Any) -> List[str]:
    if isinstance(raw_fields, list):
        candidates = raw_fields
    elif isinstance(raw_fields, (tuple, set)):
        candidates = list(raw_fields)
    elif isinstance(raw_fields, str):
        candidates = [raw_fields]
    else:
        candidates = []

    normalized: List[str] = []
    for entry in candidates:
        text = str(entry).strip().lower()
        if not text:
            continue
        if text == "both":
            return ["sg", "temp_f"]
        if text in {"sg", "temp_f"} and text not in normalized:
            normalized.append(text)

    return normalized or ["sg", "temp_f"]


def _sensor_form_defaults(widget_kind: str, config: Dict[str, Any]) -> Dict[str, Any]:
    sensor_kind = str(config.get("sensor_kind") or widget_kind or "hydrometer").lower()
    if sensor_kind not in _SENSOR_TYPE_LABELS:
        sensor_kind = "hydrometer"

    tilt_color = str(
        config.get("tilt_color")
        or config.get("color")
        or config.get("tilt")
        or "blue"
    ).lower()
    if tilt_color not in _TILT_COLORS:
        tilt_color = "blue"

    fields = _normalize_sensor_fields(config.get("fields"))

    flow_sensor_id = ""
    flow_alias = ""
    temp_probe_id = ""
    temp_alias = ""

    alias_value = str(config.get("alias") or "").strip()

    if sensor_kind == "flow":
        flow_sensor_id = str(
            config.get("sensor_id")
            or config.get("flow_sensor_id")
            or ""
        ).strip()
        flow_alias = str(config.get("flow_alias") or alias_value).strip()
    elif sensor_kind == "temp_probe":
        temp_probe_id = str(
            config.get("probe_id")
            or config.get("temp_probe_id")
            or config.get("sensor_id")
            or ""
        ).strip()
        temp_alias = str(config.get("temp_alias") or alias_value).strip()

    return {
        "kind": sensor_kind,
        "tilt_color": tilt_color,
        "fields": fields,
        "flow_sensor_id": flow_sensor_id,
        "flow_alias": flow_alias,
        "temp_probe_id": temp_probe_id,
        "temp_alias": temp_alias,
    }


def _dummy_form_defaults(widget_kind: str, config: Dict[str, Any]) -> Dict[str, Any]:
    kind_value = str(config.get("dummy_kind") or widget_kind or "dummy_relay").lower()
    if kind_value in {"dummy_data", "dummy_sensor", "data"}:
        normalized = "dummy_data"
    else:
        normalized = "dummy_relay"

    state_value = _as_bool(config.get("state"), default=False)
    raw_value = config.get("value")
    value_text = "" if raw_value is None else str(raw_value)

    return {
        "kind": normalized,
        "state": state_value,
        "value": value_text,
    }


def _relay_form_defaults(config: Dict[str, Any]) -> Dict[str, Any]:
    backend_value = str(config.get("backend") or "USB").upper()
    if backend_value not in _RELAY_BACKENDS:
        backend_value = "USB"

    channel_raw = config.get("channel")
    try:
        channel_value = int(channel_raw)
    except (TypeError, ValueError):
        channel_value = None

    board_value = str(config.get("board") or "").strip()

    bcm_raw = config.get("bcm")
    try:
        bcm_value = int(bcm_raw)
    except (TypeError, ValueError):
        bcm_value = None

    relay_label = str(config.get("relay_label") or "").strip()
    if backend_value == "USB" and board_value and channel_value:
        if not relay_label:
            try:
                relay_label = format_relay_label(board_value, channel_value)
            except ValueError:
                relay_label = ""

    return {
        "backend": backend_value,
        "board": board_value,
        "channel": channel_value,
        "bcm": bcm_value,
        "relay_label": relay_label,
    }


def _normalize_sensor_fields(raw_fields: Any) -> List[str]:
    if isinstance(raw_fields, list):
        candidates = raw_fields
    elif isinstance(raw_fields, (tuple, set)):
        candidates = list(raw_fields)
    elif isinstance(raw_fields, str):
        candidates = [raw_fields]
    else:
        candidates = []

    normalized: List[str] = []
    for entry in candidates:
        text = str(entry).strip().lower()
        if not text:
            continue
        if text == "both":
            return ["sg", "temp_f"]
        if text in {"sg", "temp_f"} and text not in normalized:
            normalized.append(text)

    return normalized or ["sg", "temp_f"]


def _sensor_form_defaults(widget_kind: str, config: Dict[str, Any]) -> Dict[str, Any]:
    sensor_kind = str(config.get("sensor_kind") or widget_kind or "hydrometer").lower()
    if sensor_kind not in _SENSOR_TYPE_LABELS:
        sensor_kind = "hydrometer"

    tilt_color = str(
        config.get("tilt_color")
        or config.get("color")
        or config.get("tilt")
        or "blue"
    ).lower()
    if tilt_color not in _TILT_COLORS:
        tilt_color = "blue"

    fields = _normalize_sensor_fields(config.get("fields"))

    flow_sensor_id = ""
    flow_alias = ""
    temp_probe_id = ""
    temp_alias = ""

    alias_value = str(config.get("alias") or "").strip()

    if sensor_kind == "flow":
        flow_sensor_id = str(
            config.get("sensor_id")
            or config.get("flow_sensor_id")
            or ""
        ).strip()
        flow_alias = str(config.get("flow_alias") or alias_value).strip()
    elif sensor_kind == "temp_probe":
        temp_probe_id = str(
            config.get("probe_id")
            or config.get("temp_probe_id")
            or config.get("sensor_id")
            or ""
        ).strip()
        temp_alias = str(config.get("temp_alias") or alias_value).strip()

    return {
        "kind": sensor_kind,
        "tilt_color": tilt_color,
        "fields": fields,
        "flow_sensor_id": flow_sensor_id,
        "flow_alias": flow_alias,
        "temp_probe_id": temp_probe_id,
        "temp_alias": temp_alias,
    }


def _dummy_form_defaults(widget_kind: str, config: Dict[str, Any]) -> Dict[str, Any]:
    kind_value = str(config.get("dummy_kind") or widget_kind or "dummy_relay").lower()
    if kind_value in {"dummy_data", "dummy_sensor", "data"}:
        normalized = "dummy_data"
    else:
        normalized = "dummy_relay"

    state_value = _as_bool(config.get("state"), default=False)
    raw_value = config.get("value")
    value_text = "" if raw_value is None else str(raw_value)

    return {
        "kind": normalized,
        "state": state_value,
        "value": value_text,
    }


async def _extract_request_data(request: Request) -> Dict[str, Any]:
    content_type = (request.headers.get("content-type") or "").lower()
    if "application/json" in content_type:
        try:
            payload = await request.json()
        except Exception as exc:  # pragma: no cover - defensive
            raise HTTPException(status_code=400, detail="Body must be valid JSON") from exc
        if not isinstance(payload, dict):
            raise HTTPException(status_code=400, detail="Body must be an object")
        return payload

    form = await request.form()
    data: Dict[str, Any] = {}
    for key in form.keys():
        values = form.getlist(key)
        if not values:
            data[key] = None
        elif len(values) == 1:
            data[key] = values[0]
        else:
            data[key] = values
    return data


def _display_values(widget: Widget, config: Dict[str, Any]) -> Dict[str, str]:
    label = str(config.get("label") or widget.slug or f"Widget #{widget.id}").strip()
    label_text = label or f"Widget #{widget.id}"

    kind_raw = (widget.kind or "").strip().lower()
    if kind_raw in {"dummy", "dummy_relay"}:
        kind_text = "Dummy Relay"
    elif kind_raw in {"dummy_data", "dummy_sensor"}:
        kind_text = "Dummy Data Injector"
    elif kind_raw == "weather":
        kind_text = "Weather"
    elif kind_raw in {"widget", "text", "number"}:
        widget_kind = str(config.get("widget_kind") or kind_raw).strip().lower()
        if widget_kind in {"number", "numeric", "value"}:
            kind_text = "Number Widget"
        else:
            kind_text = "Text Widget"
    elif kind_raw in {"sensor", "hydrometer"}:
        sensor_kind = str(
            config.get("sensor_kind") or widget.kind or "hydrometer"
        ).strip().lower()
        if sensor_kind in _SENSOR_TYPE_LABELS:
            kind_text = _SENSOR_TYPE_LABELS[sensor_kind]
        else:
            kind_text = sensor_kind.replace("_", " ").strip().title() or "Sensor"
    else:
        fallback_kind = (widget.kind or "Widget").replace("_", " ").strip().title()
        kind_text = fallback_kind or "Widget"

    return {"label": label_text, "kind": kind_text}


@router.get("")
def list_widgets(session: Session = Depends(get_session)):
    return session.exec(select(Widget)).all()


@router.post("")
async def create_widget(request: Request, session: Session = Depends(get_session)):
    content_type = request.headers.get("content-type", "").lower()

    data: Dict[str, Any]
    if "application/json" in content_type:
        try:
            data = await request.json()
        except json.JSONDecodeError as exc:
            raise HTTPException(status_code=400, detail="Request body must be valid JSON.") from exc
    elif "application/x-www-form-urlencoded" in content_type or "multipart/form-data" in content_type:
        form = await request.form()
        data = {key: value for key, value in form.items()}
    else:
        try:
            data = await request.json()
        except json.JSONDecodeError:
            form = await request.form()
            data = {key: value for key, value in form.items()}

    if not isinstance(data, dict):
        raise HTTPException(status_code=400, detail="Request body must be a JSON object.")

    # Merge query parameters (e.g., draft=1) if not already present in the body
    for key, value in request.query_params.multi_items():
        data.setdefault(key, value)

    if "config" in data and "config_json" not in data:
        config = data.pop("config")
        data["config_json"] = config if config is not None else {}

    raw_kind = data.get("kind")
    kind = (raw_kind or "").strip()
    if not kind:
        raise HTTPException(status_code=400, detail="kind is required")
    kind_lower = kind.lower()
    data["kind"] = kind

    if "config_json" in data:
        raw_config = data.get("config_json")
        if isinstance(raw_config, (dict, list)):
            config_obj: Any = raw_config
        elif isinstance(raw_config, str):
            raw_text = raw_config.strip()
            if raw_text in ("", "null", "None"):
                config_obj = {}
            else:
                try:
                    config_obj = json.loads(raw_text)
                except json.JSONDecodeError as exc:
                    raise HTTPException(status_code=400, detail="config_json must be valid JSON") from exc
        else:
            raise HTTPException(status_code=400, detail="config_json must be an object or JSON string")
    else:
        config_obj = {}

    if isinstance(config_obj, dict):
        if kind_lower == "relay":
            relay_label = str(config_obj.get("relay_label") or "").strip()
            if not relay_label:
                board_value = config_obj.get("board")
                channel_value = config_obj.get("channel")
                try:
                    channel_int = int(channel_value) if channel_value is not None else None
                except (TypeError, ValueError):
                    channel_int = None
                board_text = str(board_value).strip() if board_value not in (None, "") else ""
                if board_text and channel_int is not None:
                    try:
                        config_obj["relay_label"] = format_relay_label(
                            board_text, channel_int
                        )
                    except ValueError:
                        pass
        elif kind_lower == "weather":
            config_obj = _normalize_weather_config(config_obj)
        elif kind_lower == "image":
            config_obj = _normalize_image_config(config_obj)
        elif kind_lower in {"dummy", "dummy_relay", "dummy_data", "dummy_sensor"}:
            config_obj["dummy"] = True
            if kind_lower in {"dummy", "dummy_relay"}:
                config_obj["dummy_kind"] = "relay"
                config_obj["state"] = _as_bool(config_obj.get("state"), default=False)
                config_obj.pop("value", None)
                kind = "dummy_relay"
            else:
                config_obj["dummy_kind"] = "data"
                raw_value = config_obj.get("value")
                config_obj["value"] = "" if raw_value is None else str(raw_value)
                config_obj.pop("state", None)
                kind = "dummy_data"
            data["kind"] = kind
            kind_lower = kind

    data["config_json"] = json.dumps(config_obj)

    slug = (data.get("slug") or "").strip()
    if not slug:
        base = kind.replace(" ", "-") or "widget"
        existing_slugs = set(session.exec(select(Widget.slug)).all())
        index = 1
        while True:
            candidate = f"{base}-{index}"
            if candidate not in existing_slugs:
                slug = candidate
                break
            index += 1
    data["slug"] = slug

    numeric_defaults = {"x": 0, "y": 0, "w": 1, "h": 1}
    numeric_values: Dict[str, int] = {}
    for field, default in numeric_defaults.items():
        if field in data:
            value = data.get(field)
            if value in (None, "", "null", "None"):
                numeric_values[field] = default
                continue
            try:
                numeric_values[field] = int(value)
            except (TypeError, ValueError) as exc:
                raise HTTPException(status_code=400, detail=f"{field} must be an integer") from exc
        else:
            numeric_values[field] = default

    widget_fields = {
        "slug": data["slug"],
        "kind": data["kind"],
        "config_json": data["config_json"],
        "x": numeric_values["x"],
        "y": numeric_values["y"],
        "w": numeric_values["w"],
        "h": numeric_values["h"],
    }

    widget = Widget(**widget_fields)
    if getattr(widget, "published_at", None) is None:
        widget.published_at = datetime.utcnow()

    try:
        session.add(widget)
        session.commit()
    except Exception:
        session.rollback()
        raise

    session.refresh(widget)

    response_payload = {"id": widget.id, "kind": widget.kind, "w": widget.w, "h": widget.h}

    accept_header = (request.headers.get("accept") or "").lower()
    wants_json = "application/json" in accept_header or request.headers.get("hx-request") == "true"

    if wants_json:
        response = JSONResponse(status_code=201, content=response_payload)
    else:
        redirect_target = (
            request.query_params.get("redirect")
            or request.query_params.get("next")
            or "/dashboard/edit"
        )
        response = RedirectResponse(url=redirect_target, status_code=303)
        response.headers["X-Widget-Resource"] = f"/widgets/{widget.id}"
        response.headers["X-Widget-ID"] = str(widget.id)

    response.headers.setdefault("Location", f"/widgets/{widget.id}")
    return response


@router.get("/render/{widget_id}", response_class=HTMLResponse)
def get_widget_render(
    widget_id: int,
    request: Request,
    session: Session = Depends(get_session),
):
    widget = session.get(Widget, widget_id)
    if not widget:
        raise HTTPException(status_code=404, detail="Widget not found")

    mode = request.query_params.get("mode", "view")
    template_name = render_widget(widget, mode)
    context = _widget_context(widget, mode=mode)
    context["request"] = request
    return request.app.state.templates.TemplateResponse(template_name, context)


@router.get("/{widget_id}")
def get_widget(widget_id: int, session: Session = Depends(get_session)):
    widget = session.get(Widget, widget_id)
    if not widget:
        raise HTTPException(status_code=404, detail="Widget not found")
    return widget


@router.get("/{widget_id}/edit", response_class=HTMLResponse)
def edit_widget_modal(
    widget_id: int,
    request: Request,
    session: Session = Depends(get_session),
):
    widget = session.get(Widget, widget_id)
    if not widget:
        raise HTTPException(status_code=404, detail="Widget not found")

    config = _parse_config(widget)
    widget_payload = {
        "id": widget.id,
        "slug": widget.slug,
        "kind": widget.kind,
        "config_json": config,
    }

    context = {
        "request": request,
        "widget": widget_payload,
        "display": _display_values(widget, config),
        "relay_form": _relay_form_defaults(config),
        "sensor_form": _sensor_form_defaults(widget.kind, config),
        "dummy_form": _dummy_form_defaults(widget.kind, config),
        "weather_form": _weather_form_defaults(config),
        "relay_backends": sorted(_RELAY_BACKENDS),
        "tilt_colors": _TILT_COLORS,
        "sensor_types": [
            {"value": key, "label": label}
            for key, label in _SENSOR_TYPE_LABELS.items()
        ],
        "sensor_field_options": [
            {"value": key, "label": label}
            for key, label in _SENSOR_FIELD_LABELS.items()
        ],
    }

    return request.app.state.templates.TemplateResponse(
        "widgets/_edit_modal.html", context
    )


@router.post("/{widget_id}")
async def save_widget(
    widget_id: int,
    request: Request,
    session: Session = Depends(get_session),
):
    widget = session.get(Widget, widget_id)
    if not widget:
        raise HTTPException(status_code=404, detail="Widget not found")

    data = await _extract_request_data(request)

    raw_label = data.get("slug") or data.get("label") or widget.slug
    label = str(raw_label or "").strip()
    if not label:
        raise HTTPException(status_code=400, detail="Name/label cannot be empty.")

    config = _parse_config(widget)
    config["label"] = label

    kind = (widget.kind or "").strip().lower()

    if kind == "relay":
        backend_value = str(
            data.get("relay_backend") or config.get("backend") or "USB"
        ).upper()
        if backend_value not in _RELAY_BACKENDS:
            raise HTTPException(
                status_code=400, detail="Relay backend must be USB or GPIO."
            )
        config["backend"] = backend_value
        config["device_kind"] = "relay"

        if backend_value == "USB":
            board_value = str(
                data.get("relay_board") or config.get("board") or ""
            ).strip()
            if not board_value:
                raise HTTPException(
                    status_code=400, detail="Board ID is required for USB relays."
                )
            channel_raw = data.get("relay_channel") or config.get("channel")
            try:
                channel_value = int(channel_raw)
            except (TypeError, ValueError):
                raise HTTPException(
                    status_code=400,
                    detail="Channel must be a number between 1 and 8.",
                )
            if channel_value < 1 or channel_value > 8:
                raise HTTPException(
                    status_code=400, detail="Channel must be between 1 and 8."
                )
            config["board"] = board_value
            config["channel"] = channel_value
            try:
                config["relay_label"] = format_relay_label(
                    board_value, channel_value
                )
            except ValueError as exc:  # pragma: no cover - defensive
                raise HTTPException(status_code=400, detail=str(exc)) from exc
            config.pop("bcm", None)
        else:
            bcm_raw = data.get("relay_bcm") or config.get("bcm")
            try:
                bcm_value = int(bcm_raw)
            except (TypeError, ValueError):
                raise HTTPException(
                    status_code=400, detail="Provide a valid BCM pin for GPIO relays."
                )
            config["bcm"] = bcm_value
            config.pop("board", None)
            config.pop("channel", None)
            config.pop("relay_label", None)

    elif kind in {"hydrometer", "sensor"}:
        sensor_type = str(
            data.get("sensor_type") or config.get("sensor_kind") or "hydrometer"
        ).lower()
        if sensor_type not in _SENSOR_TYPE_LABELS:
            raise HTTPException(status_code=400, detail="Unknown sensor type.")
        config["sensor_kind"] = sensor_type

        if sensor_type == "hydrometer":
            tilt_color = str(
                data.get("sensor_tilt_color")
                or config.get("tilt_color")
                or "blue"
            ).lower()
            if tilt_color not in _TILT_COLORS:
                raise HTTPException(status_code=400, detail="Select a valid Tilt color.")
            config["tilt_color"] = tilt_color

            raw_fields = data.get("sensor_fields")
            if isinstance(raw_fields, list):
                fields = _normalize_sensor_fields(raw_fields)
            elif isinstance(raw_fields, str):
                fields = _normalize_sensor_fields([raw_fields])
            else:
                fields = _normalize_sensor_fields(config.get("fields"))
            config["fields"] = fields

            for key in (
                "sensor_id",
                "flow_sensor_id",
                "flow_alias",
                "probe_id",
                "temp_probe_id",
                "alias",
                "temp_alias",
            ):
                config.pop(key, None)

        elif sensor_type == "flow":
            sensor_id = str(data.get("flow_sensor_id") or "").strip()
            alias = str(data.get("flow_alias") or "").strip()
            if not sensor_id and not alias:
                raise HTTPException(
                    status_code=400,
                    detail="Flow meters require a sensor ID or alias.",
                )
            if sensor_id:
                config["sensor_id"] = sensor_id
                config["flow_sensor_id"] = sensor_id
            else:
                config.pop("sensor_id", None)
                config.pop("flow_sensor_id", None)
            if alias:
                config["alias"] = alias
                config["flow_alias"] = alias
            else:
                config.pop("alias", None)
                config.pop("flow_alias", None)

            for key in ("tilt_color", "fields", "probe_id", "temp_probe_id", "temp_alias"):
                config.pop(key, None)

        elif sensor_type == "temp_probe":
            probe_id = str(data.get("temp_probe_id") or "").strip()
            alias = str(data.get("temp_alias") or "").strip()
            if not probe_id and not alias:
                raise HTTPException(
                    status_code=400,
                    detail="Temperature probes require an ID or alias.",
                )
            if probe_id:
                config["probe_id"] = probe_id
                config["temp_probe_id"] = probe_id
            else:
                config.pop("probe_id", None)
                config.pop("temp_probe_id", None)
            if alias:
                config["alias"] = alias
                config["temp_alias"] = alias
            else:
                config.pop("alias", None)
                config.pop("temp_alias", None)

            for key in ("tilt_color", "fields", "sensor_id", "flow_sensor_id", "flow_alias"):
                config.pop(key, None)
        else:  # pragma: no cover - defensive
            raise HTTPException(status_code=400, detail="Unsupported sensor type")

    elif kind == "weather":
        config = _normalize_weather_config(
            {
                "lat": data.get("weather_lat"),
                "lon": data.get("weather_lon"),
                "units": data.get("weather_units"),
                "refresh_min": data.get("weather_refresh"),
                "location_label": data.get("weather_location_label"),
            },
            existing=config,
        )

    elif kind in {"dummy", "dummy_relay", "dummy_data"}:
        selected_kind = str(
            data.get("dummy_kind") or widget.kind or config.get("dummy_kind") or "dummy_relay"
        ).strip().lower()
        if selected_kind in {"dummy", "dummy_relay"}:
            new_kind = "dummy_relay"
            config["dummy_kind"] = "relay"
            state_raw = data.get("dummy_state")
            if state_raw in (None, ""):
                state_value = _as_bool(config.get("state"), default=False)
            else:
                state_value = _as_bool(state_raw, default=False)
            config["state"] = state_value
            config.pop("value", None)
        elif selected_kind in {"dummy_data", "dummy_sensor", "data"}:
            new_kind = "dummy_data"
            config["dummy_kind"] = "data"
            value_raw = data.get("dummy_value")
            if value_raw is None:
                value_text = "" if config.get("value") is None else str(config.get("value"))
            else:
                value_text = str(value_raw)
            config["value"] = value_text
            config.pop("state", None)
        else:
            raise HTTPException(status_code=400, detail="Unknown dummy type.")

        widget.kind = new_kind
        config["dummy"] = True

    else:
        raise HTTPException(
            status_code=400,
            detail="This widget type cannot be edited via the modal yet.",
        )

    widget.slug = label
    widget.config_json = json.dumps(config)
    if hasattr(widget, "published_at"):
        widget.published_at = datetime.utcnow()

    try:
        session.add(widget)
        session.commit()
    except Exception:
        session.rollback()
        raise

    session.refresh(widget)

    payload = jsonable_encoder(widget)
    payload["config_json"] = config

    return {"ok": True, "widget": payload}


@router.post("/{widget_id}/dummy", response_class=HTMLResponse)
async def update_dummy_widget(
    widget_id: int,
    request: Request,
    session: Session = Depends(get_session),
):
    widget = session.get(Widget, widget_id)
    if not widget:
        raise HTTPException(status_code=404, detail="Widget not found")

    kind = (widget.kind or "").strip().lower()
    if kind not in {"dummy", "dummy_relay", "dummy_data", "dummy_sensor"}:
        raise HTTPException(status_code=400, detail="Widget is not a dummy tile.")

    payload = await _extract_request_data(request)
    config = _parse_config(widget)

    updated = False

    if "state" in payload:
        state_value = _as_bool(payload.get("state"), default=False)
        config["state"] = state_value
        config["dummy_kind"] = "relay"
        config["dummy"] = True
        config.pop("value", None)
        widget.kind = "dummy_relay"
        updated = True

    if "value" in payload:
        value_raw = payload.get("value")
        config["value"] = "" if value_raw is None else str(value_raw)
        config["dummy_kind"] = "data"
        config["dummy"] = True
        config.pop("state", None)
        widget.kind = "dummy_data"
        updated = True

    if not updated:
        raise HTTPException(status_code=400, detail="No dummy fields provided.")

    widget.config_json = json.dumps(config)
    if hasattr(widget, "published_at"):
        widget.published_at = datetime.utcnow()

    try:
        session.add(widget)
        session.commit()
    except Exception:
        session.rollback()
        raise

    session.refresh(widget)

    mode = request.query_params.get("mode", "view")
    context = _widget_context(widget, mode=mode)
    context["request"] = request
    return request.app.state.templates.TemplateResponse(
        "widgets/dummy.html", context
    )


@router.post("/{widget_id}/weather", response_class=HTMLResponse)
async def update_weather_widget(
    widget_id: int,
    request: Request,
    session: Session = Depends(get_session),
):
    widget = session.get(Widget, widget_id)
    if not widget:
        raise HTTPException(status_code=404, detail="Widget not found")

    kind = (widget.kind or "").strip().lower()
    if kind != "weather":
        raise HTTPException(status_code=400, detail="Widget is not a weather tile.")

    payload = await _extract_request_data(request)
    config = _parse_config(widget)

    manual: Dict[str, Any] = {}
    temp_raw = payload.get("manual_temp")
    if temp_raw not in (None, ""):
        try:
            manual_temp = float(temp_raw)
        except (TypeError, ValueError):
            manual_temp = str(temp_raw)
        manual["temp"] = manual_temp

    cond_code_raw = payload.get("manual_cond_code")
    cond_code: int | None
    if cond_code_raw in (None, ""):
        cond_code = None
    else:
        try:
            cond_code = int(cond_code_raw)
        except (TypeError, ValueError):
            raise HTTPException(status_code=400, detail="Condition code must be a number.") from None

    if cond_code is not None:
        manual["cond_code"] = cond_code

    cond_text_raw = str(payload.get("manual_cond_text") or "").strip()
    if not cond_text_raw and cond_code is not None:
        cond_text_raw = _WEATHER_CODE_LABELS.get(cond_code, "Manual condition")
    if cond_text_raw:
        manual["cond_text"] = cond_text_raw

    manual["is_day"] = _as_bool(payload.get("manual_is_day"), default=True)
    manual["updated_at"] = datetime.utcnow().isoformat()

    if not manual:
        raise HTTPException(status_code=400, detail="Provide manual weather details to inject.")

    config["manual_weather"] = manual

    widget.config_json = json.dumps(config)
    if hasattr(widget, "published_at"):
        widget.published_at = datetime.utcnow()

    try:
        session.add(widget)
        session.commit()
    except Exception:
        session.rollback()
        raise

    session.refresh(widget)

    mode = request.query_params.get("mode", "view")
    context = _widget_context(widget, mode=mode)
    context["request"] = request
    return request.app.state.templates.TemplateResponse(
        "widgets/weather.html", context
    )



@router.patch("/{widget_id}/config")
async def patch_widget_config(
    widget_id: int,
    request: Request,
    session: Session = Depends(get_session),
):
    widget = session.get(Widget, widget_id)
    if not widget:
        raise HTTPException(status_code=404, detail="Widget not found")

    content_type = request.headers.get("content-type", "")
    payload: Dict[str, Any]

    def coerce(value: Any) -> Any:
        if isinstance(value, str):
            text = value.strip()
            lowered = text.lower()
            if lowered in {"true", "false"}:
                return lowered == "true"
            if lowered in {"null", "none"}:
                return None
            if text == "":
                return ""
            try:
                return int(text)
            except (TypeError, ValueError):
                try:
                    return float(text)
                except (TypeError, ValueError):
                    return value
        return value

    if "application/json" in content_type:
        try:
            parsed = await request.json()
        except Exception as exc:  # pragma: no cover - defensive
            raise HTTPException(status_code=400, detail="Body must be JSON") from exc
        if not isinstance(parsed, dict):
            raise HTTPException(status_code=400, detail="Body must be an object")
        payload = parsed
    else:
        form = await request.form()
        payload = {key: coerce(value) for key, value in form.multi_items()}

    current = _parse_config(widget)
    updated = dict(current)
    updated.update(payload)

    kind_lower = (widget.kind or "").strip().lower()
    if kind_lower == "image":
        updated = _normalize_image_config(updated, existing=current)

    widget.config_json = json.dumps(updated)

    try:
        session.add(widget)
        session.commit()
    except Exception:
        session.rollback()
        raise

    session.refresh(widget)

    return {"ok": True, "config_json": updated}


@router.put("/{widget_id}")
def update_widget(
    widget_id: int,
    payload: Dict[str, Any],
    request: Request,
    session: Session = Depends(get_session),
):
    widget = session.get(Widget, widget_id)
    if not widget:
        raise HTTPException(status_code=404, detail="Widget not found")

    data = dict(payload)
    updates: Dict[str, Any] = {}

    if "config" in data and "config_json" not in data:
        config = data.pop("config")
        data["config_json"] = json.dumps(config if config is not None else {})

    if "slug" in data:
        slug = (data.get("slug") or "").strip()
        if not slug:
            raise HTTPException(status_code=400, detail="Slug cannot be empty")
        updates["slug"] = slug

    if "kind" in data:
        kind = (data.get("kind") or "").strip()
        if kind:
            updates["kind"] = kind

    if "config_json" in data:
        raw_config = data.get("config_json")
        if isinstance(raw_config, (dict, list)):
            parsed_config = raw_config
        else:
            raw_text = (raw_config or "").strip()
            if raw_text in ("", "null", "None"):
                parsed_config = {}
            else:
                try:
                    parsed_config = json.loads(raw_text)
                except (TypeError, json.JSONDecodeError) as exc:
                    raise HTTPException(
                        status_code=400,
                        detail="config_json must be valid JSON",
                    ) from exc

        target_kind = (updates.get("kind") or widget.kind or "").strip().lower()
        if target_kind == "image" and isinstance(parsed_config, dict):
            existing_config = _parse_config(widget)
            parsed_config = _normalize_image_config(parsed_config, existing=existing_config)

        updates["config_json"] = json.dumps(parsed_config)

    numeric_fields = {"x", "y", "w", "h", "draft_x", "draft_y", "draft_w", "draft_h"}
    for field in numeric_fields:
        if field in data:
            value = data.get(field)
            if value in (None, ""):
                updates[field] = None
                continue
            try:
                updates[field] = int(value)
            except (TypeError, ValueError) as exc:
                raise HTTPException(status_code=400, detail=f"{field} must be an integer") from exc

    if not updates:
        return widget

    try:
        for key, value in updates.items():
            if hasattr(widget, key):
                setattr(widget, key, value)
        if any(name in updates for name in ("x", "y", "w", "h")) and hasattr(widget, "published_at"):
            widget.published_at = datetime.utcnow()
        session.add(widget)
        session.commit()
        session.refresh(widget)
    except Exception:
        session.rollback()
        raise

    if request.headers.get("HX-Request") == "true":
        payload = jsonable_encoder(widget)
        response = JSONResponse(content=payload)
        response.headers["HX-Trigger"] = json.dumps({"widget-updated": {"id": widget.id}})
        return response

    return widget


@router.delete("/{widget_id}")
def delete_widget(widget_id: int, request: Request, session: Session = Depends(get_session)):
    widget = session.get(Widget, widget_id)
    if not widget:
        raise HTTPException(status_code=404, detail="Widget not found")

    try:
        session.delete(widget)
        session.commit()
    except Exception:
        session.rollback()
        raise

    result = {"ok": True, "deleted_id": widget_id}
    if request.headers.get("HX-Request") == "true":
        response = JSONResponse(content=result)
        response.headers["HX-Trigger"] = json.dumps({"widget-deleted": {"id": widget_id}})
        return response

    return result


def _coerce_int(value: Any, *, default: int, minimum: int) -> int:
    try:
        parsed = int(value)
    except (TypeError, ValueError):
        parsed = default
    if parsed < minimum:
        return minimum
    return parsed


def _parse_position_items(payload: Any) -> List[Dict[str, Any]]:
    if payload is None:
        return []
    data = payload
    if isinstance(data, (bytes, bytearray)):
        data = data.decode("utf-8", "ignore")
    if isinstance(data, str):
        text = data.strip()
        if text == "":
            return []
        try:
            parsed = json.loads(text)
        except json.JSONDecodeError as exc:
            raise HTTPException(status_code=400, detail="Invalid layout payload") from exc
        data = parsed
    if isinstance(data, dict):
        if "positions" in data:
            return _parse_position_items(data.get("positions"))
        raise HTTPException(status_code=400, detail="Invalid layout payload")
    if not isinstance(data, list):
        raise HTTPException(status_code=400, detail="Invalid layout payload")

    items: List[Dict[str, Any]] = []
    for item in data:
        if isinstance(item, dict):
            items.append(item)
    return items


def _apply_position_updates(
    session: Session,
    updates: List[Dict[str, Any]],
    *,
    use_draft: bool,
) -> int:
    if not updates:
        return 0

    supports_draft = all(
        hasattr(Widget, field) for field in ("draft_x", "draft_y", "draft_w", "draft_h")
    )
    stamp = datetime.utcnow()
    total = 0

    for item in updates:
        try:
            widget_id = int(item.get("id"))
        except (TypeError, ValueError):
            continue
        if widget_id <= 0:
            continue

        widget = session.get(Widget, widget_id)
        if not widget:
            continue

        x = _coerce_int(item.get("x"), default=getattr(widget, "x", 0) or 0, minimum=0)
        y = _coerce_int(item.get("y"), default=getattr(widget, "y", 0) or 0, minimum=0)
        w = _coerce_int(item.get("w"), default=getattr(widget, "w", 1) or 1, minimum=1)
        h = _coerce_int(item.get("h"), default=getattr(widget, "h", 1) or 1, minimum=1)

        if use_draft and supports_draft:
            changed = False
            if getattr(widget, "draft_x", None) != x:
                widget.draft_x = x
                changed = True
            if getattr(widget, "draft_y", None) != y:
                widget.draft_y = y
                changed = True
            if getattr(widget, "draft_w", None) != w:
                widget.draft_w = w
                changed = True
            if getattr(widget, "draft_h", None) != h:
                widget.draft_h = h
                changed = True
            if changed:
                session.add(widget)
                total += 1
            continue

        widget.x = x
        widget.y = y
        widget.w = w
        widget.h = h
        widget.published_at = stamp

        if supports_draft:
            if getattr(widget, "draft_x", None) is not None:
                widget.draft_x = None
            if getattr(widget, "draft_y", None) is not None:
                widget.draft_y = None
            if getattr(widget, "draft_w", None) is not None:
                widget.draft_w = None
            if getattr(widget, "draft_h", None) is not None:
                widget.draft_h = None

        session.add(widget)
        total += 1

    return total


@router.post("/pos")
async def save_positions(
    request: Request,
    session: Session = Depends(get_session),
):
    content_type = (request.headers.get("content-type") or "").lower()
    raw_payload: Any
    if "application/json" in content_type:
        try:
            raw_payload = await request.json()
        except json.JSONDecodeError as exc:
            raise HTTPException(status_code=400, detail="Invalid layout payload") from exc
    elif "application/x-www-form-urlencoded" in content_type or "multipart/form-data" in content_type:
        form = await request.form()
        raw_payload = form.get("positions")
    else:
        body_bytes = await request.body()
        raw_payload = body_bytes if body_bytes else None

    items = _parse_position_items(raw_payload)

    supports_draft = all(
        hasattr(Widget, field) for field in ("draft_x", "draft_y", "draft_w", "draft_h")
    )
    wants_draft = request.query_params.get("draft", "").lower() in {"1", "true", "yes"}
    use_draft = supports_draft and wants_draft

    try:
        updated = _apply_position_updates(session, items, use_draft=use_draft)
        session.commit()
    except HTTPException:
        raise
    except Exception:
        session.rollback()
        raise

    return {"ok": True, "updated": updated, "draft": use_draft}


@router.get("/ui", response_class=HTMLResponse)
def widgets_ui(request: Request):
    templates = request.app.state.templates
    return templates.TemplateResponse("tools_widgets.html", {"request": request})


@tools_router.get("/widgets", include_in_schema=False)
def _tools_widgets_alias():
    return RedirectResponse(url="/widgets/ui", status_code=307)
