from __future__ import annotations
from fastapi import APIRouter, Depends, Request
from fastapi.responses import HTMLResponse, JSONResponse
from pydantic import BaseModel
from sqlmodel import select
from datetime import datetime
from html import escape
from ..db import get_session, Session
from ..models import HydrometerLatest
from ..services.tilt_scanner import TiltScannerService
from ..services.weather import WeatherService

router = APIRouter(prefix="/sensors", tags=["sensors"])

weather_service = WeatherService()


def _latest_record(session: Session, color: str) -> dict[str, object | None]:
    normalized = color.lower()
    row = session.exec(select(HydrometerLatest).where(HydrometerLatest.color == normalized)).first()
    if not row:
        return {"color": normalized, "temp_f": None, "sg": None, "updated_at": None}
    return {
        "color": row.color,
        "temp_f": row.temp_f,
        "sg": row.sg,
        "updated_at": row.updated_at.isoformat() if row.updated_at else None,
    }


def _tilt_scanner_state(
    request: Request, scanner: TiltScannerService | None = None
) -> dict[str, object]:
    if scanner is None:
        scanner = getattr(request.app.state, "tilt_scanner", None)

    status_data = getattr(request.app.state, "tilt_ble_status", {}) or {}
    last_seen: dict[str, str] = {}
    for color, data in status_data.items():
        if isinstance(data, dict):
            timestamp = data.get("ts")
            if isinstance(timestamp, str):
                last_seen[color] = timestamp

    env_enabled = bool(getattr(request.app.state, "tilt_ble_env_enabled", False))
    runtime_override = bool(getattr(request.app.state, "tilt_ble_runtime_override", False))

    running = False
    notes: list[str] = []
    if not scanner:
        notes.append("Tilt scanner not initialized.")
    else:
        running = scanner.is_active()
        import_error = getattr(scanner, "import_error", None)
        if import_error:
            notes.append(f"BLE unavailable: {import_error}")
        else:
            last_error = getattr(scanner, "last_error", None)
            if last_error and not running:
                notes.append(str(last_error))
            if running:
                notes.append("Tilt scanner running.")
            else:
                notes.append("Tilt scanner idle.")

    if env_enabled:
        if not running:
            notes.append("TILT_BLE_ENABLE=1 configured.")
    else:
        if running:
            notes.append("Running via runtime override (TILT_BLE_ENABLE not set).")
        elif runtime_override:
            notes.append("Runtime override requested (TILT_BLE_ENABLE not set).")
        else:
            notes.append("Tilt scanner disabled by default (TILT_BLE_ENABLE not set).")

    deduped_notes: list[str] = []
    seen_notes: set[str] = set()
    for note in notes:
        if not note or note in seen_notes:
            continue
        deduped_notes.append(note)
        seen_notes.add(note)

    if not deduped_notes:
        deduped_notes.append("Tilt scanner status unavailable.")

    return {
        "running": running,
        "last_seen": last_seen,
        "notes": deduped_notes,
    }


class TiltIngest(BaseModel):
    color: str
    temp_f: float
    sg: float

@router.post("/tilt/ingest")
def ingest_tilt(payload: TiltIngest, session: Session = Depends(get_session)):
    color = payload.color.lower()
    stmt = select(HydrometerLatest).where(HydrometerLatest.color == color)
    row = session.exec(stmt).first()
    if not row:
        row = HydrometerLatest(color=color, temp_f=payload.temp_f, sg=payload.sg, updated_at=datetime.utcnow())
        session.add(row)
    else:
        row.temp_f = payload.temp_f
        row.sg = payload.sg
        row.updated_at = datetime.utcnow()
    session.commit()
    return {"ok": True, "latest": {"color": row.color, "temp_f": row.temp_f, "sg": row.sg, "updated_at": row.updated_at.isoformat()}}


@router.get("/tilt/scanner/status")
async def tilt_scanner_status(request: Request):
    return _tilt_scanner_state(request)


@router.post("/tilt/scanner/enable")
async def tilt_scanner_enable(request: Request):
    scanner: TiltScannerService | None = getattr(request.app.state, "tilt_scanner", None)
    if not scanner:
        payload = _tilt_scanner_state(request, None)
        payload["ok"] = False
        return JSONResponse(payload, status_code=503)

    request.app.state.tilt_ble_runtime_override = True
    await scanner.start()
    payload = _tilt_scanner_state(request, scanner)
    payload["ok"] = bool(payload.get("running"))
    status_code = 200 if payload["ok"] else 503
    return JSONResponse(payload, status_code=status_code)


@router.post("/tilt/scanner/disable")
async def tilt_scanner_disable(request: Request):
    scanner: TiltScannerService | None = getattr(request.app.state, "tilt_scanner", None)
    request.app.state.tilt_ble_runtime_override = False
    if not scanner:
        payload = _tilt_scanner_state(request, None)
        payload["ok"] = True
        return JSONResponse(payload)

    await scanner.stop()
    payload = _tilt_scanner_state(request, scanner)
    payload["ok"] = True
    return JSONResponse(payload)


@router.post("/tilt/scanner/scan-once")
async def tilt_scanner_scan_once(request: Request):
    scanner = getattr(request.app.state, "tilt_scanner", None)
    if not scanner:
        return {
            "ok": False,
            "counts": {"total": 0, "colors": {}},
            "running": False,
            "note": "Tilt scanner not initialized.",
        }

    result = await scanner.scan_once()
    env_enabled = bool(getattr(request.app.state, "tilt_ble_env_enabled", False))
    runtime_override = bool(getattr(request.app.state, "tilt_ble_runtime_override", False))
    if not env_enabled and not runtime_override:
        suffix = "background scanner disabled"
        note = result.get("note")
        if note:
            result["note"] = f"{note}; {suffix}"
        else:
            result["note"] = suffix
    return result


class DummyIngest(BaseModel):
    widget_id: int | None = None
    color: str | None = None
    temp_f: float | None = None
    sg: float | None = None


@router.post("/dummy/ingest")
def ingest_dummy(payload: DummyIngest, session: Session = Depends(get_session)):
    """Persist synthetic hydrometer readings for dummy sensor tiles."""

    base_color = (payload.color or "").strip().lower()
    if not base_color:
        base_color = f"dummy-{payload.widget_id}" if payload.widget_id else "dummy"
    if base_color == "dummy" and payload.widget_id:
        color = f"dummy-{payload.widget_id}"
    else:
        color = base_color
    row = session.exec(select(HydrometerLatest).where(HydrometerLatest.color == color)).first()
    if not row:
        row = HydrometerLatest(color=color)
        session.add(row)

    if payload.temp_f is not None:
        row.temp_f = payload.temp_f
    if payload.sg is not None:
        row.sg = payload.sg
    row.updated_at = datetime.utcnow()

    session.commit()
    latest = {
        "color": row.color,
        "temp_f": row.temp_f,
        "sg": row.sg,
        "updated_at": row.updated_at.isoformat(),
    }
    return {"ok": True, "latest": latest}


class WeatherQuery(BaseModel):
    lat: float
    lon: float
    units: str = "us"
    refresh_min: int | None = None


@router.get("/weather/latest")
async def weather_latest(query: WeatherQuery = Depends()):
    data = await weather_service.get_latest(
        lat=query.lat,
        lon=query.lon,
        units=query.units,
        refresh_min=query.refresh_min or 10,
    )
    return {"ok": True, "data": data}


@router.post("/weather/refresh")
async def weather_refresh(payload: WeatherQuery):
    data = await weather_service.get_latest(
        lat=payload.lat,
        lon=payload.lon,
        units=payload.units,
        refresh_min=payload.refresh_min or 10,
        force=True,
    )
    return {"ok": True, "data": data}


@router.get("/tilt/latest/{color}", response_class=HTMLResponse)
def tilt_latest_fragment(
    color: str,
    request: Request,
    fields: str | None = None,
    session: Session = Depends(get_session),
):
    normalized = (color or "").strip().lower()
    requested_fields: list[str] = []
    if fields:
        requested_fields = [
            chunk.strip().lower()
            for chunk in fields.split(",")
            if chunk.strip()
        ]

    allowed_fields = ["sg", "temp_f"]
    filtered_fields = [
        field for field in requested_fields if field in allowed_fields
    ]
    if not filtered_fields:
        filtered_fields = allowed_fields.copy()

    mode_param = request.query_params.get("mode")
    accept_header = request.headers.get("accept", "")
    wants_json = mode_param == "json" or (
        mode_param != "html" and "application/json" in accept_header
    )

    record = _latest_record(session, normalized)

    if wants_json:
        payload = {
            "color": record.get("color"),
            "updated_at": record.get("updated_at"),
        }
        for field in allowed_fields:
            payload[field] = record.get(field)
        return JSONResponse({"ok": True, "data": payload})

    def format_value(name: str, value: object | None) -> tuple[str, str]:
        if name == "sg":
            label = "Specific Gravity"
            if value is None:
                return label, "—"
            try:
                return label, f"{float(value):.4f}"
            except (TypeError, ValueError):
                return label, str(value)
        if name == "temp_f":
            label = "Temperature"
            if value is None:
                return label, "—"
            try:
                return label, f"{float(value):.1f} °F"
            except (TypeError, ValueError):
                return label, str(value)
        label = name.replace("_", " ").title()
        return label, "—" if value is None else str(value)

    entries: list[tuple[str, str]] = []
    for field in filtered_fields:
        label, display = format_value(field, record.get(field))
        entries.append((label, display))

    has_data = any(
        record.get(field) is not None for field in filtered_fields
    )

    if not has_data:
        return HTMLResponse(
            '<div class="text-xs text-slate-500">No recent readings</div>'
        )

    parts: list[str] = []
    for label, display in entries:
        parts.append(
            """
<div class=\"flex flex-col gap-0.5\">
  <span class=\"text-[11px] uppercase tracking-wide text-slate-500\">{label}</span>
  <span class=\"text-lg font-semibold text-sky-200\">{display}</span>
</div>
""".format(label=escape(label), display=escape(display))
        )

    updated_at = record.get("updated_at")
    if updated_at:
        parts.append(
            """
<div class=\"text-[10px] text-slate-500\">Updated {stamp}</div>
""".format(stamp=escape(str(updated_at)))
        )

    html = '<div class="flex flex-col gap-1">' + "".join(parts) + "</div>"
    return HTMLResponse(html)


@router.get("/hydrometer/latest/{color}")
def latest(color: str, session: Session = Depends(get_session)):
    return _latest_record(session, color)

    if not body_parts:
        body_parts.append('<div class="text-sm text-slate-300">—</div>')

    html = '<div class="flex flex-col gap-1">' + "".join(body_parts) + "</div>"
    return HTMLResponse(html)


@router.get("/hydrometer/latest/{color}")
def latest(color: str, session: Session = Depends(get_session)):
    return _latest_record(session, color)

@router.get("/ui", response_class=HTMLResponse)
def sensors_ui():
    return """
<!doctype html>
<html>
<head>
  <meta charset="utf-8"/>
  <meta name="viewport" content="width=device-width,initial-scale=1"/>
  <title>BevForge - Hydrometer Monitor</title>
  <style>
    :root { color-scheme: dark; }
    body { font-family: system-ui, -apple-system, Segoe UI, Roboto, sans-serif;
           background:#0b0f1a; color:#e6e9ef; margin:0; padding:1rem; }
    h1 { font-size:1.1rem; margin:0 0 .75rem 0; }
    .row { display:flex; flex-wrap:wrap; gap:.75rem; align-items:center; }
    .card { border:1px solid #1e2842; border-radius:.75rem; padding:.75rem; }
    .grid { display:grid; grid-template-columns: repeat(auto-fit,minmax(180px,1fr)); gap:.75rem; }
    .muted { opacity:.75; font-size:.9rem; }
    input,select,button { background:#111726; border:1px solid #1e2842; color:#e6e9ef;
                          padding:.45rem .6rem; border-radius:.5rem; }
    button:hover { background:#15203a; cursor:pointer; }
    .accent { border-color:#4158d0; }
    table { width:100%; border-collapse:collapse; }
    th,td { border-bottom:1px solid #1e2842; padding:.4rem; text-align:left; }
  </style>
</head>
<body>
  <h1>Hydrometer Monitor</h1>

  <div class="row">
    <button id="refresh" class="accent">Refresh</button>
    <span class="muted">Shows latest from /sensors/hydrometer/latest/{color}</span>
  </div>

  <div class="grid" style="margin-top:.75rem">
    <div class="card"><div class="muted">red</div><table><tbody id="red"></tbody></table></div>
    <div class="card"><div class="muted">green</div><table><tbody id="green"></tbody></table></div>
    <div class="card"><div class="muted">blue</div><table><tbody id="blue"></tbody></table></div>
    <div class="card"><div class="muted">purple</div><table><tbody id="purple"></tbody></table></div>
  </div>

  <div class="card" style="margin-top:1rem">
    <div class="row">
      <strong>Inject Test Reading</strong>
      <select id="color">
        <option>red</option><option>green</option><option>blue</option><option>purple</option>
      </select>
      <input id="temp" type="number" step="0.1" placeholder="temp F" style="width:8rem"/>
      <input id="sg" type="number" step="0.001" placeholder="SG" style="width:8rem"/>
      <button id="send" class="accent">Send</button>
      <span class="muted">POST /sensors/tilt/ingest</span>
    </div>
  </div>

<script>
async function latest(color){
  try{
    const r = await fetch("/sensors/hydrometer/latest/"+color);
    if(!r.ok) return null;
    return await r.json();
  }catch{ return null; }
}
function renderRow(el, data){
  el.innerHTML = "";
  if(!data || !Object.keys(data).length){
    el.innerHTML = "<tr><td class='muted'>no data</td></tr>";
    return;
  }
  const rows = [];
  for(const [k,v] of Object.entries(data)){
    rows.push("<tr><th>"+k+"</th><td>"+v+"</td></tr>");
  }
  el.innerHTML = rows.join("");
}
async function load(){
  for(const c of ["red","green","blue","purple"]){
    const data = await latest(c);
    renderRow(document.getElementById(c), data);
  }
}
addEventListener("click", async (e)=>{
  const b = e.target.closest("button");
  if(!b) return;
  if(b.id==="refresh") return void load();
  if(b.id==="send"){
    const color = document.getElementById("color").value;
    const temp  = parseFloat(document.getElementById("temp").value || "0");
    const sg    = parseFloat(document.getElementById("sg").value || "0");
    try{
      await fetch("/sensors/tilt/ingest", {
        method:"POST", headers: {"Content-Type":"application/json"},
        body: JSON.stringify({color: color, temp_f: temp || null, sg: sg || null})
      });
      await load();
      alert("Reading injected.");
    }catch(err){
      alert("Error: "+err.message);
    }
  }
});
load();
</script>
</body>
</html>
    """
