from __future__ import annotations

import asyncio
import json
import logging
import time
from collections import defaultdict
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Tuple

from fastapi import APIRouter, Depends, Form, HTTPException, Query, Request
from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse
from pydantic import BaseModel
from sqlmodel import Field, Session, SQLModel, select, text

from ..db import engine, get_session, session_factory
from ..models import (
    Automation,
    AutomationGraph,
    AutomationLink,
    AutomationNode,
    AutomationRule,
    HydrometerLatest,
    Widget,
)
from ..services.pumps import pump_manager
from ..utils.basic_auth import require_basic_auth, require_editor_role

log_auto = logging.getLogger("bevforge.automations")
router = APIRouter(prefix="/automations", tags=["automations"])

# ------------------------- Schemas -------------------------
class RuleIn(SQLModel):
    kind: str
    label: Optional[str] = ""
    config: Dict[str, Any]

class RuleUpdateIn(BaseModel):
    label: str | None = None
    config: dict | None = None
    enabled: bool | None = None

class RuleUpdate(SQLModel):
    label: Optional[str] = None
    config: Optional[Dict[str, Any]] = None
    enabled: Optional[bool] = None


class GraphNodeIn(BaseModel):
    widget_id: int


class GraphLinkIn(BaseModel):
    src_widget_id: int
    dst_widget_id: int
    kind: Optional[str] = None


class GraphLinkUpdate(BaseModel):
    src_widget_id: Optional[int] = None
    dst_widget_id: Optional[int] = None
    kind: Optional[str] = None


class GraphLayoutIn(BaseModel):
    layout: Dict[str, Dict[str, float]]


def _parse_config(raw: str | Dict[str, Any] | None) -> Dict[str, Any]:
    if isinstance(raw, dict):
        return dict(raw)
    if not raw:
        return {}
    try:
        return json.loads(raw)
    except (TypeError, json.JSONDecodeError):
        return {}


def _widget_label(widget: Widget, config: Dict[str, Any]) -> str:
    label = (
        config.get("label")
        or config.get("title")
        or config.get("name")
        or widget.slug
        or f"Widget #{widget.id}"
    )
    return str(label)


def _widget_secondary(widget: Widget, config: Dict[str, Any]) -> str:
    kind = (widget.kind or "").lower()
    dummy_kind = (config.get("dummy_kind") or "").lower()
    if dummy_kind:
        return f"Dummy {dummy_kind}"
    if kind in {"pump", "valve"}:
        backend = config.get("backend") or config.get("device_backend") or config.get("device_kind")
        if backend:
            return f"Backend: {backend}"
    if kind in {"hydrometer", "sensor"} or config.get("sensor_kind"):
        color = (
            config.get("color")
            or config.get("tilt_color")
            or config.get("slug")
            or config.get("hydro_color")
        )
        if color:
            return f"Color: {str(color).upper()}"
    binding = config.get("binding") or config.get("state_binding")
    if isinstance(binding, dict):
        btype = binding.get("type") or binding.get("kind")
        if btype:
            return f"Binding: {btype}"
    elif binding:
        return f"Binding: {binding}"
    return ""


def _widget_category(widget: Widget, config: Dict[str, Any]) -> str:
    kind = (widget.kind or "").lower()
    dummy_kind = (config.get("dummy_kind") or "").lower()
    if dummy_kind or kind.startswith("dummy"):
        return "dummy"
    if kind in {"pump", "valve"} or config.get("device_kind") or config.get("pump_widget_id"):
        return "devices"
    if kind in {"hydrometer", "sensor"} or config.get("sensor_kind"):
        return "sensors"
    if kind.startswith("automation"):
        return "automation"
    return "automation"


def _summarize_widget(widget: Widget) -> Dict[str, Any]:
    config = _parse_config(widget.config_json)
    summary = {
        "id": widget.id,
        "slug": widget.slug,
        "kind": widget.kind,
        "label": _widget_label(widget, config),
        "detail": _widget_secondary(widget, config),
        "config": config,
    }
    summary["category"] = _widget_category(widget, config)
    return summary


def _ensure_graph(session: Session, automation: Automation) -> AutomationGraph:
    graph = session.exec(
        select(AutomationGraph).where(AutomationGraph.automation_id == automation.id)
    ).first()
    if graph:
        return graph
    graph = AutomationGraph(automation_id=automation.id)
    session.add(graph)
    session.commit()
    session.refresh(graph)
    return graph


def _serialize_node(node: AutomationNode, summary: Dict[str, Any] | None) -> Dict[str, Any]:
    return {
        "id": node.id,
        "graph_id": node.graph_id,
        "widget_id": node.widget_id,
        "widget": summary or {},
    }


def _serialize_link(link: AutomationLink) -> Dict[str, Any]:
    return {
        "id": link.id,
        "graph_id": link.graph_id,
        "src_widget_id": link.src_widget_id,
        "dst_widget_id": link.dst_widget_id,
        "kind": link.kind,
    }


def _extract_layout(automation: Automation) -> Dict[int, Dict[str, float]]:
    config = _parse_config(automation.config_json)
    layout_raw = config.get("graph_layout")
    layout: Dict[int, Dict[str, float]] = {}
    if isinstance(layout_raw, dict):
        for key, value in layout_raw.items():
            try:
                node_id = int(key)
            except (TypeError, ValueError):
                continue
            if not isinstance(value, dict):
                continue
            try:
                x = float(value.get("x", 0))
                y = float(value.get("y", 0))
            except (TypeError, ValueError):
                continue
            layout[node_id] = {"x": x, "y": y}
    return layout


def _store_layout(session: Session, automation: Automation, layout: Dict[int, Dict[str, float]]) -> None:
    config = _parse_config(automation.config_json)
    serializable = {
        str(node_id): {"x": float(pos.get("x", 0.0)), "y": float(pos.get("y", 0.0))}
        for node_id, pos in layout.items()
    }
    config["graph_layout"] = serializable
    automation.config_json = json.dumps(config)
    session.add(automation)
    session.commit()
    session.refresh(automation)


def _build_graph_payload(
    session: Session,
    automation: Automation,
    summaries: Dict[int, Dict[str, Any]],
) -> Tuple[AutomationGraph, Dict[str, Any]]:
    graph = _ensure_graph(session, automation)
    nodes = session.exec(
        select(AutomationNode).where(AutomationNode.graph_id == graph.id).order_by(AutomationNode.id)
    ).all()
    links = session.exec(
        select(AutomationLink).where(AutomationLink.graph_id == graph.id).order_by(AutomationLink.id)
    ).all()
    layout = _extract_layout(automation)
    payload = {
        "id": graph.id,
        "nodes": [_serialize_node(node, summaries.get(node.widget_id)) for node in nodes],
        "links": [_serialize_link(link) for link in links],
        "layout": {str(node_id): pos for node_id, pos in layout.items()},
    }
    return graph, payload


def _group_widget_summaries(summaries: Dict[int, Dict[str, Any]]) -> List[Dict[str, Any]]:
    buckets: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
    for summary in summaries.values():
        category = summary.get("category") or "automation"
        buckets[category].append(summary)

    for items in buckets.values():
        items.sort(key=lambda item: (item.get("label") or "", item.get("slug") or ""))

    order = [
        ("devices", "Devices"),
        ("sensors", "Sensors"),
        ("dummy", "Test dummies"),
        ("automation", "Automation & logic"),
    ]
    groups: List[Dict[str, Any]] = []
    for key, label in order:
        items = buckets.get(key)
        if items:
            groups.append({"key": key, "label": label, "items": items})
    return groups


def _is_sensor_widget(widget: Widget, config: Dict[str, Any]) -> bool:
    kind = (widget.kind or "").lower()
    if kind in {"hydrometer", "sensor"}:
        return True
    if (config.get("sensor_kind") or "").lower():
        return True
    if (config.get("dummy_kind") or "").lower() == "sensor":
        return True
    return False


def _is_device_widget(widget: Widget, config: Dict[str, Any]) -> bool:
    kind = (widget.kind or "").lower()
    if kind in {"pump", "valve"}:
        return True
    if (config.get("device_kind") or "").lower() in {"pump", "valve", "relay"}:
        return True
    if (config.get("dummy_kind") or "").lower() in {"relay", "device"}:
        return True
    return False


def _sensor_color(widget: Widget, config: Dict[str, Any]) -> Optional[str]:
    color = (
        config.get("color")
        or config.get("tilt_color")
        or config.get("slug")
        or config.get("hydro_color")
        or config.get("dummy_color")
    )
    if not color and (config.get("dummy") or config.get("dummy_kind")):
        color = f"dummy-{widget.id}"
    if isinstance(color, str) and color.strip():
        return color.strip().lower()
    return None


def _thresholds_from_config(config: Dict[str, Any]) -> Tuple[float, float]:
    hysteresis = config.get("hysteresis")
    if isinstance(hysteresis, dict):
        config = {**config, **hysteresis}

    def _pick(values: List[Any], default: float) -> float:
        for value in values:
            if value is None:
                continue
            try:
                return float(value)
            except (TypeError, ValueError):
                continue
        return float(default)

    on_candidates = [
        config.get("on_above"),
        config.get("high"),
        config.get("threshold_high"),
        config.get("target_high"),
        config.get("max"),
    ]
    off_candidates = [
        config.get("off_below"),
        config.get("low"),
        config.get("threshold_low"),
        config.get("target_low"),
        config.get("min"),
    ]
    on_value = _pick(on_candidates, 72.0)
    off_value = _pick(off_candidates, on_value - 2.0)
    if off_value >= on_value:
        off_value = on_value - 2.0
    return on_value, off_value


def _maybe_float(value: Any) -> Optional[float]:
    try:
        result = float(value)
    except (TypeError, ValueError):
        return None
    return result


def _synthesize_rules(session: Session, automation: Automation, graph: AutomationGraph) -> int:
    nodes = session.exec(
        select(AutomationNode).where(AutomationNode.graph_id == graph.id)
    ).all()
    if not nodes:
        existing = session.exec(
            select(AutomationRule).where(AutomationRule.automation_id == automation.id)
        ).all()
        for rule in existing:
            session.delete(rule)
        session.commit()
        return 0
    widget_ids = {node.widget_id for node in nodes}

    widgets = session.exec(select(Widget).where(Widget.id.in_(widget_ids))).all()
    widget_map = {widget.id: widget for widget in widgets}
    config_map = {widget.id: _parse_config(widget.config_json) for widget in widgets}

    links = session.exec(
        select(AutomationLink).where(AutomationLink.graph_id == graph.id)
    ).all()

    existing_rules = session.exec(
        select(AutomationRule).where(AutomationRule.automation_id == automation.id)
    ).all()
    for rule in existing_rules:
        session.delete(rule)

    created = 0
    for link in links:
        src_widget = widget_map.get(link.src_widget_id)
        dst_widget = widget_map.get(link.dst_widget_id)
        if not src_widget or not dst_widget:
            continue
        src_config = config_map.get(src_widget.id, {})
        dst_config = config_map.get(dst_widget.id, {})
        if not _is_sensor_widget(src_widget, src_config):
            continue
        if not _is_device_widget(dst_widget, dst_config):
            continue
        color = _sensor_color(src_widget, src_config)
        if not color:
            continue
        on_above, off_below = _thresholds_from_config(src_config)
        rule_config: Dict[str, Any] = {
            "color": color,
            "on_above": on_above,
            "off_below": off_below,
            "pump_widget_id": dst_widget.id,
        }
        if src_config.get("units"):
            rule_config["units"] = src_config.get("units")
        min_on = _maybe_float(src_config.get("min_on_secs") or dst_config.get("min_on_secs"))
        min_off = _maybe_float(src_config.get("min_off_secs") or dst_config.get("min_off_secs"))
        if min_on is not None:
            rule_config["min_on_secs"] = min_on
        if min_off is not None:
            rule_config["min_off_secs"] = min_off

        label = f"{_widget_label(src_widget, src_config)} → {_widget_label(dst_widget, dst_config)}"
        kind = (link.kind or "").strip() or "hydro_temp_pump"
        rule = AutomationRule(
            automation_id=automation.id,
            kind=kind,
            label=label,
            config_json=json.dumps(rule_config),
            enabled=True,
            created_at=datetime.now(timezone.utc),
        )
        session.add(rule)
        created += 1

    session.commit()
    log_auto.info(
        "Synthesized %s automation rule(s) for automation %s graph %s",
        created,
        automation.id,
        graph.id,
    )
    return created



# ------------------------- Automations -------------------------
@router.get("")
def list_automations(session: Session = Depends(get_session)) -> List[Automation]:
    return session.exec(select(Automation).order_by(Automation.id)).all()

@router.post("")
def create_automation(
    label: Optional[str] = Query(default=None),
    body: Optional[Dict[str, Any]] = None,
    session: Session = Depends(get_session),
):
    if body and isinstance(body, dict):
        label = body.get("label", label)
        cfg = body.get("config") or {}
    else:
        cfg = {}
    if not label:
        raise HTTPException(status_code=422, detail="label is required")

    a = Automation(
        label=label,
        config_json=json.dumps(cfg),
        created_at=datetime.now(timezone.utc),
    )
    session.add(a); session.commit(); session.refresh(a)
    return a

@router.delete("/{automation_id}")
def delete_automation(automation_id: int, session: Session = Depends(get_session)):
    a = session.get(Automation, automation_id)
    if not a:
        raise HTTPException(404, f"automation {automation_id} not found")
    for r in session.exec(select(AutomationRule).where(AutomationRule.automation_id == automation_id)).all():
        session.delete(r)
    session.delete(a); session.commit()
    return {"ok": True, "deleted_id": automation_id}


# ------------------------- Graph Editor -------------------------
@router.get(
    "/edit",
    response_class=HTMLResponse,
    include_in_schema=False,
    dependencies=[Depends(require_basic_auth)],
)
def edit_automation_graph(
    request: Request,
    automation_id: Optional[int] = Query(default=None),
    session: Session = Depends(get_session),
    _: None = Depends(require_editor_role),
):
    automations = session.exec(select(Automation).order_by(Automation.id)).all()
    if not automations:
        default = Automation(
            label="Automation 1",
            config_json=json.dumps({}),
            created_at=datetime.now(timezone.utc),
        )
        session.add(default)
        session.commit()
        session.refresh(default)
        automations = [default]

    selected = None
    if automation_id is not None:
        for candidate in automations:
            if candidate.id == automation_id:
                selected = candidate
                break
    if selected is None:
        selected = automations[0]

    summaries = {
        widget.id: _summarize_widget(widget)
        for widget in session.exec(select(Widget).order_by(Widget.slug, Widget.id)).all()
    }
    groups = _group_widget_summaries(summaries)
    graph, graph_payload = _build_graph_payload(session, selected, summaries)

    context = {
        "request": request,
        "automations": automations,
        "selected_automation": selected,
        "graph": graph_payload,
        "widget_groups": groups,
        "widget_catalog": summaries,
    }
    return request.app.state.templates.TemplateResponse("automations_edit.html", context)


@router.get("/{automation_id}/graph", dependencies=[Depends(require_basic_auth)])
def get_automation_graph(
    automation_id: int,
    session: Session = Depends(get_session),
    _: None = Depends(require_editor_role),
):
    automation = session.get(Automation, automation_id)
    if not automation:
        raise HTTPException(status_code=404, detail="Automation not found")
    summaries = {
        widget.id: _summarize_widget(widget)
        for widget in session.exec(select(Widget)).all()
    }
    graph, payload = _build_graph_payload(session, automation, summaries)
    return {
        "automation": {"id": automation.id, "label": automation.label},
        "graph": payload,
    }


@router.post(
    "/{automation_id}/graph/nodes",
    dependencies=[Depends(require_basic_auth)],
)
def create_graph_node(
    automation_id: int,
    payload: GraphNodeIn,
    session: Session = Depends(get_session),
    _: None = Depends(require_editor_role),
):
    automation = session.get(Automation, automation_id)
    if not automation:
        raise HTTPException(status_code=404, detail="Automation not found")
    graph = _ensure_graph(session, automation)
    widget = session.get(Widget, payload.widget_id)
    if not widget:
        raise HTTPException(status_code=404, detail="Widget not found")
    existing = session.exec(
        select(AutomationNode)
        .where(AutomationNode.graph_id == graph.id)
        .where(AutomationNode.widget_id == widget.id)
    ).first()
    summary = _summarize_widget(widget)
    if existing:
        return {
            "node": _serialize_node(existing, summary),
            "graph_id": graph.id,
            "existing": True,
        }
    node = AutomationNode(graph_id=graph.id, widget_id=widget.id)
    session.add(node)
    session.commit()
    session.refresh(node)
    return {"node": _serialize_node(node, summary), "graph_id": graph.id}


@router.delete(
    "/{automation_id}/graph/nodes/{node_id}",
    dependencies=[Depends(require_basic_auth)],
)
def delete_graph_node(
    automation_id: int,
    node_id: int,
    session: Session = Depends(get_session),
    _: None = Depends(require_editor_role),
):
    automation = session.get(Automation, automation_id)
    if not automation:
        raise HTTPException(status_code=404, detail="Automation not found")
    graph = _ensure_graph(session, automation)
    node = session.get(AutomationNode, node_id)
    if not node or node.graph_id != graph.id:
        raise HTTPException(status_code=404, detail="Node not found")

    links = session.exec(
        select(AutomationLink).where(AutomationLink.graph_id == graph.id)
    ).all()
    removed_links: List[int] = []
    for link in links:
        if link.src_widget_id == node.widget_id or link.dst_widget_id == node.widget_id:
            removed_links.append(link.id)
            session.delete(link)

    session.delete(node)
    session.commit()
    return {"ok": True, "deleted_id": node_id, "removed_links": removed_links}


@router.post(
    "/{automation_id}/graph/links",
    dependencies=[Depends(require_basic_auth)],
)
def create_graph_link(
    automation_id: int,
    payload: GraphLinkIn,
    session: Session = Depends(get_session),
    _: None = Depends(require_editor_role),
):
    automation = session.get(Automation, automation_id)
    if not automation:
        raise HTTPException(status_code=404, detail="Automation not found")
    graph = _ensure_graph(session, automation)
    if payload.src_widget_id == payload.dst_widget_id:
        raise HTTPException(status_code=400, detail="Cannot link a widget to itself")

    for widget_id in (payload.src_widget_id, payload.dst_widget_id):
        exists = session.exec(
            select(AutomationNode)
            .where(AutomationNode.graph_id == graph.id)
            .where(AutomationNode.widget_id == widget_id)
        ).first()
        if not exists:
            raise HTTPException(status_code=404, detail=f"Widget {widget_id} not present on graph")

    existing = session.exec(
        select(AutomationLink)
        .where(AutomationLink.graph_id == graph.id)
        .where(AutomationLink.src_widget_id == payload.src_widget_id)
        .where(AutomationLink.dst_widget_id == payload.dst_widget_id)
    ).first()
    if existing:
        return {"link": _serialize_link(existing), "existing": True}

    link = AutomationLink(
        graph_id=graph.id,
        src_widget_id=payload.src_widget_id,
        dst_widget_id=payload.dst_widget_id,
        kind=(payload.kind or "").strip() or "hysteresis",
    )
    session.add(link)
    session.commit()
    session.refresh(link)
    return {"link": _serialize_link(link)}


@router.patch(
    "/{automation_id}/graph/links/{link_id}",
    dependencies=[Depends(require_basic_auth)],
)
def update_graph_link(
    automation_id: int,
    link_id: int,
    payload: GraphLinkUpdate,
    session: Session = Depends(get_session),
    _: None = Depends(require_editor_role),
):
    automation = session.get(Automation, automation_id)
    if not automation:
        raise HTTPException(status_code=404, detail="Automation not found")
    graph = _ensure_graph(session, automation)
    link = session.get(AutomationLink, link_id)
    if not link or link.graph_id != graph.id:
        raise HTTPException(status_code=404, detail="Link not found")

    if payload.src_widget_id is not None:
        if payload.src_widget_id == link.dst_widget_id:
            raise HTTPException(status_code=400, detail="Source and destination must differ")
        exists = session.exec(
            select(AutomationNode)
            .where(AutomationNode.graph_id == graph.id)
            .where(AutomationNode.widget_id == payload.src_widget_id)
        ).first()
        if not exists:
            raise HTTPException(status_code=404, detail="Source widget missing from graph")
        link.src_widget_id = payload.src_widget_id

    if payload.dst_widget_id is not None:
        if payload.dst_widget_id == link.src_widget_id:
            raise HTTPException(status_code=400, detail="Source and destination must differ")
        exists = session.exec(
            select(AutomationNode)
            .where(AutomationNode.graph_id == graph.id)
            .where(AutomationNode.widget_id == payload.dst_widget_id)
        ).first()
        if not exists:
            raise HTTPException(status_code=404, detail="Destination widget missing from graph")
        link.dst_widget_id = payload.dst_widget_id

    if payload.kind is not None:
        link.kind = (payload.kind or "").strip() or link.kind

    session.add(link)
    session.commit()
    session.refresh(link)
    return {"link": _serialize_link(link)}


@router.delete(
    "/{automation_id}/graph/links/{link_id}",
    dependencies=[Depends(require_basic_auth)],
)
def delete_graph_link(
    automation_id: int,
    link_id: int,
    session: Session = Depends(get_session),
    _: None = Depends(require_editor_role),
):
    automation = session.get(Automation, automation_id)
    if not automation:
        raise HTTPException(status_code=404, detail="Automation not found")
    graph = _ensure_graph(session, automation)
    link = session.get(AutomationLink, link_id)
    if not link or link.graph_id != graph.id:
        raise HTTPException(status_code=404, detail="Link not found")
    session.delete(link)
    session.commit()
    return {"ok": True, "deleted_id": link_id}


@router.post(
    "/{automation_id}/graph/layout",
    dependencies=[Depends(require_basic_auth)],
)
def update_graph_layout(
    automation_id: int,
    payload: GraphLayoutIn,
    session: Session = Depends(get_session),
    _: None = Depends(require_editor_role),
):
    automation = session.get(Automation, automation_id)
    if not automation:
        raise HTTPException(status_code=404, detail="Automation not found")
    graph = _ensure_graph(session, automation)
    nodes = session.exec(
        select(AutomationNode).where(AutomationNode.graph_id == graph.id)
    ).all()
    valid_ids = {node.id for node in nodes}
    layout: Dict[int, Dict[str, float]] = {}
    for key, value in (payload.layout or {}).items():
        try:
            node_id = int(key)
        except (TypeError, ValueError):
            continue
        if node_id not in valid_ids:
            continue
        if not isinstance(value, dict):
            continue
        x = _maybe_float(value.get("x"))
        y = _maybe_float(value.get("y"))
        if x is None or y is None:
            continue
        layout[node_id] = {"x": x, "y": y}

    _store_layout(session, automation, layout)
    return {"ok": True, "layout": {str(k): v for k, v in layout.items()}}


@router.post(
    "/{automation_id}/graph/publish",
    dependencies=[Depends(require_basic_auth)],
)
def publish_graph(
    automation_id: int,
    layout: str = Form(default=""),
    session: Session = Depends(get_session),
    _: None = Depends(require_editor_role),
):
    automation = session.get(Automation, automation_id)
    if not automation:
        raise HTTPException(status_code=404, detail="Automation not found")
    graph = _ensure_graph(session, automation)

    if layout:
        try:
            payload = json.loads(layout)
        except json.JSONDecodeError:
            payload = {}
        nodes = session.exec(
            select(AutomationNode).where(AutomationNode.graph_id == graph.id)
        ).all()
        valid_ids = {node.id for node in nodes}
        layout_map: Dict[int, Dict[str, float]] = {}
        if isinstance(payload, dict):
            for key, value in payload.items():
                try:
                    node_id = int(key)
                except (TypeError, ValueError):
                    continue
                if node_id not in valid_ids or not isinstance(value, dict):
                    continue
                x = _maybe_float(value.get("x"))
                y = _maybe_float(value.get("y"))
                if x is None or y is None:
                    continue
                layout_map[node_id] = {"x": x, "y": y}
        if layout_map:
            _store_layout(session, automation, layout_map)

    _synthesize_rules(session, automation, graph)
    return RedirectResponse(url="/dashboard/edit", status_code=303)


# ------------------------- Rules -------------------------
@router.get("/{automation_id}/rules}")
def list_rules_trailing_fix(automation_id: int, session: Session = Depends(get_session)) -> List[AutomationRule]:
    # compatibility for any cached openapi; route below is the real one
    return session.exec(
        select(AutomationRule)
        .where(AutomationRule.automation_id == automation_id)
        .order_by(AutomationRule.id)
    ).all()

@router.get("/{automation_id}/rules")
def list_rules(automation_id: int, session: Session = Depends(get_session)) -> List[AutomationRule]:
    return session.exec(
        select(AutomationRule)
        .where(AutomationRule.automation_id == automation_id)
        .order_by(AutomationRule.id)
    ).all()

@router.post("/{automation_id}/rules")
def add_rule(automation_id: int, body: RuleIn, session: Session = Depends(get_session)):
    parent = session.get(Automation, automation_id)
    if not parent:
        raise HTTPException(404, f"automation {automation_id} not found")
    try:
        r = AutomationRule(
            automation_id=automation_id,
            kind=body.kind,
            label=(body.label or ""),
            config_json=json.dumps(body.config or {}),
            enabled=True,
            created_at=datetime.now(timezone.utc),
        )
        session.add(r); session.commit(); session.refresh(r)
        return r
    except Exception as e:
        return JSONResponse(status_code=500, content={"error": str(e)})

@router.delete("/{automation_id}/rules/{rule_id}")
def delete_rule(automation_id: int, rule_id: int, session: Session = Depends(get_session)):
    r = session.get(AutomationRule, rule_id)
    if not r or r.automation_id != automation_id:
        raise HTTPException(404, "rule not found")
    session.delete(r); session.commit()
    return {"ok": True, "deleted_rule_id": rule_id}

@router.put("/{automation_id}/rules/{rule_id}")
def update_rule(automation_id: int, rule_id: int, body: RuleUpdate, session: Session = Depends(get_session)):
    r = session.get(AutomationRule, rule_id)
    if not r or r.automation_id != automation_id:
        raise HTTPException(404, "rule not found")
    if body.label is not None:
        r.label = body.label
    if body.enabled is not None:
        r.enabled = bool(body.enabled)
    if body.config is not None:
        r.config_json = json.dumps(body.config)
    session.add(r); session.commit(); session.refresh(r)
    return r

@router.patch("/rules/{rule_id}")
def update_rule(rule_id: int, body: RuleUpdateIn, session: Session = Depends(get_session)):
    r = session.get(AutomationRule, rule_id)
    if not r:
        raise HTTPException(status_code=404, detail="rule not found")
    if body.label is not None:
        r.label = body.label
    if body.config is not None:
        r.config_json = json.dumps(body.config)
    if body.enabled is not None:
        r.enabled = bool(body.enabled)
    session.add(r)
    session.commit()
    session.refresh(r)
    return r
    
@router.patch("/{automation_id}/rules/{rule_id}/enable")
def enable_rule(automation_id: int, rule_id: int, session: Session = Depends(get_session)):
    r = session.get(AutomationRule, rule_id)
    if not r or r.automation_id != automation_id:
        raise HTTPException(404, "rule not found")
    r.enabled = True; session.add(r); session.commit(); session.refresh(r)
    return r

@router.patch("/{automation_id}/rules/{rule_id}/disable")
def disable_rule(automation_id: int, rule_id: int, session: Session = Depends(get_session)):
    r = session.get(AutomationRule, rule_id)
    if not r or r.automation_id != automation_id:
        raise HTTPException(404, "rule not found")
    r.enabled = False; session.add(r); session.commit(); session.refresh(r)
    return r

# ------------------------- Schema debug -------------------------
@router.get("/schema")
def db_schema():
    try:
        with Session(engine) as s:
            out = []
            for name, sql in s.exec(text("SELECT name, sql FROM sqlite_master WHERE type='table' ORDER BY name;")):
                out.append({"name": name, "sql": sql})
            return out
    except Exception as e:
        return {"error": str(e)}

# ------------------------- Evaluation core -------------------------
def _eval_once(session: Session) -> list[dict]:
    """
    Evaluate enabled automation rules using latest hydrometer samples.
    Supports hysteresis (hydro_temp_pump) and PID time-proportional pump control.
    Returns a list of action dicts performed.
    """
    actions: list[dict] = []

    latest: dict[str, dict] = {}
    for row in session.exec(select(HydrometerLatest)).all():
        latest[row.color] = {"temp_f": row.temp_f, "sg": row.sg, "updated_at": row.updated_at}

    hysteresis_state = getattr(router, "_pump_timing", None)
    if hysteresis_state is None:
        hysteresis_state = {}
        setattr(router, "_pump_timing", hysteresis_state)

    pid_state = getattr(router, "_pid_state", None)
    if pid_state is None:
        pid_state = {}
        setattr(router, "_pid_state", pid_state)

    now = time.time()
    active_pid_rules: set[int] = set()

    rules = session.exec(select(AutomationRule).where(AutomationRule.enabled == True)).all()
    for r in rules:
        kind = (r.kind or "").strip().lower()
        if kind == "hydro_temp_pump":
            try:
                cfg = json.loads(r.config_json or "{}")
                color     = str(cfg.get("color", "red")).lower()
                on_above  = float(cfg.get("on_above"))
                off_below = float(cfg.get("off_below"))
                pump_id   = int(cfg.get("pump_widget_id"))
                min_on    = float(cfg.get("min_on_secs", 0))
                min_off   = float(cfg.get("min_off_secs", 0))
            except Exception as e:
                log_auto.warning("Rule %s bad config: %s", r.id, e)
                continue

            sample = latest.get(color)
            if not sample or sample.get("temp_f") is None:
                continue

            temp_f = float(sample["temp_f"])
            is_on  = bool(pump_manager.get_state(pump_id))
            last   = hysteresis_state.get(pump_id, {"last_change": 0, "last_state": is_on})
            elapsed = now - float(last.get("last_change", 0))

            if temp_f >= on_above and not is_on:
                if min_off and elapsed < min_off and last.get("last_state") is False:
                    continue
                pump_manager.set_pump(pump_id, True)
                hysteresis_state[pump_id] = {"last_change": now, "last_state": True}
                actions.append({
                    "rule_id": r.id,
                    "pump_id": pump_id,
                    "action": "ON",
                    "temp_f": temp_f,
                    "on_above": on_above,
                    "off_below": off_below,
                    "color": color,
                })
            elif temp_f <= off_below and is_on:
                if min_on and elapsed < min_on and last.get("last_state") is True:
                    continue
                pump_manager.set_pump(pump_id, False)
                hysteresis_state[pump_id] = {"last_change": now, "last_state": False}
                actions.append({
                    "rule_id": r.id,
                    "pump_id": pump_id,
                    "action": "OFF",
                    "temp_f": temp_f,
                    "on_above": on_above,
                    "off_below": off_below,
                    "color": color,
                })
            continue

        if kind == "pid_pump":
            active_pid_rules.add(r.id)
            try:
                cfg = json.loads(r.config_json or "{}")
                color = str(cfg.get("color", "red")).lower()
                target_f = float(cfg.get("target_f", 68.0))
                kp = float(cfg.get("kp", 1.0))
                ki = float(cfg.get("ki", 0.0))
                kd = float(cfg.get("kd", 0.0))
                pump_key = cfg.get("pump_id", cfg.get("pump_widget_id"))
                pump_id = int(pump_key)
                window_s = float(cfg.get("window_s", 10.0))
                output_min = float(cfg.get("output_min", 0.0))
                output_max = float(cfg.get("output_max", 1.0))
                deadband = float(cfg.get("deadband_f", 0.0))
            except Exception as e:
                log_auto.warning("PID rule %s bad config: %s", r.id, e)
                continue

            window_s = window_s if window_s > 0 else 1.0
            low_output, high_output = (output_min, output_max)
            if low_output > high_output:
                low_output, high_output = high_output, low_output

            state = pid_state.get(r.id)
            if not state or state.get("pump_id") != pump_id:
                state = {
                    "pump_id": pump_id,
                    "integral": 0.0,
                    "last_error": None,
                    "last_ts": None,
                    "window_start": now,
                    "window_on_until": now,
                    "duty": 0.0,
                    "window_length": window_s,
                }
                pid_state[r.id] = state
            elif state.get("window_length") != window_s:
                state["window_length"] = window_s
                state["window_start"] = now

            sample = latest.get(color)
            if not sample or sample.get("temp_f") is None:
                state["integral"] = 0.0
                state["last_error"] = 0.0
                state["last_ts"] = now
                state.setdefault("window_start", now)
                state["window_on_until"] = state["window_start"]
                state["duty"] = 0.0
                current = pump_manager.get_state(pump_id)
                if current:
                    pump_manager.set_pump(pump_id, False)
                    actions.append({
                        "rule_id": r.id,
                        "pump_id": pump_id,
                        "action": "OFF",
                        "reason": "no_sample",
                        "color": color,
                    })
                continue

            temp_f = float(sample.get("temp_f"))
            prev_ts = state.get("last_ts")
            dt = now - float(prev_ts or 0.0) if prev_ts else 0.0
            if dt < 0:
                dt = 0.0

            error = temp_f - target_f
            if deadband > 0 and abs(error) <= deadband:
                error = 0.0

            integral = float(state.get("integral", 0.0))
            if error == 0.0:
                integral *= 0.95
            elif dt > 0:
                integral += error * dt

            span = high_output - low_output
            if ki != 0.0 and span > 0:
                limit = span / abs(ki)
                if limit > 0:
                    integral = max(min(integral, limit), -limit)

            prev_error = state.get("last_error")
            derivative = 0.0
            if prev_error is not None and dt > 0:
                derivative = (error - float(prev_error)) / dt

            output = (kp * error) + (ki * integral) + (kd * derivative)
            duty = max(low_output, min(high_output, output))

            state["integral"] = integral
            state["last_error"] = error
            state["last_ts"] = now

            start = state.get("window_start")
            if start is None or now < start or (now - start) >= window_s:
                start = now
                state["window_start"] = start

            on_time = max(0.0, min(window_s, duty * window_s))
            on_until = start + on_time
            if on_until > start + window_s:
                on_until = start + window_s
            state["window_on_until"] = on_until
            state["duty"] = duty
            state["window_length"] = window_s

            desired_on = on_time > 0 and now < on_until
            current = pump_manager.get_state(pump_id)
            if desired_on and not current:
                pump_manager.set_pump(pump_id, True)
                actions.append({
                    "rule_id": r.id,
                    "pump_id": pump_id,
                    "action": "ON",
                    "temp_f": temp_f,
                    "target_f": target_f,
                    "duty": duty,
                    "color": color,
                })
            elif not desired_on and current:
                pump_manager.set_pump(pump_id, False)
                actions.append({
                    "rule_id": r.id,
                    "pump_id": pump_id,
                    "action": "OFF",
                    "temp_f": temp_f,
                    "target_f": target_f,
                    "duty": duty,
                    "color": color,
                })
            continue

    if pid_state:
        for rule_id in list(pid_state.keys()):
            if rule_id not in active_pid_rules:
                pid_state.pop(rule_id, None)

    return actions

# ------------------------- Debug/status/poke -------------------------
@router.get("/status")
def automations_status(request: Request):
    running = bool(getattr(request.app.state, "auto_loop_running", False))
    last_tick = getattr(request.app.state, "auto_last_tick", None)
    return {"running": running, "last_tick": str(last_tick) if last_tick else None}

@router.post("/poke")
def automations_poke(session: Session = Depends(get_session)):
    actions = _eval_once(session)
    return {"ok": True, "decided": bool(actions), "actions": actions}

@router.get("/ui", response_class=HTMLResponse)
def automations_ui(request: Request):
    return request.app.state.templates.TemplateResponse("auto_editor.html", {"request": request})


# ------------------------- Background loop -------------------------
async def eval_loop(app, interval: float = 2.0):
    if interval <= 0:
        log_auto.warning("Automation loop interval %.3f is non-positive; using 0.1", interval)
        interval = 0.1

    app.state.auto_loop_running = True
    app.state.auto_loop_interval = interval
    log_auto.info("Automation loop running (interval=%.2fs).", interval)
    try:
        while True:
            await asyncio.sleep(interval)
            try:
                with Session(engine) as s:
                    _ = _eval_once(s)
                app.state.auto_last_tick = datetime.now(timezone.utc)
            except Exception as e:
                log_auto.error("Automation loop error: %s", e)
    finally:
        app.state.auto_loop_running = False


# ----------------------- UI + Toggles (v0.1) -----------------------
from fastapi import Request
from fastapi.responses import HTMLResponse
from ..db import get_session

@router.post("/rules/{rule_id}/enable")
def enable_rule(rule_id: int, session: Session = Depends(get_session)):
    r = session.get(AutomationRule, rule_id)
    if not r:
        raise HTTPException(status_code=404, detail="rule not found")
    r.enabled = True
    session.add(r); session.commit(); session.refresh(r)
    return {"ok": True, "id": r.id, "enabled": r.enabled}

@router.post("/rules/{rule_id}/disable")
def disable_rule(rule_id: int, session: Session = Depends(get_session)):
    r = session.get(AutomationRule, rule_id)
    if not r:
        raise HTTPException(status_code=404, detail="rule not found")
    r.enabled = False
    session.add(r); session.commit(); session.refresh(r)
    return {"ok": True, "id": r.id, "enabled": r.enabled}

@router.get("/ui", response_class=HTMLResponse)
def automations_ui(request: Request, session: Session = Depends(get_session)):
    autos = session.exec(select(Automation).order_by(Automation.id)).all()
    # collect rules per automation
    bundles = []
    for a in autos:
        rules = session.exec(
            select(AutomationRule)
            .where(AutomationRule.automation_id == a.id)
            .order_by(AutomationRule.id)
        ).all()
        bundles.append({"auto": a, "rules": rules})
    return request.app.state.templates.TemplateResponse("auto_editor.html", {
        "request": request,
        "bundles": bundles
    })
