from __future__ import annotations

import uuid
from pathlib import Path
from typing import Final

from fastapi import APIRouter, File, HTTPException, UploadFile
from fastapi.responses import JSONResponse

router = APIRouter(prefix="/media", tags=["media"])

STATIC_DIR = Path(__file__).resolve().parents[2] / "static"
UPLOADS_DIR = STATIC_DIR / "uploads"
MAX_UPLOAD_SIZE: Final[int] = 8 * 1024 * 1024

ALLOWED_CONTENT_TYPES: Final[dict[str, str]] = {
    "image/png": ".png",
    "image/jpeg": ".jpg",
    "image/jpg": ".jpg",
    "image/gif": ".gif",
    "image/svg+xml": ".svg",
}

ALLOWED_EXTENSIONS: Final[set[str]] = {".png", ".jpg", ".jpeg", ".gif", ".svg"}


def _ensure_upload_dir() -> None:
    UPLOADS_DIR.mkdir(parents=True, exist_ok=True)


def _infer_extension(upload: UploadFile) -> str:
    content_type = (upload.content_type or "").lower()
    if content_type in ALLOWED_CONTENT_TYPES:
        return ALLOWED_CONTENT_TYPES[content_type]

    suffix = Path(upload.filename or "").suffix.lower()
    if suffix in ALLOWED_EXTENSIONS:
        if suffix == ".jpeg":
            return ".jpg"
        return suffix

    raise HTTPException(status_code=400, detail="Unsupported image format.")


@router.post("/upload")
async def upload_media(file: UploadFile = File(...)) -> JSONResponse:
    if not file:
        raise HTTPException(status_code=400, detail="No file uploaded.")

    if not file.content_type or not file.content_type.startswith("image/"):
        raise HTTPException(status_code=400, detail="Only image uploads are allowed.")

    _ensure_upload_dir()

    extension = _infer_extension(file)
    filename = f"{uuid.uuid4().hex}{extension}"
    destination = UPLOADS_DIR / filename

    data = await file.read()
    if len(data) > MAX_UPLOAD_SIZE:
        await file.close()
        raise HTTPException(status_code=413, detail="Upload exceeds 8 MB limit.")

    try:
        destination.write_bytes(data)
    finally:
        await file.close()

    url_path = f"/static/uploads/{filename}"
    return JSONResponse(status_code=201, content={"url": url_path})
