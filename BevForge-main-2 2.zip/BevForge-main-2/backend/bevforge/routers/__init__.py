"""Router package exports for FastAPI wiring."""

from . import admin, automations, dash, devices, ferments, media, sensors, tools, widgets

__all__ = [
    "admin",
    "automations",
    "dash",
    "devices",
    "ferments",
    "media",
    "sensors",
    "tools",
    "widgets",
]
