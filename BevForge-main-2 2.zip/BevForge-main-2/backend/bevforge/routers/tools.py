from __future__ import annotations
from fastapi import APIRouter, Depends, Request, Form
from fastapi.responses import HTMLResponse, RedirectResponse
from sqlmodel import select
from ..db import get_session, Session
from ..models import Widget
from ..utils.auth import require_edit

router = APIRouter(prefix="/tools", tags=["tools"])

@router.get("/devices", response_class=HTMLResponse)
def devices_form(request: Request, session: Session = Depends(get_session)):
    return request.app.state.templates.TemplateResponse("tools_devices.html", {"request": request})

@router.post("/devices")
def devices_create(kind: str = Form(...), slug: str = Form(...), session: Session = Depends(get_session)):
    if kind != "pump":
        kind = "pump"
    w = Widget(slug=slug, kind=kind)
    session.add(w)
    session.commit()
    return RedirectResponse("/dash/main?edit=1", status_code=303)

@router.get("/sensors", response_class=HTMLResponse)
def sensors_form(request: Request):
    return request.app.state.templates.TemplateResponse("tools_sensors.html", {"request": request})

@router.post("/sensors")
def sensors_create(kind: str = Form(...), slug: str = Form(...), session: Session = Depends(get_session)):
    w = Widget(slug=slug, kind=kind)
    session.add(w)
    session.commit()
    return RedirectResponse("/dash/main?edit=1", status_code=303)

@router.get("/widgets", response_class=HTMLResponse)
def widgets_form(request: Request):
    return request.app.state.templates.TemplateResponse("tools_widgets.html", {"request": request})

@router.post("/widgets")
def widgets_create(kind: str = Form(...), slug: str = Form(...), session: Session = Depends(get_session)):
    w = Widget(slug=slug, kind=kind)
    session.add(w)
    session.commit()
    return RedirectResponse("/dash/main?edit=1", status_code=303)
