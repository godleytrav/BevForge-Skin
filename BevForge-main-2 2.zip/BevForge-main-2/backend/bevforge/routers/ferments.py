from __future__ import annotations
from fastapi import APIRouter, Depends, Request
from fastapi.responses import HTMLResponse, JSONResponse
from sqlmodel import Session, select
from ..db import get_session
from ..models import HydrometerLatest

router = APIRouter(prefix="/ferments", tags=["ferments"])

@router.get("/ui", response_class=HTMLResponse)
def ferment_ui(request: Request, session: Session = Depends(get_session)) -> HTMLResponse:
    # Show a minimal page + latest Tilt sample if present.
    sample = session.exec(select(HydrometerLatest)).first()
    latest = (
        f"{sample.color} — {sample.temp_f:.1f} °F, SG {sample.sg:.3f}"
        if sample else "No hydrometer samples yet."
    )

    html = f"""
<!doctype html>
<html>
<head>
<meta charset="utf-8"/>
<title>Fermentation</title>
<link rel="stylesheet" href="/static/app.css"/>
</head>
<body class="page">
  <header class="hdr"><h1>Fermentation</h1></header>
  <main class="content">
    <section class="card">
      <h2>Latest hydrometer</h2>
      <p>{latest}</p>
      <p>Use the Tilt HTTP ingest to feed a reading:</p>
      <pre>curl -X POST http://127.0.0.1:8080/sensors/tilt/ingest \\
  -H 'Content-Type: application/json' \\
  -d '{{"color":"red","temp_f":68.5,"sg":1.012}}'</pre>
    </section>
  </main>
</body>
</html>
"""
    return HTMLResponse(html)

@router.get("/latest/{color}")
def ferment_latest(color: str, session: Session = Depends(get_session)):
    color = color.lower().strip()
    row = session.exec(select(HydrometerLatest).where(HydrometerLatest.color == color)).first()
    if not row:
        return JSONResponse({"ok": False, "error": "no sample"}, status_code=404)
    return {
        "ok": True,
        "color": row.color,
        "temp_f": row.temp_f,
        "sg": row.sg,
        "updated_at": row.updated_at,
    }
