from __future__ import annotations

import datetime
import glob
import html
import json
import logging
import os
import shutil
import subprocess
from pathlib import Path
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse
from sqlmodel import select

from ..db import DB_PATH, Session, get_session
from ..models import Widget
from ..services.pumps import pump_manager
from ..services.tilt_scanner import BleakScanner
from ..utils.auth import admin_basic
from ..utils.basic_auth import require_basic_auth
from ..utils.version import version_payload

router = APIRouter(prefix="/admin", tags=["admin"], dependencies=[Depends(require_basic_auth)])

def _bluetooth_service_active() -> bool:
    """Best-effort check for the bluetooth service."""

    if shutil.which("systemctl"):
        try:
            result = subprocess.run(
                ["systemctl", "is-active", "bluetooth"],
                capture_output=True,
                text=True,
                check=False,
            )
        except Exception:
            pass
        else:
            output = (result.stdout or result.stderr or "").strip().lower()
            if result.returncode == 0 and "active" in output:
                return True
            if "inactive" in output or "failed" in output:
                return False

    if shutil.which("service"):
        try:
            result = subprocess.run(
                ["service", "bluetooth", "status"],
                capture_output=True,
                text=True,
                check=False,
            )
        except Exception:
            pass
        else:
            output = (result.stdout + result.stderr).lower()
            if "active (running)" in output or "start/running" in output:
                return True
            if "inactive" in output or "stopped" in output:
                return False

    return False

@router.get("/logs/info")
def logs_info():
    """
    Report log directory, main file, size and any rotated backups.
    """
    import os, glob
    log_dir = os.environ.get("LOG_DIR", "backend/logs")
    log_file = os.environ.get("LOG_FILE", "app.log")
    path = os.path.join(log_dir, log_file)
    size = os.path.getsize(path) if os.path.exists(path) else 0
    backups = sorted(glob.glob(os.path.join(log_dir, "app.log.*")))
    return {
        "log_dir": log_dir,
        "log_file": log_file,
        "path": path,
        "size_bytes": size,
        "backups": [os.path.basename(b) for b in backups],
    }

@router.post("/logs/rotate")
def logs_rotate():
    """
    Force a rollover on the RotatingFileHandler if present.
    """
    import logging
    from logging.handlers import RotatingFileHandler
    rotated = []
    # Scan root and known loggers for RotatingFileHandler(s)
    for name in [""] + list(logging.Logger.manager.loggerDict.keys()):
        logger = logging.getLogger(name)
        for h in getattr(logger, "handlers", []):
            if isinstance(h, RotatingFileHandler):
                try:
                    h.doRollover()
                    rotated.append(getattr(h, "baseFilename", str(h)))
                except Exception as e:
                    rotated.append(f"ERROR: {e}")
    return {"ok": True, "rotated": rotated}


def _auth_enabled() -> bool:
    # Only require auth if BEVFORGE_ADMIN_PASS is set
    return bool(os.getenv("BEVFORGE_ADMIN_PASS"))

@router.get("/version")
def version():
    return version_payload()

@router.get("/health", response_class=HTMLResponse)
def admin_health(request: Request):
    app = request.app
    db_path = Path(DB_PATH)
    db_size = db_path.stat().st_size if db_path.exists() else 0

    # pumps info
    maps = pump_manager.mappings()
    backend = maps.get("backend")
    gpio = maps.get("gpio", {})
    usb = maps.get("usb", {})

    # automations heartbeat
    running = bool(getattr(app.state, "auto_loop_running", False))
    last_tick = getattr(app.state, "auto_last_tick", None)

    # last 50 log lines
    log_file = Path("backend/logs/app.log")
    tail_html = ""
    if log_file.exists():
        lines = log_file.read_text(errors="ignore").splitlines()[-50:]
        tail_html = "<br/>".join(l.replace("&","&amp;").replace("<","&lt;") for l in lines)

    ble_enabled_env = bool(getattr(app.state, "tilt_ble_env_enabled", False))
    ble_running = bool(getattr(app.state, "tilt_ble_running", False))
    ble_status_data = getattr(app.state, "tilt_ble_status", {}) or {}
    ble_last_error = getattr(app.state, "tilt_ble_last_error", None)
    ble_import_error = getattr(app.state, "tilt_ble_import_error", None)

    ble_lines: list[str] = []
    if ble_import_error:
        ble_lines.append(f"Import error: {ble_import_error}")
    if not ble_enabled_env:
        ble_lines.append("disabled (set TILT_BLE_ENABLE=1 to enable)")
    else:
        if ble_running:
            if ble_status_data:
                for color, info in sorted(ble_status_data.items()):
                    sg_val = info.get("sg")
                    if isinstance(sg_val, (int, float)):
                        sg_text = f"{sg_val:.3f}"
                    elif sg_val is None:
                        sg_text = "n/a"
                    else:
                        sg_text = str(sg_val)

                    temp_val = info.get("temp_f")
                    if isinstance(temp_val, (int, float)):
                        temp_text = f"{temp_val:.1f}°F"
                    elif temp_val is None:
                        temp_text = "temp n/a"
                    else:
                        temp_text = str(temp_val)

                    rssi_val = info.get("rssi")
                    rssi_text = f"RSSI {rssi_val}" if rssi_val is not None else ""
                    ts_val = info.get("ts")

                    parts = [f"{color}", f"SG {sg_text}", temp_text]
                    if rssi_text:
                        parts.append(rssi_text)
                    if ts_val:
                        parts.append(str(ts_val))
                    ble_lines.append(" | ".join(parts))
            else:
                ble_lines.append("running, awaiting first sample")
        else:
            ble_lines.append("env enabled, scanner not running (see logs)")

    if ble_last_error and all(ble_last_error not in line for line in ble_lines):
        ble_lines.append(f"Last error: {ble_last_error}")
    if not ble_lines:
        ble_lines.append("no data")
    ble_status_html = "<br/>".join(html.escape(line) for line in ble_lines)

    return f"""
<!doctype html><html><head><meta charset="utf-8"/><title>Admin Health</title>
<style>
:root {{ color-scheme: dark; }}
body {{ font-family: system-ui, -apple-system, Segoe UI, Roboto, sans-serif; background:#0b0f1a; color:#e6e9ef; margin:0; padding:1rem; }}
.card {{ border:1px solid #1e2842; border-radius:.75rem; padding:.75rem; margin-bottom:1rem; }}
.kv th {{ text-align:left; padding-right:.5rem; opacity:.8; }}
pre {{ white-space:pre-wrap; }}
</style>
</head><body>
<h1>Admin Health</h1>
<div class="card"><table class="kv">
<tr><th>DB Path</th><td>{db_path}</td></tr>
<tr><th>DB Size</th><td>{db_size} bytes</td></tr>
<tr><th>Automations Running</th><td>{running}</td></tr>
<tr><th>Last Tick</th><td>{last_tick}</td></tr>
<tr><th>Pump Backend</th><td>{backend}</td></tr>
<tr><th>GPIO Map</th><td><pre>{gpio}</pre></td></tr>
<tr><th>USB Map</th><td><pre>{usb}</pre></td></tr>
<tr><th>BLE Status</th><td>{ble_status_html}</td></tr>
</table></div>
<div class="card"><strong>Last 50 log lines</strong><div style="margin-top:.5rem"><pre>{tail_html}</pre></div></div>
</body></html>
"""
    return HTMLResponse(content=html)


@router.get("/tilt/status")
def tilt_status(request: Request):
    """Return the most recent Tilt BLE readings captured by the scanner."""

    app = request.app
    env_enabled = bool(getattr(app.state, "tilt_ble_env_enabled", False))
    status = getattr(app.state, "tilt_ble_status", {}) or {}
    latest = {color: dict(values) for color, values in status.items()}

    payload: dict[str, Any] = {
        "env_enabled": env_enabled,
        "running": bool(getattr(app.state, "tilt_ble_running", False)),
        "task_active": bool(getattr(app.state, "tilt_ble_task", None)),
        "latest": latest,
    }

    import_error = getattr(app.state, "tilt_ble_import_error", None)
    if import_error:
        payload["import_error"] = import_error

    last_error = getattr(app.state, "tilt_ble_last_error", None)
    if last_error:
        payload["last_error"] = last_error

    return payload


@router.get("/diagnostics")
def diagnostics(request: Request) -> dict[str, Any]:
    mappings = pump_manager.mappings()
    relay_info = pump_manager.relay_health()
    detected = relay_info.get("detected_devices") or []

    first_device = detected[0] if detected else {}
    vid = (first_device.get("vid") or "").strip()
    pid = (first_device.get("pid") or "").strip()
    vidpid = f"{vid}:{pid}" if vid or pid else None

    prefix = relay_info.get("discovered_prefix") or relay_info.get("env_prefix")
    labels_sample = relay_info.get("sample_labels") or []

    app = request.app
    scanner_running = bool(getattr(app.state, "tilt_ble_running", False))

    return {
        "backend": {
            "active": mappings.get("backend_slug"),
            "display": mappings.get("backend"),
            "requested": mappings.get("backend_requested"),
        },
        "usb": {
            "present": bool(detected),
            "vidpid": vidpid,
            "hidraw": first_device.get("hidraw"),
            "prefix": prefix,
            "labels_sample": labels_sample,
        },
        "tilt": {
            "ble_installed": BleakScanner is not None,
            "bt_service_active": _bluetooth_service_active(),
            "scanner_running": scanner_running,
        },
    }


@router.get("/hardware/diag", response_class=HTMLResponse)
def hardware_diag(request: Request, session: Session = Depends(get_session)):
    """Render a lightweight diagnostics dashboard for pump and BLE hardware."""

    try:
        info = pump_manager.describe()
    except Exception as exc:  # pragma: no cover - defensive
        info = {"error": str(exc)}

    backend_label = info.get("backend") or getattr(pump_manager, "backend_name", "Unknown")
    driver_obj = getattr(pump_manager, "driver", None)
    driver_name = info.get("driver") or (driver_obj.__class__.__name__ if driver_obj else "Unavailable")

    def _normalize_map(raw: dict | None) -> dict[int, object]:
        normalized: dict[int, object] = {}
        for key, value in (raw or {}).items():
            try:
                normalized[int(key)] = value
            except (TypeError, ValueError):
                continue
        return normalized

    gpio_map = _normalize_map(info.get("gpio"))
    usb_map = _normalize_map(info.get("usb"))
    mapped_ids = sorted(set(gpio_map) | set(usb_map))

    widgets_lookup: dict[int, Widget] = {}
    if mapped_ids:
        widgets = session.exec(select(Widget).where(Widget.id.in_(mapped_ids))).all()
        widgets_lookup = {w.id: w for w in widgets}

    driver = driver_obj
    diag_rows: list[dict[str, object]] = []
    for widget_id in mapped_ids:
        widget = widgets_lookup.get(widget_id)
        slug = widget.slug if widget else "(missing)"
        backend = "GPIO" if widget_id in gpio_map else "USB"
        mapping = gpio_map.get(widget_id) if backend == "GPIO" else usb_map.get(widget_id)
        read_error: str | None = None
        raw_value: object | None = None
        read_state: bool | None = None
        if driver and hasattr(driver, "get"):
            try:
                raw_value = driver.get(widget_id)
                read_state = bool(raw_value)
            except Exception as exc:  # pragma: no cover - hardware interaction
                read_error = str(exc)
        else:
            read_error = "driver does not expose get()"
        diag_rows.append(
            {
                "id": widget_id,
                "slug": slug,
                "backend": backend,
                "mapping": mapping,
                "raw": raw_value,
                "state": read_state,
                "error": read_error,
            }
        )

    usb_candidates: list[dict[str, object]] = []
    seen_paths: set[str] = set()
    for pattern in ("/dev/ttyUSB*", "/dev/ttyACM*", "/dev/hidraw*"):
        for path in sorted(glob.glob(pattern)):
            if path in seen_paths:
                continue
            seen_paths.add(path)
            mode_repr = "?"
            try:
                mode_repr = oct(os.stat(path).st_mode & 0o777)
            except Exception:
                mode_repr = "?"
            claim_msg = ""
            claim_error = None
            try:
                fd = os.open(path, os.O_RDONLY | os.O_NONBLOCK)
            except Exception as exc:  # pragma: no cover - dependent on host perms
                claim_error = str(exc)
            else:
                claim_msg = "opened read-only"
                os.close(fd)
            usb_candidates.append(
                {
                    "path": path,
                    "mode": mode_repr,
                    "claim": claim_msg,
                    "error": claim_error,
                }
            )

    raw_use_ble = str(os.getenv("USE_BLE", "")).strip()
    normalized_ble = raw_use_ble.lower()
    ble_enabled = normalized_ble in {"1", "true", "yes", "on"}
    if not raw_use_ble:
        ble_label = "Disabled (USE_BLE unset)"
    else:
        ble_label = "Enabled" if ble_enabled else f"Disabled ({raw_use_ble})"

    last_ble_scan = None
    last_ble_attr = None
    for attr in ("tilt_last_scan", "tilt_ble_last_scan", "tilt_last_tick", "ble_last_scan"):
        value = getattr(request.app.state, attr, None)
        if value is not None:
            last_ble_scan = value
            last_ble_attr = attr
            break

    def _format_timestamp(value: object | None) -> str:
        if value is None:
            return "Not available"
        if isinstance(value, (datetime.datetime, datetime.date)):
            return value.isoformat()
        return str(value)

    ble_scan_display = _format_timestamp(last_ble_scan)
    ble_attr_display = last_ble_attr or "—"

    gpio_json = html.escape(json.dumps(gpio_map, indent=2, default=str)) if gpio_map else "{}"
    usb_json = html.escape(json.dumps(usb_map, indent=2, default=str)) if usb_map else "{}"
    info_json = html.escape(json.dumps(info, indent=2, default=str))

    def _status_badge(row: dict[str, object]) -> tuple[str, str]:
        if row["error"]:
            return "Error", "bg-rose-500/20 text-rose-200"
        if row["state"] is True:
            return "ON", "bg-emerald-500/20 text-emerald-200"
        if row["state"] is False:
            return "OFF", "bg-sky-500/20 text-sky-200"
        return "Unknown", "bg-slate-500/20 text-slate-200"

    device_rows_html = "".join(
        f"<tr class=\"border-b border-slate-800/60\">"
        f"<td class=\"px-3 py-2 font-mono text-sm text-slate-300\">{row['id']}</td>"
        f"<td class=\"px-3 py-2 text-sm\">{html.escape(str(row['slug']))}</td>"
        f"<td class=\"px-3 py-2 text-xs uppercase tracking-wide text-slate-400\">{html.escape(str(row['backend']))}</td>"
        f"<td class=\"px-3 py-2 font-mono text-sm text-slate-300\">{html.escape(str(row['mapping'])) if row['mapping'] is not None else '—'}</td>"
        f"<td class=\"px-3 py-2\"><span class=\"inline-flex items-center rounded-full px-3 py-1 text-xs font-semibold { _status_badge(row)[1]}\">{_status_badge(row)[0]}</span></td>"
        f"<td class=\"px-3 py-2 font-mono text-xs text-slate-400\">{html.escape(repr(row['raw'])) if row['error'] is None else '—'}</td>"
        f"<td class=\"px-3 py-2 text-xs text-rose-200\">{html.escape(str(row['error'])) if row['error'] else ''}</td>"
        "</tr>"
        for row in diag_rows
    ) if diag_rows else "<tr><td colspan=\"7\" class=\"px-3 py-6 text-center text-sm text-slate-400\">No mapped devices reported.</td></tr>"

    usb_rows_html = "".join(
        f"<tr class=\"border-b border-slate-800/60\">"
        f"<td class=\"px-3 py-2 font-mono text-xs text-slate-300\">{html.escape(item['path'])}</td>"
        f"<td class=\"px-3 py-2 font-mono text-xs text-slate-400\">{html.escape(str(item['mode']))}</td>"
        f"<td class=\"px-3 py-2 text-xs text-emerald-200\">{html.escape(item['claim']) if item['claim'] else '—'}</td>"
        f"<td class=\"px-3 py-2 text-xs text-rose-200\">{html.escape(str(item['error'])) if item['error'] else ''}</td>"
        "</tr>"
        for item in usb_candidates
    ) if usb_candidates else "<tr><td colspan=\"4\" class=\"px-3 py-6 text-center text-sm text-slate-400\">No USB relay candidates detected.</td></tr>"

    page = f"""
<!doctype html>
<html class=\"h-full\">
<head>
  <meta charset=\"utf-8\" />
  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\" />
  <title>Hardware Diagnostics — BevForge</title>
  <script src=\"https://cdn.tailwindcss.com\"></script>
</head>
<body class=\"min-h-full bg-slate-950 text-slate-100\">
  <div class=\"mx-auto flex max-w-5xl flex-col gap-6 px-4 py-6\">
    <header>
      <h1 class=\"text-2xl font-semibold tracking-tight text-slate-100\">Hardware Diagnostics</h1>
      <p class=\"mt-1 text-sm text-slate-400\">Pump backend state, USB relay visibility, and Tilt BLE heartbeat.</p>
    </header>

    <section class=\"grid gap-4 sm:grid-cols-2\">
      <div class=\"rounded-lg border border-slate-800/80 bg-slate-900/70 p-4\">
        <div class=\"text-xs uppercase tracking-[0.3em] text-slate-500\">Backend</div>
        <div class=\"mt-1 text-xl font-semibold text-slate-100\">{html.escape(str(backend_label))}</div>
        <div class=\"text-sm text-slate-400\">Driver: {html.escape(str(driver_name))}</div>
      </div>
      <div class=\"rounded-lg border border-slate-800/80 bg-slate-900/70 p-4\">
        <div class=\"text-xs uppercase tracking-[0.3em] text-slate-500\">Tilt BLE</div>
        <div class=\"mt-1 text-xl font-semibold text-slate-100\">{html.escape(ble_label)}</div>
        <div class=\"text-xs text-slate-400\">Flag: {html.escape(raw_use_ble or '(unset)')}</div>
        <div class=\"text-xs text-slate-400\">Last scan ({html.escape(ble_attr_display)}): {html.escape(ble_scan_display)}</div>
      </div>
    </section>

    <section class=\"grid gap-4 md:grid-cols-2\">
      <div class=\"rounded-lg border border-slate-800/80 bg-slate-900/70 p-4\">
        <h2 class=\"text-sm font-semibold uppercase tracking-[0.25em] text-slate-300\">GPIO Map</h2>
        <pre class=\"mt-2 overflow-x-auto whitespace-pre-wrap text-xs text-slate-300\">{gpio_json}</pre>
      </div>
      <div class=\"rounded-lg border border-slate-800/80 bg-slate-900/70 p-4\">
        <h2 class=\"text-sm font-semibold uppercase tracking-[0.25em] text-slate-300\">USB Map</h2>
        <pre class=\"mt-2 overflow-x-auto whitespace-pre-wrap text-xs text-slate-300\">{usb_json}</pre>
      </div>
    </section>

    <section class=\"rounded-lg border border-slate-800/80 bg-slate-900/70\">
      <header class=\"border-b border-slate-800/80 px-4 py-3\">
        <h2 class=\"text-sm font-semibold uppercase tracking-[0.25em] text-slate-300\">Mapped Devices Readback</h2>
      </header>
      <div class=\"overflow-x-auto\">
        <table class=\"min-w-full divide-y divide-slate-800/80 text-left text-sm\">
          <thead class=\"bg-slate-900/80 text-xs uppercase tracking-wider text-slate-400\">
            <tr>
              <th class=\"px-3 py-2\">ID</th>
              <th class=\"px-3 py-2\">Slug</th>
              <th class=\"px-3 py-2\">Backend</th>
              <th class=\"px-3 py-2\">Mapping</th>
              <th class=\"px-3 py-2\">Readback</th>
              <th class=\"px-3 py-2\">Raw</th>
              <th class=\"px-3 py-2\">Error</th>
            </tr>
          </thead>
          <tbody class=\"divide-y divide-slate-900/60\">
            {device_rows_html}
          </tbody>
        </table>
      </div>
    </section>

    <section class=\"rounded-lg border border-slate-800/80 bg-slate-900/70\">
      <header class=\"border-b border-slate-800/80 px-4 py-3\">
        <h2 class=\"text-sm font-semibold uppercase tracking-[0.25em] text-slate-300\">USB Relay Candidates</h2>
      </header>
      <div class=\"overflow-x-auto\">
        <table class=\"min-w-full divide-y divide-slate-800/80 text-left text-sm\">
          <thead class=\"bg-slate-900/80 text-xs uppercase tracking-wider text-slate-400\">
            <tr>
              <th class=\"px-3 py-2\">Device</th>
              <th class=\"px-3 py-2\">Mode</th>
              <th class=\"px-3 py-2\">Claim</th>
              <th class=\"px-3 py-2\">Error</th>
            </tr>
          </thead>
          <tbody class=\"divide-y divide-slate-900/60\">
            {usb_rows_html}
          </tbody>
        </table>
      </div>
    </section>

    <section class=\"rounded-lg border border-slate-800/80 bg-slate-900/70 p-4\">
      <h2 class=\"text-sm font-semibold uppercase tracking-[0.25em] text-slate-300\">PumpManager.describe()</h2>
      <pre class=\"mt-2 overflow-x-auto whitespace-pre-wrap text-xs text-slate-300\">{info_json}</pre>
    </section>
  </div>
</body>
</html>
"""

    return HTMLResponse(page)

@router.get("/db/backup")
def db_backup(dep: None = Depends(admin_basic) if _auth_enabled() else None):
    path = Path("backend/data/bevforge.db")
    if not path.exists():
        return JSONResponse({"error": "database not found"}, status_code=404)
    return FileResponse(path, filename="bevforge.db")

@router.get("/logs/download")
def logs_download(dep: None = Depends(admin_basic) if _auth_enabled() else None):
    path = Path("backend/logs/app.log")
    if not path.exists():
        return JSONResponse({"error": "log file not found"}, status_code=404)
    return FileResponse(path, filename="app.log")

@router.get("/admin/db/backup")
def admin_db_backup():
    """
    Streams a copy of the SQLite DB as an attachment.
    """
    log = logging.getLogger("bevforge.admin")
    from ..db import DB_PATH
    db_path = Path(DB_PATH)
    if not db_path.exists():
        raise HTTPException(status_code=404, detail="DB not found")
    ts = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"bevforge_db_{ts}.sqlite"
    return FileResponse(path=str(db_path), media_type="application/octet-stream", filename=filename)

@router.get("/admin/logs/download")
def admin_logs_download():
    """
    Streams the current app log file as an attachment.
    """
    log = logging.getLogger("bevforge.admin")
    log_dir = Path(os.getenv("LOG_DIR", "backend/logs"))
    log_file = os.getenv("LOG_FILE", "app.log")
    path = log_dir / log_file
    if not path.exists():
        raise HTTPException(status_code=404, detail="Log file not found")
    ts = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"bevforge_logs_{ts}.log"
    return FileResponse(path=str(path), media_type="text/plain", filename=filename)

