# SENTINEL: DASHBOARD-ROUTER
from __future__ import annotations

import json
import logging
from datetime import datetime
from typing import Any, Dict, Iterable, List, Tuple

from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.responses import RedirectResponse
from pydantic import BaseModel
from sqlmodel import select, text

from ..db import Session, get_session
from ..models import Widget
from ..utils.basic_auth import has_editor_role, require_basic_auth, require_editor_role

logger = logging.getLogger(__name__)

DRAFT_FIELDS = ("draft_x", "draft_y", "draft_w", "draft_h")

router = APIRouter(prefix="/dash", tags=["dash"])
dashboard_router = APIRouter(prefix="/dashboard", tags=["dashboard"])


def _has_draft_columns() -> bool:
    fields = getattr(Widget, "__fields__", {})
    return all(name in fields for name in DRAFT_FIELDS)


def _serialize_widgets(
    rows: Iterable[Widget],
    *,
    use_draft: bool,
) -> Tuple[List[Dict[str, Any]], bool]:
    supports_draft = _has_draft_columns()
    widgets: List[Dict[str, Any]] = []
    has_pending_draft = False

    for row in rows:
        try:
            config = json.loads(row.config_json or "{}")
        except json.JSONDecodeError:
            config = {}

        published = {
            "x": getattr(row, "x", 0) or 0,
            "y": getattr(row, "y", 0) or 0,
            "w": getattr(row, "w", 1) or 1,
            "h": getattr(row, "h", 1) or 1,
        }
        draft_values = {
            "x": getattr(row, "draft_x", None) if supports_draft else None,
            "y": getattr(row, "draft_y", None) if supports_draft else None,
            "w": getattr(row, "draft_w", None) if supports_draft else None,
            "h": getattr(row, "draft_h", None) if supports_draft else None,
        }

        pending = supports_draft and any(value is not None for value in draft_values.values())
        has_pending_draft = has_pending_draft or pending

        widgets.append(
            {
                "id": row.id,
                "slug": row.slug,
                "kind": row.kind,
                "config": config,
                "x": draft_values["x"] if use_draft and draft_values["x"] is not None else published["x"],
                "y": draft_values["y"] if use_draft and draft_values["y"] is not None else published["y"],
                "w": draft_values["w"] if use_draft and draft_values["w"] is not None else published["w"],
                "h": draft_values["h"] if use_draft and draft_values["h"] is not None else published["h"],
                "draft": draft_values,
                "has_draft": pending,
            }
        )

    return widgets, has_pending_draft


def _has_editor_access(request: Request) -> bool:
    return has_editor_role(request.headers.get("Authorization"))


def _render_dashboard(
    request: Request,
    session: Session,
    *,
    slug: str,
    template: str,
    edit_mode: bool,
    use_draft: bool,
    extra: Dict[str, Any] | None = None,
):
    rows = session.exec(select(Widget).order_by(Widget.y, Widget.x, Widget.id)).all()
    widgets, has_pending_draft = _serialize_widgets(rows, use_draft=use_draft)
    context: Dict[str, Any] = {
        "request": request,
        "slug": slug,
        "widgets": widgets,
        "edit_mode": edit_mode,
        "edit": edit_mode,
        "is_edit": edit_mode,
        "can_edit": _has_editor_access(request),
        "supports_draft": _has_draft_columns(),
        "has_pending_draft": has_pending_draft,
    }
    if extra:
        context.update(extra)
    return request.app.state.templates.TemplateResponse(template, context)


@router.get("/{slug}", include_in_schema=False)
def legacy_dashboard(
    slug: str,
    request: Request,
    session: Session = Depends(get_session),
):
    if request.query_params.get("edit") == "1":
        return RedirectResponse(url="/dashboard/edit", status_code=307)
    return _render_dashboard(
        request,
        session,
        slug=slug,
        template="dashboard.html",
        edit_mode=False,
        use_draft=False,
    )


@dashboard_router.get("", include_in_schema=False)
def dashboard_home(request: Request, session: Session = Depends(get_session)):
    return _render_dashboard(
        request,
        session,
        slug="main",
        template="dashboard.html",
        edit_mode=False,
        use_draft=False,
    )


@dashboard_router.get(
    "/edit",
    include_in_schema=False,
    dependencies=[Depends(require_basic_auth)],
)
def dashboard_edit(
    request: Request,
    session: Session = Depends(get_session),
    _auth: Dict[str, Any] = Depends(require_editor_role),
):
    return _render_dashboard(
        request,
        session,
        slug="main",
        template="dashboard.html",
        edit_mode=True,
        use_draft=True,
        extra={
            "publish_url": "/dashboard/publish",
            "revert_url": "/dashboard/revert-draft",
        },
    )


@dashboard_router.get(
    "/widgets/{widget_id}/inline-editor",
    include_in_schema=False,
    dependencies=[Depends(require_basic_auth)],
)
def dashboard_widget_inline_editor(
    widget_id: int,
    request: Request,
    session: Session = Depends(get_session),
    _auth: Dict[str, Any] = Depends(require_editor_role),
):
    widget = session.get(Widget, widget_id)
    if not widget:
        raise HTTPException(status_code=404, detail="Widget not found")

    try:
        parsed = json.loads(widget.config_json or "{}")
        config_pretty = json.dumps(parsed, indent=2, sort_keys=True)
    except json.JSONDecodeError:
        config_pretty = widget.config_json or "{}"

    templates = request.app.state.templates
    return templates.TemplateResponse(
        "partials/widget_inline_editor.html",
        {
            "request": request,
            "widget": widget,
            "config_pretty": config_pretty,
        },
    )


class DummyLogPayload(BaseModel):
    widget_id: int | None = None
    state: bool
    label: str | None = None


@dashboard_router.post("/dummy/log", include_in_schema=False)
def dashboard_dummy_log(payload: DummyLogPayload):
    """Record dummy relay toggles in the dashboard log."""

    wid = payload.widget_id
    state_text = "ON" if payload.state else "OFF"
    label = payload.label or (f"widget #{wid}" if wid is not None else "dummy relay")
    logger.info("Dummy relay toggle: %s -> %s", label, state_text)
    return {"ok": True, "state": state_text}


@dashboard_router.post(
    "/publish",
    include_in_schema=False,
    dependencies=[Depends(require_basic_auth)],
)
async def dashboard_publish(
    request: Request,
    session: Session = Depends(get_session),
    _auth: Dict[str, Any] = Depends(require_editor_role),
):
    content_type = (request.headers.get("content-type") or "").lower()
    raw_payload: Any
    if "application/json" in content_type:
        try:
            raw_payload = await request.json()
        except json.JSONDecodeError as exc:
            raise HTTPException(status_code=400, detail="Invalid layout payload") from exc
    elif "application/x-www-form-urlencoded" in content_type or "multipart/form-data" in content_type:
        form = await request.form()
        raw_payload = form.get("positions")
    else:
        body_bytes = await request.body()
        raw_payload = body_bytes if body_bytes else None

    updates = _parse_positions_payload(raw_payload)
    publish_stamp = datetime.utcnow()

    applied_updates = 0
    published = 0
    try:
        if updates:
            applied_updates = _store_layout_updates(
                session,
                updates,
                as_draft=True,
                published_stamp=publish_stamp,
            )
        published = _publish_drafts(session, published_stamp=publish_stamp)
        live_updates = _store_layout_updates(
            session,
            updates,
            as_draft=False,
            published_stamp=publish_stamp,
        )
        if published == 0:
            if live_updates:
                published = live_updates
            elif applied_updates and not _has_draft_columns():
                published = applied_updates
        session.commit()
    except Exception:
        session.rollback()
        raise

    logger.info("Published dashboard layout for %s widget(s)", published)
    return RedirectResponse(url="/dashboard", status_code=303)


@dashboard_router.post(
    "/revert-draft",
    include_in_schema=False,
    dependencies=[Depends(require_basic_auth)],
)
def dashboard_revert_draft(
    session: Session = Depends(get_session),
    _auth: Dict[str, Any] = Depends(require_editor_role),
):
    cleared = 0
    if _has_draft_columns():
        result = session.exec(
            text(
                """
                UPDATE widget
                SET draft_x = NULL,
                    draft_y = NULL,
                    draft_w = NULL,
                    draft_h = NULL
                WHERE draft_x IS NOT NULL
                   OR draft_y IS NOT NULL
                   OR draft_w IS NOT NULL
                   OR draft_h IS NOT NULL
                """
            )
        )
        cleared = result.rowcount or 0
        session.commit()
    logger.info("Reverted dashboard draft layout for %s widget(s)", cleared)
    return {"ok": True, "cleared": cleared}


def _parse_positions_payload(raw_positions: Any) -> List[Dict[str, Any]]:
    if raw_positions is None:
        return []

    payload = raw_positions
    if isinstance(payload, (bytes, bytearray)):
        payload = payload.decode("utf-8", "ignore")
    if isinstance(payload, str):
        text = payload.strip()
        if text == "":
            return []
        try:
            parsed = json.loads(text)
        except json.JSONDecodeError as exc:
            raise HTTPException(status_code=400, detail="Invalid layout payload") from exc
        payload = parsed

    if isinstance(payload, dict):
        if "positions" in payload:
            return _parse_positions_payload(payload.get("positions"))
        raise HTTPException(status_code=400, detail="Invalid layout payload")

    if not isinstance(payload, list):
        raise HTTPException(status_code=400, detail="Invalid layout payload")

    updates: List[Dict[str, Any]] = []
    for item in payload:
        if not isinstance(item, dict):
            continue
        updates.append(
            {
                "id": item.get("id"),
                "x": item.get("x"),
                "y": item.get("y"),
                "w": item.get("w"),
                "h": item.get("h"),
            }
        )
    return updates


def _coerce_int(value: Any, *, default: int, minimum: int) -> int:
    try:
        parsed = int(value)
    except (TypeError, ValueError):
        parsed = default
    if parsed < minimum:
        return minimum
    return parsed


def _store_layout_updates(
    session: Session,
    updates: List[Dict[str, Any]],
    *,
    as_draft: bool,
    published_stamp: datetime | None = None,
) -> int:
    if not updates:
        return 0

    supports_draft = _has_draft_columns()
    stamp = published_stamp or datetime.utcnow()
    total = 0
    for item in updates:
        if not isinstance(item, dict):
            continue
        try:
            widget_id = int(item.get("id"))
        except (TypeError, ValueError):
            continue
        if widget_id <= 0:
            continue

        widget = session.get(Widget, widget_id)
        if not widget:
            continue

        x = _coerce_int(item.get("x"), default=widget.x if hasattr(widget, "x") else 0, minimum=0)
        y = _coerce_int(item.get("y"), default=widget.y if hasattr(widget, "y") else 0, minimum=0)
        w = _coerce_int(item.get("w"), default=widget.w if hasattr(widget, "w") else 1, minimum=1)
        h = _coerce_int(item.get("h"), default=widget.h if hasattr(widget, "h") else 1, minimum=1)

        if as_draft and supports_draft:
            changed = False
            if getattr(widget, "draft_x", None) != x:
                widget.draft_x = x
                changed = True
            if getattr(widget, "draft_y", None) != y:
                widget.draft_y = y
                changed = True
            if getattr(widget, "draft_w", None) != w:
                widget.draft_w = w
                changed = True
            if getattr(widget, "draft_h", None) != h:
                widget.draft_h = h
                changed = True
            if changed:
                session.add(widget)
                total += 1
            continue

        widget.x = x
        widget.y = y
        widget.w = w
        widget.h = h
        widget.published_at = stamp

        if supports_draft:
            if getattr(widget, "draft_x", None) is not None:
                widget.draft_x = None
            if getattr(widget, "draft_y", None) is not None:
                widget.draft_y = None
            if getattr(widget, "draft_w", None) is not None:
                widget.draft_w = None
            if getattr(widget, "draft_h", None) is not None:
                widget.draft_h = None

        session.add(widget)
        total += 1
    return total


def _publish_drafts(session: Session, *, published_stamp: datetime | None = None) -> int:
    if not _has_draft_columns():
        return 0

    stamp = published_stamp or datetime.utcnow()
    rows = session.exec(select(Widget)).all()
    updated = 0

    for widget in rows:
        draft_x = getattr(widget, "draft_x", None)
        draft_y = getattr(widget, "draft_y", None)
        draft_w = getattr(widget, "draft_w", None)
        draft_h = getattr(widget, "draft_h", None)
        if not any(value is not None for value in (draft_x, draft_y, draft_w, draft_h)):
            continue

        if draft_x is not None:
            widget.x = _coerce_int(draft_x, default=widget.x, minimum=0)
        if draft_y is not None:
            widget.y = _coerce_int(draft_y, default=widget.y, minimum=0)
        if draft_w is not None:
            widget.w = _coerce_int(draft_w, default=widget.w, minimum=1)
        if draft_h is not None:
            widget.h = _coerce_int(draft_h, default=widget.h, minimum=1)

        widget.draft_x = None
        widget.draft_y = None
        widget.draft_w = None
        widget.draft_h = None
        widget.published_at = stamp

        session.add(widget)
        updated += 1

    return updated
