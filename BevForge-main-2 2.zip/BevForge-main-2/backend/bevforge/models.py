from __future__ import annotations
from datetime import datetime
from typing import Optional

from sqlmodel import Field, SQLModel

class Widget(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    slug: str
    kind: str  # 'clock'|'weather'|'pump'|'hydrometer'|'ferment'|...
    config_json: str = "{}"
    x: int = 0
    y: int = 0
    w: int = 1
    h: int = 1
    draft_x: Optional[int] = Field(default=None, nullable=True)
    draft_y: Optional[int] = Field(default=None, nullable=True)
    draft_w: Optional[int] = Field(default=None, nullable=True)
    draft_h: Optional[int] = Field(default=None, nullable=True)
    created_at: datetime = Field(default_factory=datetime.utcnow)
    published_at: Optional[datetime] = Field(default=None, nullable=True)

class DashboardLayout(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    dashboard_slug: str
    widget_id: int = Field(foreign_key="widget.id")
    x: int = 0
    y: int = 0
    w: int = 1
    h: int = 1

class AutomationRule(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    automation_id: int = Field(foreign_key="automations.id")
    kind: str  # 'hydro_temp_pump'
    label: str
    config_json: str  # JSON with thresholds, units, color, pump_widget_id
    enabled: bool = True
    created_at: datetime = Field(default_factory=datetime.utcnow)

class HydrometerLatest(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    color: str  # e.g., 'red','green','blue' Tilt color
    temp_f: float = 0.0
    sg: float = 1.000
    updated_at: datetime = Field(default_factory=datetime.utcnow, nullable=False)

class FermentLog(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    batch_slug: str
    temp_f: float
    sg: float
    note: str = ""
    created_at: datetime = Field(default_factory=datetime.utcnow)

class Automation(SQLModel, table=True):
    __tablename__ = "automations"

    id: Optional[int] = Field(default=None, primary_key=True)
    label: str = Field(index=True)
    config_json: str = Field(default="{}")
    created_at: datetime = Field(default_factory=datetime.utcnow)


class AutomationGraph(SQLModel, table=True):
    __tablename__ = "automation_graph"

    id: Optional[int] = Field(default=None, primary_key=True)
    automation_id: int = Field(foreign_key="automations.id")
    created_at: datetime = Field(default_factory=datetime.utcnow)


class AutomationNode(SQLModel, table=True):
    __tablename__ = "automation_node"

    id: Optional[int] = Field(default=None, primary_key=True)
    graph_id: int = Field(foreign_key="automation_graph.id")
    widget_id: int = Field(foreign_key="widget.id")


class AutomationLink(SQLModel, table=True):
    __tablename__ = "automation_link"

    id: Optional[int] = Field(default=None, primary_key=True)
    graph_id: int = Field(foreign_key="automation_graph.id")
    src_widget_id: int = Field(foreign_key="widget.id")
    dst_widget_id: int = Field(foreign_key="widget.id")
    kind: str = Field(default="hysteresis")

