from __future__ import annotations
import os, logging
from logging.handlers import RotatingFileHandler
from pathlib import Path

def setup_logging():
    """
    Configure app-wide logging with rotation.
    Env:
      LOG_DIR (default backend/logs)
      LOG_FILE (default app.log)
      LOG_MAX_MB (default 5)
      LOG_BACKUPS (default 5)
      LOG_LEVEL (default INFO)
    """
    log_dir = Path(os.getenv("LOG_DIR", "backend/logs"))
    log_dir.mkdir(parents=True, exist_ok=True)
    log_file = os.getenv("LOG_FILE", "app.log")
    max_mb   = float(os.getenv("LOG_MAX_MB", "5"))
    backups  = int(os.getenv("LOG_BACKUPS", "5"))
    level    = os.getenv("LOG_LEVEL", "INFO").upper()

    logfile_path = log_dir / log_file

    root = logging.getLogger()
    if root.handlers:
        # Already configured (uvicorn may add its own). We still add our rotating file.
        pass
    root.setLevel(getattr(logging, level, logging.INFO))

    # Rotating file handler
    rfh = RotatingFileHandler(logfile_path, maxBytes=int(max_mb*1024*1024), backupCount=backups)
    rfh.setLevel(getattr(logging, level, logging.INFO))
    rfh.setFormatter(logging.Formatter(
        fmt="%(asctime)s %(levelname)s %(name)s: %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    ))
    root.addHandler(rfh)

    # Nice named logger for our app
    logging.getLogger("bevforge").setLevel(getattr(logging, level, logging.INFO))
    return str(logfile_path)
