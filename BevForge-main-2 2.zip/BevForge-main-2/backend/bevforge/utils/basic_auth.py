from __future__ import annotations

import base64
import os
import secrets
from typing import Dict, Tuple

from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPBasic, HTTPBasicCredentials

_BASIC_HEADER = {"WWW-Authenticate": "Basic"}
_EDITOR_ROLES = {"admin"}
_security = HTTPBasic(auto_error=False)


def _configured_credentials() -> Tuple[str, str] | None:
    user = os.getenv("BASIC_AUTH_USER")
    password = os.getenv("BASIC_AUTH_PASS")
    if user and password:
        return user, password
    return None


def _decode_basic_header(raw_header: str) -> Tuple[str, str] | None:
    try:
        scheme, encoded = raw_header.split(" ", 1)
    except ValueError:
        return None
    if scheme.lower() != "basic":
        return None
    try:
        decoded = base64.b64decode(encoded.encode()).decode()
    except (ValueError, UnicodeDecodeError):
        return None
    if ":" not in decoded:
        return None
    username, password = decoded.split(":", 1)
    return username, password


def require_basic_auth(
    credentials: HTTPBasicCredentials | None = Depends(_security),
) -> Dict[str, str | bool | None]:
    """Enforce HTTP Basic auth when credentials are configured."""

    configured = _configured_credentials()
    if not configured:
        return {"user": None, "role": "admin", "authenticated": False}

    if credentials is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Unauthorized",
            headers=_BASIC_HEADER,
        )

    expected_user, expected_pass = configured
    if not (
        secrets.compare_digest(credentials.username or "", expected_user)
        and secrets.compare_digest(credentials.password or "", expected_pass)
    ):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Unauthorized",
            headers=_BASIC_HEADER,
        )

    return {"user": credentials.username, "role": "admin", "authenticated": True}


def require_editor_role(
    credentials: HTTPBasicCredentials | None = Depends(_security),
) -> Dict[str, str | bool | None]:
    """Ensure the authenticated caller has editor-level access."""

    auth_info = require_basic_auth(credentials=credentials)
    role = (auth_info.get("role") or "").lower()
    if role in _EDITOR_ROLES:
        return auth_info

    raise HTTPException(
        status_code=status.HTTP_403_FORBIDDEN,
        detail="Forbidden: editor role required",
    )


def has_editor_role(authorization: str | None) -> bool:
    configured = _configured_credentials()
    if not configured:
        return True
    if not authorization:
        return False
    decoded = _decode_basic_header(authorization)
    if not decoded:
        return False
    expected_user, expected_pass = configured
    username, password = decoded
    return secrets.compare_digest(username, expected_user) and secrets.compare_digest(
        password, expected_pass
    )


__all__ = ["has_editor_role", "require_basic_auth", "require_editor_role"]
