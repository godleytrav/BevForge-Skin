from __future__ import annotations

import json
from typing import Dict, Tuple

__all__ = [
    "parse_usb_map",
    "parse_relay_label",
    "format_relay_label",
    "normalize_board_id",
]


def parse_usb_map(raw: str | None) -> Tuple[Dict[int, str], Dict[str, str]]:
    """Parse ``PUMP_USB_MAP`` env strings into numeric and logical mappings."""

    numeric: Dict[int, str] = {}
    logical: Dict[str, str] = {}

    if not raw:
        return numeric, logical

    text = raw.strip()
    if not text:
        return numeric, logical

    data = None
    try:
        data = json.loads(text)
    except json.JSONDecodeError:
        data = None

    if isinstance(data, dict):
        iterator = data.items()
    else:
        parts = [chunk.strip() for chunk in text.split(",") if chunk.strip()]
        parsed: list[tuple[str, str]] = []
        for chunk in parts:
            if ":" not in chunk:
                continue
            key, value = chunk.split(":", 1)
            key = key.strip()
            value = value.strip()
            if not key or not value:
                continue
            parsed.append((key, value))
        iterator = parsed

    for key, value in iterator:  # type: ignore[arg-type]
        str_key = str(key).strip()
        str_value = str(value).strip()
        if not str_key or not str_value:
            continue
        logical[str_key] = str_value
        try:
            numeric[int(str_key)] = str_value
        except (TypeError, ValueError):
            if str_key.isdigit():
                try:
                    numeric[int(str_key)] = str_value
                except ValueError:
                    pass
            continue

    return numeric, logical


def normalize_board_id(board: str | None) -> str | None:
    if not board:
        return None
    text = str(board).strip()
    if not text:
        return None
    return text.upper()


def format_relay_label(board: str, channel: int) -> str:
    normalized = normalize_board_id(board)
    if not normalized:
        raise ValueError("board must be provided")
    if channel < 1 or channel > 8:
        raise ValueError("channel must be between 1 and 8")
    return f"{normalized}_{int(channel)}"


def parse_relay_label(label: str | None) -> tuple[str, int] | None:
    if not label:
        return None
    text = str(label).strip().upper()
    if not text:
        return None
    if "_" not in text:
        return None
    board, channel_text = text.split("_", 1)
    if not board or not channel_text:
        return None
    try:
        channel = int(channel_text)
    except (TypeError, ValueError):
        return None
    if channel < 1 or channel > 8:
        return None
    return board, channel

