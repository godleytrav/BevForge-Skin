from __future__ import annotations
import os
from fastapi import Depends, HTTPException, Request
from fastapi.security import HTTPBasic, HTTPBasicCredentials

security = HTTPBasic()

def admin_basic(credentials: HTTPBasicCredentials = Depends(security)) -> None:
    user_ok = credentials.username == os.getenv("BEVFORGE_ADMIN_USER", "admin")
    pass_ok = credentials.password == os.getenv("BEVFORGE_ADMIN_PASS", "")
    if not (user_ok and pass_ok):
        raise HTTPException(status_code=401, detail="Unauthorized")

def require_edit(request: Request) -> None:
    """Guard edit mode if BEVFORGE_ADMIN_PASS is set and ?edit=1 is used."""
    edit = request.query_params.get("edit") == "1"
    if not edit:
        return
    admin_pass = os.getenv("BEVFORGE_ADMIN_PASS")
    if admin_pass:
        # We require Basic auth when BEVFORGE_ADMIN_PASS is set
        # The routers using this should include HTTPBasic dependency
        return
    # if no admin pass set, edit is open (dev-friendly)
    return
