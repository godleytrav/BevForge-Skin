from __future__ import annotations
import platform, sys, subprocess
from pathlib import Path

def git_info() -> str:
    try:
        root = Path(__file__).resolve().parents[3]
        rev = subprocess.check_output(["git", "-C", str(root), "rev-parse", "--short", "HEAD"], text=True).strip()
        dirty = subprocess.check_output(["git", "-C", str(root), "status", "--porcelain"], text=True).strip()
        return f"{rev}{'+' if dirty else ''}"
    except Exception:
        return "unknown"

def version_payload():
    import bevforge
    return {
        "name": "BevForge OS",
        "version": getattr(bevforge, "__version__", "0.0.0"),
        "git": git_info(),
        "py": sys.version.split()[0],
        "os": platform.platform(),
    }
