from __future__ import annotations

import json
import logging
import os
import shutil
import subprocess
from pathlib import Path
from typing import Dict, Iterable, List, Set, Tuple

from ..utils.usbrelay import (
    format_relay_label,
    normalize_board_id,
    parse_relay_label,
    parse_usb_map,
)

log = logging.getLogger("bevforge.pumps")

USB_RELAY_ACCESS_ERROR = "usb relay not accessible; check udev 16c0:05df"

class BasePumpDriver:
    def set(self, widget_id: int, on: bool) -> None: ...
    def get(self, widget_id: int) -> bool: ...
    def mappings(self) -> Tuple[Dict[int,int], Dict[int,str]]:
        """Return (gpio_map, usb_map) for inspection; default empty."""
        return {}, {}

# ---------------- Dummy ----------------
class DummyDriver(BasePumpDriver):
    def __init__(self):
        self.state: Dict[int, bool] = {}
    def set(self, widget_id: int, on: bool) -> None:
        prev = self.state.get(widget_id)
        if prev != on:
            self.state[widget_id] = on
            log.info("PUMP %s -> %s (dummy)", widget_id, "ON" if on else "OFF")
    def get(self, widget_id: int) -> bool:
        return bool(self.state.get(widget_id, False))

# ---------------- GPIO ----------------
class GpioZeroDriver(BasePumpDriver):
    def __init__(self):
        from gpiozero import LED  # type: ignore
        mapping = json.loads(os.getenv("PUMP_GPIO_MAP", "{}"))
        self.actors: Dict[int, LED] = {}
        self.state: Dict[int, bool] = {}
        self._gpio_map: Dict[int, int] = {}
        for wid, bcm in mapping.items():
            wid = int(wid); bcm = int(bcm)
            self.actors[wid] = LED(bcm)
            self.actors[wid].off()
            self.state[wid] = False
            self._gpio_map[wid] = bcm
            log.info("GpioZeroDriver: widget %s mapped to BCM %s", wid, bcm)
    def set(self, widget_id: int, on: bool) -> None:
        led = self.actors.get(widget_id)
        if not led:
            return
        led.on() if on else led.off()
        prev = self.state.get(widget_id)
        self.state[widget_id] = on
        if prev != on:
            pin = getattr(getattr(led, 'pin', None), 'number', '?')
            log.info("PUMP %s -> %s (gpiozero pin %s)", widget_id, "ON" if on else "OFF", pin)
    def get(self, widget_id: int) -> bool:
        return bool(self.state.get(widget_id, False))
    def mappings(self) -> Tuple[Dict[int,int], Dict[int,str]]:
        return dict(self._gpio_map), {}

# ---------------- USB (usbrelay CLI) ----------------
def _usbrelay_available() -> bool:
    return shutil.which("usbrelay") is not None

def _usbrelay_list() -> dict:
    out = subprocess.check_output(["usbrelay"], text=True).strip()
    items = {}
    for tok in out.replace("\n", " ").split():
        if "=" in tok:
            name, val = tok.split("=")
            items[name] = (val.strip() == "1")
    return items

def _usbrelay_set(name: str, on: bool) -> None:
    cmd = ["usbrelay", f"{name}={'1' if on else '0'}"]
    subprocess.run(cmd, check=True, capture_output=True, text=True)

class USBHIDRelay8Driver(BasePumpDriver):
    """Driver for DCTTech USBRelay8 (VID 16c0, PID 05df) HID boards."""

    VID = "16c0"
    PID = "05df"
    _ALLOWED_METHODS = {"auto", "hidraw", "cli"}

    def __init__(self):
        numeric_map, logical_map = parse_usb_map(os.getenv("PUMP_USB_MAP"))
        self.map: Dict[int, str] = dict(numeric_map)
        self.logical_map: Dict[str, str] = dict(logical_map)
        self.state: Dict[str, bool] = {}
        self._board_paths: Dict[str, Path] = {}
        self._board_masks: Dict[str, int] = {}
        self._board_prefixes: Dict[str, str] = {}
        self._prefix_to_board: Dict[str, str] = {}
        self._actual_labels: set[str] = set()
        self._actual_prefixes: set[str] = set()
        self._sample_labels: List[str] = []
        self._alias_cache: Dict[str, str] = {}
        self._devices_info: List[dict[str, str]] = []
        self._default_board: str | None = None
        self._env_prefix = normalize_board_id(os.getenv("USB_RELAY_LABEL_PREFIX"))
        self._preferred_prefix: str | None = self._env_prefix
        self._cli_state: Dict[str, bool] = {}
        self._cli_labels: List[str] = []
        self._cli_prefixes: Set[str] = set()
        self._usbrelay_module = self._load_usbrelay_module()
        self._cli_available = _usbrelay_available()
        self._cli_capable = bool(self._usbrelay_module) or self._cli_available
        self._method_setting = self._normalize_method(os.getenv("USB_RELAY_METHOD"))
        self._last_method: str | None = None
        self._discover_boards()
        self._initialize_state()
        self._prime_alias_cache()

    @staticmethod
    def _load_usbrelay_module():
        try:  # pragma: no cover - optional dependency
            import usbrelay  # type: ignore
        except Exception:
            return None
        return usbrelay

    @classmethod
    def _normalize_method(cls, value: str | None) -> str:
        if not value:
            return "auto"
        slug = value.strip().lower()
        return slug if slug in cls._ALLOWED_METHODS else "auto"

    @staticmethod
    def _coerce_state_value(value: object) -> bool:
        if isinstance(value, bool):
            return value
        if isinstance(value, (int, float)):
            return bool(int(value))
        if isinstance(value, str):
            lowered = value.strip().lower()
            if lowered in {"1", "on", "true", "yes"}:
                return True
            if lowered in {"0", "off", "false", "no"}:
                return False
        return bool(value)

    @classmethod
    def _coerce_label_mapping(cls, raw: object) -> dict[str, bool]:
        mapping: dict[str, bool] = {}
        if isinstance(raw, dict):
            items = raw.items()
        elif isinstance(raw, (list, tuple, set)):
            items = []
            for item in raw:
                if isinstance(item, str):
                    text = item.strip()
                    if text:
                        mapping[text] = False
                    continue
                if isinstance(item, (list, tuple)) and item:
                    label = str(item[0] or "").strip()
                    if not label:
                        continue
                    state = cls._coerce_state_value(item[1]) if len(item) > 1 else False
                    mapping[label] = state
            return mapping
        else:
            return mapping

        for key, value in items:
            label = str(key or "").strip()
            if not label:
                continue
            mapping[label] = cls._coerce_state_value(value)
        return mapping

    @classmethod
    def _module_label_mapping(cls, module: object) -> dict[str, bool]:
        candidates = [
            "list_relays",
            "list",
            "device_names",
            "devices",
            "discover",
            "relay_names",
        ]
        for name in candidates:
            func = getattr(module, name, None)
            if not callable(func):
                continue
            try:
                result = func()  # type: ignore[call-arg]
            except Exception as exc:  # pragma: no cover - optional dependency handling
                log.debug("usbrelay module %s() failed: %s", name, exc)
                continue
            mapping = cls._coerce_label_mapping(result)
            if mapping:
                return mapping
        return {}

    @classmethod
    def _gather_cli_state(cls, module: object | None = None) -> dict[str, bool]:
        mapping: dict[str, bool] = {}
        module_obj = module or cls._load_usbrelay_module()
        if module_obj is not None:
            mapping = cls._module_label_mapping(module_obj)
        if mapping:
            return {str(k).strip(): bool(v) for k, v in mapping.items() if str(k).strip()}
        if _usbrelay_available():
            try:
                mapping = _usbrelay_list()
            except Exception as exc:  # pragma: no cover - best effort logging
                log.debug("usbrelay CLI list failed: %s", exc)
                mapping = {}
        return {str(k).strip(): bool(v) for k, v in mapping.items() if str(k).strip()}

    @staticmethod
    def _read_ids(entry: Path) -> tuple[str | None, str | None]:
        device_dir = entry / "device"
        candidates = [device_dir]
        candidates.extend(list(device_dir.parents[:3]))
        for candidate in candidates:
            vid_path = candidate / "idVendor"
            pid_path = candidate / "idProduct"
            if vid_path.exists() and pid_path.exists():
                try:
                    vid = vid_path.read_text().strip().lower()
                    pid = pid_path.read_text().strip().lower()
                    return vid, pid
                except OSError:
                    continue
        return None, None

    @classmethod
    def detect_devices(cls) -> List[dict[str, str]]:
        devices: List[dict[str, str]] = []
        hid_root = Path("/sys/class/hidraw")
        try:
            entries = sorted(hid_root.glob("hidraw*")) if hid_root.exists() else []
        except Exception:
            entries = []
        for entry in entries:
            try:
                vid, pid = cls._read_ids(entry)
            except Exception:
                vid = pid = None
            if vid == cls.VID and pid == cls.PID:
                devices.append(
                    {
                        "hidraw": str(Path("/dev") / entry.name),
                        "sysfs": str(entry),
                        "vid": vid or "",
                        "pid": pid or "",
                    }
                )
        return devices

    @classmethod
    def has_devices(cls) -> bool:
        if cls.detect_devices():
            return True
        return bool(cls._gather_cli_state())

    def _discover_boards(self) -> None:
        devices = self.detect_devices()
        if not devices:
            hid_root = Path("/sys/class/hidraw")
            try:
                entries = sorted(hid_root.glob("hidraw*")) if hid_root.exists() else []
            except Exception:
                entries = []
            for entry in entries:
                vid, pid = self._read_ids(entry)
                if vid == self.VID and pid == self.PID:
                    devices.append(
                        {
                            "hidraw": str(Path("/dev") / entry.name),
                            "sysfs": str(entry),
                            "vid": vid or "",
                            "pid": pid or "",
                        }
                    )

        self._devices_info = []
        for index, info in enumerate(devices, start=1):
            board_key = normalize_board_id(f"RELAY{index}") or f"RELAY{index}"
            path_text = info.get("hidraw")
            device_path = Path(path_text) if path_text else Path("/dev") / f"hidraw{index - 1}"
            self._board_paths[board_key] = device_path
            self._board_masks.setdefault(board_key, 0)
            record = {
                "board": board_key,
                "hidraw": str(device_path),
                "vid": info.get("vid") or "",
                "pid": info.get("pid") or "",
            }
            sysfs_path = info.get("sysfs")
            if sysfs_path:
                record["sysfs"] = sysfs_path
            self._devices_info.append(record)
            log.debug("USBHIDRelay8Driver: discovered %s at %s", board_key, device_path)
        if self._board_paths:
            self._default_board = next(iter(self._board_paths))

    def _initialize_state(self) -> None:
        current = self._gather_cli_state(self._usbrelay_module)
        self._cli_state = {}
        self._cli_labels = []
        self._cli_prefixes = set()

        labels_for_record: List[str] = []
        for label, on in current.items():
            normalized = str(label or "").strip().upper()
            if not normalized:
                continue
            state_value = bool(on)
            self.state[normalized] = state_value
            self._cli_state[normalized] = state_value
            labels_for_record.append(normalized)
            parsed = parse_relay_label(normalized)
            if parsed:
                self._cli_prefixes.add(parsed[0])

        if self._cli_state:
            self._cli_labels = sorted(self._cli_state.keys())

        labels_for_record.extend(str(value or "") for value in self.logical_map.values())
        labels_for_record.extend(str(value or "") for value in self.map.values())
        self._record_labels(labels_for_record)

    def _prime_alias_cache(self) -> None:
        for alias in list(self.map.values()) + list(self.logical_map.values()):
            text = str(alias or "").strip()
            if not text:
                continue
            key = text.upper()
            if key in self._alias_cache:
                continue
            resolved = self._resolve_label(key)
            if resolved:
                self._alias_cache[key] = resolved

    def _record_labels(self, labels: Iterable[str]) -> None:
        prefix_channels: Dict[str, set[int]] = {}
        for raw in labels:
            text = str(raw or "").strip()
            if not text:
                continue
            normalized = text.upper()
            self._actual_labels.add(normalized)
            parsed = parse_relay_label(normalized)
            if not parsed:
                continue
            prefix, channel = parsed
            self._actual_prefixes.add(prefix)
            bucket = prefix_channels.setdefault(prefix, set())
            bucket.add(channel)

        if not prefix_channels:
            return

        ordered_prefixes = sorted(prefix_channels.keys())
        board_ids = list(self._board_paths.keys())
        for board_id, prefix in zip(board_ids, ordered_prefixes):
            normalized_board = normalize_board_id(board_id)
            if normalized_board:
                self._board_prefixes.setdefault(normalized_board, prefix)
                self._prefix_to_board.setdefault(prefix, normalized_board)

        if not self._preferred_prefix and ordered_prefixes:
            self._preferred_prefix = ordered_prefixes[0]

        samples: List[str] = []
        for prefix in ordered_prefixes:
            for channel in sorted(prefix_channels[prefix]):
                samples.append(format_relay_label(prefix, channel))
                if len(samples) >= 8:
                    break
            if len(samples) >= 8:
                break
        self._sample_labels = samples

        if not self._env_prefix and self._preferred_prefix and "USB_RELAY_LABEL_PREFIX" not in os.environ:
            os.environ["USB_RELAY_LABEL_PREFIX"] = self._preferred_prefix
            self._env_prefix = self._preferred_prefix

    def _ensure_permissions(self, device_path: Path | None) -> None:
        if device_path is None:
            return
        if os.access(device_path, os.R_OK | os.W_OK):
            return
        log.error("Permission denied for %s", device_path)
        raise PermissionError(USB_RELAY_ACCESS_ERROR)

    def _write_hidraw(self, board_id: str, device_path: Path, channel: int, on: bool) -> None:
        mask = self._board_masks.get(board_id, 0)
        bit = 1 << (channel - 1)
        mask = (mask | bit) if on else (mask & ~bit)
        report = bytes([0xFF, 0x01, mask, 0x00, 0x00, 0x00, 0x00, 0x00])
        fd = os.open(device_path, os.O_RDWR | os.O_CLOEXEC)
        try:
            os.write(fd, report)
        finally:
            os.close(fd)
        self._board_masks[board_id] = mask

    def _method_sequence(self, device_path: Path | None) -> List[str]:
        if self._method_setting == "hidraw":
            return ["hidraw"]
        if self._method_setting == "cli":
            return ["cli"]
        sequence: List[str] = ["hidraw"]
        sequence.append("cli")
        return sequence

    def _invoke_cli(self, label: str, on: bool) -> None:
        module_exc: Exception | None = None
        if self._usbrelay_module is not None:
            setter = getattr(self._usbrelay_module, "set_state", None)
            if callable(setter):
                try:
                    setter(label, 1 if on else 0)
                    return
                except PermissionError as exc:  # pragma: no cover - propagate permissions
                    raise exc
                except Exception as exc:  # pragma: no cover - fallback path
                    module_exc = exc
                    log.error("usbrelay python module failed for %s: %s", label, exc)
        if self._cli_available:
            try:
                _usbrelay_set(label, on)
                return
            except subprocess.CalledProcessError as exc:
                output = (exc.stderr or "") + (exc.stdout or "")  # type: ignore[attr-defined]
                if "Permission denied" in output:
                    raise PermissionError(USB_RELAY_ACCESS_ERROR) from exc
                raise RuntimeError(USB_RELAY_ACCESS_ERROR) from exc
            except Exception as exc:  # pragma: no cover - defensive fallback
                raise RuntimeError(USB_RELAY_ACCESS_ERROR) from exc
        if module_exc is not None:
            raise RuntimeError(USB_RELAY_ACCESS_ERROR) from module_exc
        raise RuntimeError(USB_RELAY_ACCESS_ERROR)

    def _apply(self, board_id: str, device_path: Path | None, channel: int, on: bool, label: str) -> str:
        methods = self._method_sequence(device_path)
        last_exc: Exception | None = None
        for method in methods:
            if method == "hidraw":
                if device_path is None:
                    last_exc = RuntimeError(USB_RELAY_ACCESS_ERROR)
                    continue
                try:
                    self._ensure_permissions(device_path)
                    self._write_hidraw(board_id, device_path, channel, on)
                    self._last_method = "hidraw"
                    return "hidraw"
                except PermissionError as exc:
                    setattr(exc, "method", "hidraw")
                    if self._method_setting != "auto":
                        raise
                    last_exc = exc
                    continue
                except Exception as exc:  # pragma: no cover - unexpected HID failure
                    log.error("USB relay HID write failed for %s channel %s: %s", board_id, channel, exc)
                    last_exc = exc
                    if self._method_setting != "auto":
                        err = RuntimeError(USB_RELAY_ACCESS_ERROR)
                        setattr(err, "method", "hidraw")
                        raise err from exc
                    continue
            else:
                try:
                    self._invoke_cli(label, on)
                    self._last_method = "cli"
                    return "cli"
                except PermissionError as exc:
                    setattr(exc, "method", "cli")
                    raise
                except Exception as exc:
                    last_exc = exc
                    if self._method_setting != "auto":
                        err = RuntimeError(USB_RELAY_ACCESS_ERROR)
                        setattr(err, "method", "cli")
                        raise err from exc
                    continue

        final_method = methods[-1] if methods else self._method_setting
        if isinstance(last_exc, PermissionError):
            err: Exception = PermissionError(USB_RELAY_ACCESS_ERROR)
        else:
            err = RuntimeError(USB_RELAY_ACCESS_ERROR)
        setattr(err, "method", final_method if final_method != "auto" else self.preferred_method())
        raise err from last_exc

    def _resolve_prefix(self, board_hint: str | None, candidate_prefix: str | None = None) -> str | None:
        if self._env_prefix:
            return self._env_prefix
        normalized_hint = normalize_board_id(board_hint)
        if normalized_hint:
            mapped = self._board_prefixes.get(normalized_hint)
            if mapped:
                return mapped
            if normalized_hint in self._actual_prefixes:
                return normalized_hint
        candidate = normalize_board_id(candidate_prefix)
        if candidate:
            if candidate in self._actual_prefixes:
                return candidate
            mapped = self._board_prefixes.get(candidate)
            if mapped:
                return mapped
        if self._preferred_prefix:
            return self._preferred_prefix
        if self._board_prefixes:
            return next(iter(self._board_prefixes.values()))
        return candidate or normalized_hint

    def _resolve_label(
        self,
        label: str | None,
        *,
        board_id: str | None = None,
        channel: int | None = None,
    ) -> str | None:
        alias = (label or "").strip().upper()
        if alias and alias in self._alias_cache:
            return self._alias_cache[alias]

        normalized_hint = normalize_board_id(board_id)
        alias_channel = channel
        candidate_prefix = None

        parsed = parse_relay_label(alias) if alias else None
        if parsed:
            candidate_prefix, parsed_channel = parsed
            alias_channel = alias_channel or parsed_channel
            if not normalized_hint:
                normalized_hint = normalize_board_id(candidate_prefix)

        resolved_prefix = self._resolve_prefix(normalized_hint, candidate_prefix)
        if resolved_prefix and alias_channel:
            actual = format_relay_label(resolved_prefix, alias_channel)
            uppercase_actual = actual.upper()
            self._actual_labels.add(uppercase_actual)
            self._actual_prefixes.add(resolved_prefix)
            hint_board = normalized_hint or normalize_board_id(candidate_prefix)
            if hint_board:
                self._board_prefixes.setdefault(hint_board, resolved_prefix)
                self._prefix_to_board.setdefault(resolved_prefix, hint_board)
            if alias:
                self._alias_cache[alias] = uppercase_actual
            return uppercase_actual

        if alias:
            return alias
        return None

    def resolve_label(
        self,
        label: str | None,
        *,
        board_id: str | None = None,
        channel: int | None = None,
    ) -> str | None:
        return self._resolve_label(label, board_id=board_id, channel=channel)

    def preferred_method(self) -> str:
        if self._method_setting != "auto":
            return self._method_setting
        if self._last_method:
            return self._last_method
        if self._board_paths:
            return "hidraw"
        if self._cli_labels or self._cli_capable:
            return "cli"
        return "hidraw"

    @property
    def method_setting(self) -> str:
        return self._method_setting

    @property
    def last_method(self) -> str | None:
        return self._last_method

    def health(self) -> dict[str, object]:
        detected = [dict(info) for info in self._devices_info]
        cli_devices = list(self._cli_labels)
        cli_prefixes = set(self._cli_prefixes)
        device_count = len(detected)
        if cli_prefixes:
            device_count = max(device_count, len(cli_prefixes))
        elif cli_devices:
            device_count = max(device_count, 1)

        method_display = self._method_setting
        if self._method_setting == "auto":
            method_display = f"auto->{self.preferred_method()}"

        return {
            "detected_devices": detected,
            "discovered_prefix": self._preferred_prefix,
            "env_prefix": self._env_prefix,
            "board_prefixes": dict(self._board_prefixes),
            "sample_labels": list(self._sample_labels),
            "known_prefixes": sorted(self._actual_prefixes),
            "cli_devices": cli_devices,
            "device_count": device_count,
            "method": method_display,
        }

    def set_channel(
        self,
        board_id: str | None,
        channel: int,
        on: bool,
        alias_label: str | None = None,
    ) -> str:
        normalized = normalize_board_id(board_id)
        if not normalized:
            if len(self._board_paths) == 1:
                normalized = next(iter(self._board_paths))
            elif not self._board_paths:
                normalized = "RELAY1"
            else:
                raise ValueError("board must be provided when multiple USB relay boards are connected")
        if channel < 1 or channel > 8:
            raise ValueError("channel must be between 1 and 8")

        alias_text = (alias_label or format_relay_label(normalized, channel)).strip().upper()
        resolved_label = self._resolve_label(alias_text, board_id=normalized, channel=channel)
        if not resolved_label:
            raise ValueError("unknown relay_label or channel")

        parsed = parse_relay_label(resolved_label)
        if not parsed:
            raise ValueError("unknown relay_label or channel")
        resolved_prefix, resolved_channel = parsed

        board_for_write = self._prefix_to_board.get(resolved_prefix) or normalized
        device_path = self._board_paths.get(board_for_write)
        if device_path is None and self._default_board:
            fallback = self._board_paths.get(self._default_board)
            if fallback is not None:
                device_path = fallback
                board_for_write = self._default_board

        if device_path is None and self._method_setting == "hidraw":
            raise RuntimeError(USB_RELAY_ACCESS_ERROR)

        alias_display = format_relay_label(normalized, resolved_channel)
        self._alias_cache[alias_text] = resolved_label
        self._alias_cache[alias_display] = resolved_label
        self._prefix_to_board.setdefault(resolved_prefix, board_for_write)
        self._board_prefixes.setdefault(board_for_write, resolved_prefix)

        method_used = self._apply(board_for_write, device_path, resolved_channel, on, resolved_label)

        state_value = bool(on)
        self._actual_labels.add(resolved_label)
        self._actual_prefixes.add(resolved_prefix)
        self.state[resolved_label] = state_value
        self.state[alias_text] = state_value
        self.state[alias_display] = state_value

        if method_used == "cli" or resolved_label in self._cli_state:
            self._cli_state[resolved_label] = state_value
            if resolved_label not in self._cli_labels:
                self._cli_labels.append(resolved_label)
                self._cli_labels.sort()
            parsed_cli = parse_relay_label(resolved_label)
            if parsed_cli:
                self._cli_prefixes.add(parsed_cli[0])

        status = "ON" if on else "OFF"
        if alias_display != resolved_label:
            log.info("USB relay %s (%s) -> %s via %s", resolved_label, alias_display, status, method_used)
        else:
            log.info("USB relay %s -> %s via %s", resolved_label, status, method_used)

        return method_used

    def set_by_label(self, relay_label: str, on: bool) -> str:
        alias = str(relay_label or "").strip()
        if not alias:
            raise ValueError("unknown relay_label or channel")
        alias_upper = alias.upper()
        parsed = parse_relay_label(alias_upper)
        if parsed:
            board_id, channel = parsed
            board_hint = self._prefix_to_board.get(board_id) or board_id
            return self.set_channel(board_hint, channel, on, alias_label=alias_upper)

        resolved = self._resolve_label(alias_upper)
        if not resolved:
            raise ValueError("unknown relay_label or channel")
        parsed_resolved = parse_relay_label(resolved)
        if not parsed_resolved:
            raise ValueError("unknown relay_label or channel")
        resolved_prefix, resolved_channel = parsed_resolved
        board_hint = self._prefix_to_board.get(resolved_prefix) or resolved_prefix
        return self.set_channel(board_hint, resolved_channel, on, alias_label=alias_upper)

    def get_label_state(self, relay_label: str) -> bool | None:
        if not relay_label:
            return None
        alias = relay_label.strip().upper()
        if alias in self.state:
            return self.state.get(alias)
        resolved = self._alias_cache.get(alias) or self._resolve_label(alias)
        if resolved:
            return self.state.get(resolved)
        return None

    def set(self, widget_id: int, on: bool) -> None:
        label = self.map.get(widget_id)
        if not label:
            log.debug("USBHIDRelay8Driver: widget %s not mapped", widget_id)
            return
        method_used = self.set_by_label(label, on)
        log.info(
            "PUMP %s -> %s (USB relay %s via %s)",
            widget_id,
            "ON" if on else "OFF",
            label,
            method_used,
        )

    def get(self, widget_id: int) -> bool:
        label = self.map.get(widget_id)
        if not label:
            return False
        alias = str(label or "").strip().upper()
        resolved = self._alias_cache.get(alias) or self._resolve_label(alias)
        key = resolved or alias
        return bool(self.state.get(key, False))

    def mappings(self) -> Tuple[Dict[int, int], Dict[int, str]]:
        return {}, dict(self.map)

    def logical_mappings(self) -> Dict[str, str]:
        return dict(self.logical_map)

    @property
    def default_board(self) -> str | None:
        return self._default_board

# ---------------- Mixed ----------------
class MixedDriver(BasePumpDriver):
    def __init__(self):
        self.gpio = None
        self.usb = None
        try:
            self.gpio = GpioZeroDriver()
        except Exception as e:
            log.error("MixedDriver: GPIO unavailable: %s", e)
        try:
            self.usb = USBHIDRelay8Driver()
        except Exception as e:
            log.error("MixedDriver: USB unavailable: %s", e)
        if not self.gpio and not self.usb:
            raise RuntimeError("MixedDriver: no backends available")
    def set(self, widget_id: int, on: bool) -> None:
        if self.gpio and widget_id in getattr(self.gpio, "actors", {}):
            self.gpio.set(widget_id, on)
        elif self.usb and widget_id in getattr(self.usb, "map", {}):
            self.usb.set(widget_id, on)
        else:
            log.warning("MixedDriver: widget %s not mapped", widget_id)
    def get(self, widget_id: int) -> bool:
        if self.gpio and widget_id in getattr(self.gpio, "actors", {}):
            return self.gpio.get(widget_id)
        if self.usb and widget_id in getattr(self.usb, "map", {}):
            return self.usb.get(widget_id)
        return False
    def mappings(self) -> Tuple[Dict[int,int], Dict[int,str]]:
        g = getattr(self.gpio, "_gpio_map", {}) if self.gpio else {}
        u = getattr(self.usb,  "map",      {}) if self.usb  else {}
        return dict(g), dict(u)

# ---------------- Selector + Manager ----------------
def _select_driver(backend: str | None = None) -> BasePumpDriver:
    slug = _normalize_backend(
        backend if backend is not None else os.getenv("PUMP_BACKEND"),
        default="auto",
    )
    slug = _resolve_backend_slug(slug)
    if slug == "gpio":
        return GpioZeroDriver()
    if slug == "usb":
        return USBHIDRelay8Driver()
    if slug == "mixed":
        return MixedDriver()
    return DummyDriver()

def _load_gpio_map() -> Dict[int, int]:
    try:
        raw = json.loads(os.getenv("PUMP_GPIO_MAP", "{}") or "{}")
    except json.JSONDecodeError:
        raw = {}
    result: Dict[int, int] = {}
    for key, value in (raw or {}).items():
        try:
            result[int(key)] = int(value)
        except (TypeError, ValueError):
            continue
    return result


def _load_usb_map() -> tuple[Dict[int, str], Dict[str, str], bool]:
    raw_value = os.getenv("PUMP_USB_MAP")
    numeric, logical = parse_usb_map(raw_value)
    prefer_pairs = bool(
        raw_value
        and raw_value.strip()
        and not raw_value.strip().startswith("{")
        and ":" in raw_value
    )
    return numeric, logical, prefer_pairs


_BACKEND_LABELS = {
    "auto": "Auto",
    "dummy": "Dummy",
    "gpio": "GPIO",
    "usb": "USB",
    "mixed": "Mixed",
}


def _normalize_backend(name: str | None, *, default: str = "dummy") -> str:
    slug = (name or default).strip().lower()
    return slug if slug in _BACKEND_LABELS else "dummy"


def _display_backend(slug: str) -> str:
    return _BACKEND_LABELS.get(slug, slug.title())


def _resolve_backend_slug(slug: str) -> str:
    if slug == "auto":
        return "usb" if USBHIDRelay8Driver.has_devices() else "dummy"
    return slug


class PumpManager:
    def __init__(self):
        self.gpio_map: Dict[int, int] = _load_gpio_map()
        usb_map, usb_logical, prefer_pairs = _load_usb_map()
        self.usb_map: Dict[int, str] = usb_map
        self.usb_logical_map: Dict[str, str] = usb_logical
        self._usb_prefers_pairs = prefer_pairs
        requested_backend = _normalize_backend(os.getenv("PUMP_BACKEND"), default="auto")
        self.requested_backend_slug: str = requested_backend
        resolved_backend = _resolve_backend_slug(requested_backend)
        self.backend_slug: str = resolved_backend
        self.backend_name: str = _display_backend(self.backend_slug)
        os.environ["PUMP_BACKEND"] = self.backend_slug
        self._write_maps_to_env()
        try:
            self.driver: BasePumpDriver = _select_driver(self.backend_slug)
        except Exception as exc:  # pragma: no cover - defensive fallback
            log.error("Failed to initialize %s backend: %s; falling back to Dummy", self.backend_slug, exc)
            self.backend_slug = "dummy"
            self.backend_name = _display_backend(self.backend_slug)
            os.environ["PUMP_BACKEND"] = self.backend_slug
            self.driver = _select_driver(self.backend_slug)
            self.requested_backend_slug = self.backend_slug
        self._sync_driver_maps()
        if self.requested_backend_slug != self.backend_slug:
            log.info(
                "Pump backend active: %s (requested %s)",
                self.backend_name,
                _display_backend(self.requested_backend_slug),
            )
        else:
            log.info("Pump backend active: %s", self.backend_name)

    def _write_maps_to_env(self) -> None:
        if self.gpio_map:
            os.environ["PUMP_GPIO_MAP"] = json.dumps({str(k): int(v) for k, v in self.gpio_map.items()})
        else:
            os.environ.pop("PUMP_GPIO_MAP", None)
        if self.usb_map:
            serialized = {str(k): str(v) for k, v in self.usb_map.items()}
            self.usb_logical_map = dict(serialized)
            os.environ["PUMP_USB_MAP"] = json.dumps(serialized)
            self._usb_prefers_pairs = False
        elif self.usb_logical_map:
            if self._usb_prefers_pairs:
                pairs = ",".join(f"{k}:{v}" for k, v in self.usb_logical_map.items())
                os.environ["PUMP_USB_MAP"] = pairs
            else:
                os.environ["PUMP_USB_MAP"] = json.dumps(self.usb_logical_map)
        else:
            os.environ.pop("PUMP_USB_MAP", None)

    def _sync_driver_maps(self) -> None:
        driver = getattr(self, "driver", None)
        if not driver:
            return
        if hasattr(driver, "map"):
            try:
                driver.map = dict(self.usb_map)
            except Exception:
                pass
        if hasattr(driver, "logical_map"):
            try:
                driver.logical_map = dict(self.usb_logical_map)
            except Exception:
                pass

    def configure(self, backend: str | None = None) -> bool:
        requested = _normalize_backend(
            backend if backend is not None else self.requested_backend_slug,
            default="auto",
        )
        previous_env = os.environ.get("PUMP_BACKEND")
        previous_driver = self.driver
        previous_slug = self.backend_slug
        previous_name = self.backend_name
        previous_requested = self.requested_backend_slug

        resolved = _resolve_backend_slug(requested)
        os.environ["PUMP_BACKEND"] = resolved
        self.backend_slug = resolved
        self.backend_name = _display_backend(resolved)
        self.requested_backend_slug = requested
        self._write_maps_to_env()
        try:
            driver = _select_driver(resolved)
        except Exception as exc:
            log.error("Pump backend switch to %s failed: %s", requested, exc)
            if previous_env is None:
                os.environ.pop("PUMP_BACKEND", None)
            else:
                os.environ["PUMP_BACKEND"] = previous_env
            self.driver = previous_driver
            self.backend_slug = previous_slug
            self.backend_name = previous_name
            self.requested_backend_slug = previous_requested
            return False
        self.driver = driver
        self._sync_driver_maps()
        if requested != resolved:
            log.info(
                "Pump backend switched to %s (requested %s)",
                self.backend_name,
                _display_backend(requested),
            )
        else:
            log.info("Pump backend switched to %s", self.backend_name)
        return True

    def reload(self) -> str:
        self.configure(self.requested_backend_slug)
        return self.driver.__class__.__name__

    def set_pump(self, widget_id: int, on: bool) -> None:
        self.driver.set(widget_id, on)

    def get_state(self, widget_id: int) -> bool:
        return self.driver.get(widget_id)

    def update_maps(self, *, gpio: Dict[int, int] | None = None, usb: Dict[int, str] | None = None) -> bool:
        changed = False
        if gpio is not None:
            sanitized: Dict[int, int] = {}
            for key, value in gpio.items():
                try:
                    sanitized[int(key)] = int(value)
                except (TypeError, ValueError):
                    continue
            if sanitized != self.gpio_map:
                self.gpio_map = sanitized
                changed = True
        if usb is not None:
            sanitized_usb: Dict[int, str] = {}
            for key, value in usb.items():
                try:
                    sanitized_usb[int(key)] = str(value)
                except (TypeError, ValueError):
                    continue
            if sanitized_usb != self.usb_map:
                self.usb_map = sanitized_usb
                self.usb_logical_map = {str(k): str(v) for k, v in sanitized_usb.items()}
                self._usb_prefers_pairs = False
                changed = True
        if not changed:
            self._write_maps_to_env()
            return True
        self._write_maps_to_env()
        ok = self.configure(self.requested_backend_slug)
        if not ok:
            log.warning("Pump driver reload failed; retaining previous driver")
        return ok

    def map_gpio(self, widget_id: int, pin: int) -> bool:
        try:
            wid = int(widget_id)
            bcm = int(pin)
        except (TypeError, ValueError):
            return False
        new_map = dict(self.gpio_map)
        new_map[wid] = bcm
        return self.update_maps(gpio=new_map)

    def map_usb(self, widget_id: int, usb_id: str) -> bool:
        try:
            wid = int(widget_id)
        except (TypeError, ValueError):
            return False
        relay = str(usb_id or "").strip()
        if not relay:
            return False
        new_map = dict(self.usb_map)
        new_map[wid] = relay
        return self.update_maps(usb=new_map)

    def unmap(self, widget_id: int) -> bool:
        try:
            wid = int(widget_id)
        except (TypeError, ValueError):
            return False
        new_gpio = dict(self.gpio_map)
        new_usb = dict(self.usb_map)
        removed = False
        if wid in new_gpio:
            new_gpio.pop(wid, None)
            removed = True
        if wid in new_usb:
            new_usb.pop(wid, None)
            removed = True
        if not removed:
            return True
        return self.update_maps(gpio=new_gpio, usb=new_usb)

    def mappings(self) -> dict:
        return {
            "backend": self.backend_name,
            "backend_slug": self.backend_slug,
            "backend_requested": getattr(self, "requested_backend_slug", self.backend_slug),
            "gpio": dict(self.gpio_map),
            "usb": dict(self.usb_map),
            "usb_logical": dict(self.usb_logical_map),
        }

    def describe(self) -> dict:
        info = self.mappings()
        info["driver"] = self.driver.__class__.__name__
        return info


    def _usb_driver_instance(self) -> USBHIDRelay8Driver | None:
        driver = getattr(self, "driver", None)
        if isinstance(driver, USBHIDRelay8Driver):
            return driver
        usb = getattr(driver, "usb", None)
        if isinstance(usb, USBHIDRelay8Driver):
            return usb
        return None


    def relay_health(self) -> dict[str, object]:
        info: dict[str, object] = {
            "ok": True,
            "backend_active": self.backend_slug,
            "backend_display": self.backend_name,
            "backend_requested": getattr(self, "requested_backend_slug", self.backend_slug),
        }

        usb_driver = self._usb_driver_instance()
        if usb_driver:
            info.update(usb_driver.health())
            info["usb_backend_available"] = True
        else:
            info["usb_backend_available"] = False
            detected = USBHIDRelay8Driver.detect_devices()
            cli_state = USBHIDRelay8Driver._gather_cli_state()
            cli_devices = sorted({str(label or "").strip().upper() for label in cli_state.keys() if str(label or "").strip()})
            cli_prefixes = {
                parsed[0]
                for parsed in (parse_relay_label(label) for label in cli_devices)
                if parsed
            }
            device_count = len(detected)
            if cli_prefixes:
                device_count = max(device_count, len(cli_prefixes))
            elif cli_devices:
                device_count = max(device_count, 1)

            method_setting = USBHIDRelay8Driver._normalize_method(os.getenv("USB_RELAY_METHOD"))
            if method_setting == "auto":
                fallback = "hidraw" if detected else ("cli" if cli_devices else "hidraw")
                method_display = f"auto->{fallback}"
            else:
                method_display = method_setting

            info["detected_devices"] = detected
            info["cli_devices"] = cli_devices
            info["discovered_prefix"] = None
            info["sample_labels"] = cli_devices[:8]
            info["env_prefix"] = normalize_board_id(os.getenv("USB_RELAY_LABEL_PREFIX"))
            info["board_prefixes"] = {}
            info["known_prefixes"] = sorted(cli_prefixes)
            info["device_count"] = device_count
            info["method"] = method_display

        if "device_count" not in info:
            info["device_count"] = len(info.get("detected_devices", []))
        info["backend_options"] = list(_BACKEND_LABELS.keys())
        return info


pump_manager = PumpManager()
