from __future__ import annotations

"""Tilt Hydrometer BLE background scanner using bleak.

Usage notes:
    * Enable the scanner with ``TILT_BLE_ENABLE=1``.
    * On Raspberry Pi OS ensure Bluetooth support is installed::

          sudo apt-get update
          sudo apt-get install -y bluetooth bluez
          sudo systemctl enable --now bluetooth
"""

import asyncio
import contextlib
import logging
from datetime import datetime
from typing import Any, TYPE_CHECKING
from uuid import UUID

from fastapi import FastAPI
from sqlmodel import select

from ..db import session_factory
from ..models import HydrometerLatest

try:  # pragma: no cover - exercised in deployment environments
    from bleak import BleakScanner
except Exception as exc:  # pragma: no cover - import guard for optional dependency
    BleakScanner = None  # type: ignore[assignment]
    _BLEAK_IMPORT_ERROR = exc
else:  # pragma: no cover - import guard for optional dependency
    _BLEAK_IMPORT_ERROR = None

if TYPE_CHECKING:  # pragma: no cover - typing helpers only
    from bleak.backends.device import BLEDevice
    from bleak.backends.scanner import AdvertisementData


log = logging.getLogger("bevforge.services.tilt_ble")

APPLE_MANUFACTURER_ID = 0x004C
IBEACON_PREFIX = b"\x02\x15"
_RESTART_DELAY_SECONDS = 5.0

TILT_UUID_TO_COLOR: dict[str, str] = {
    "A495BB10-C5B1-4B44-B512-1370F02D74DE": "red",
    "A495BB20-C5B1-4B44-B512-1370F02D74DE": "green",
    "A495BB30-C5B1-4B44-B512-1370F02D74DE": "black",
    "A495BB40-C5B1-4B44-B512-1370F02D74DE": "purple",
    "A495BB50-C5B1-4B44-B512-1370F02D74DE": "orange",
    "A495BB60-C5B1-4B44-B512-1370F02D74DE": "blue",
    "A495BB70-C5B1-4B44-B512-1370F02D74DE": "yellow",
    "A495BB80-C5B1-4B44-B512-1370F02D74DE": "pink",
}


async def start_scanner(app: FastAPI) -> None:
    """Background task that listens for Tilt hydrometer BLE broadcasts."""

    app.state.tilt_ble_status = {}
    app.state.tilt_ble_last_error = None
    app.state.tilt_ble_import_error = None

    if BleakScanner is None:
        message = f"bleak import failed: {_BLEAK_IMPORT_ERROR}" if _BLEAK_IMPORT_ERROR else "bleak import failed"
        app.state.tilt_ble_import_error = message
        app.state.tilt_ble_last_error = message
        log.error("Tilt BLE scanner unavailable: %s", message)
        return

    status: dict[str, dict[str, Any]] = app.state.tilt_ble_status
    stop_event = asyncio.Event()
    app.state.tilt_ble_stop_event = stop_event
    pending: set[asyncio.Task[None]] = set()
    app.state.tilt_ble_persist_tasks = pending
    app.state.tilt_ble_running = True

    loop = asyncio.get_running_loop()

    async def persist_reading(color: str, temp_f: float, sg: float) -> None:
        """Persist a single Tilt reading in a background thread."""

        def _write() -> None:
            session = session_factory()
            try:
                row = session.exec(
                    select(HydrometerLatest).where(HydrometerLatest.color == color)
                ).first()
                if not row:
                    row = HydrometerLatest(color=color, temp_f=temp_f, sg=sg)
                    session.add(row)
                else:
                    row.temp_f = temp_f
                    row.sg = sg
                row.updated_at = datetime.utcnow()
                session.commit()
            except Exception as exc:  # pragma: no cover - defensive logging for deployment
                session.rollback()
                raise exc
            finally:
                session.close()

        try:
            await asyncio.to_thread(_write)
        except Exception as exc:  # pragma: no cover - defensive logging for deployment
            message = f"persist failure: {exc}"
            app.state.tilt_ble_last_error = message
            log.exception("Tilt BLE persist failure for %s: %s", color, exc)
        else:
            app.state.tilt_ble_last_error = None

    def handle_detection(device: "BLEDevice", advertisement_data: "AdvertisementData") -> None:
        if stop_event.is_set():
            return

        manufacturer_data = advertisement_data.manufacturer_data or {}
        payload = manufacturer_data.get(APPLE_MANUFACTURER_ID)
        if not payload:
            return

        data = bytes(payload)
        if len(data) < 23 or data[0:2] != IBEACON_PREFIX:
            return

        try:
            uuid = str(UUID(bytes=data[2:18])).upper()
        except Exception:  # pragma: no cover - defensive parsing guard
            return

        color = TILT_UUID_TO_COLOR.get(uuid)
        if not color:
            return

        major = int.from_bytes(data[18:20], "big")
        minor = int.from_bytes(data[20:22], "big")
        temp_f = float(major)
        sg = minor / 1000.0
        timestamp = datetime.utcnow().isoformat() + "Z"

        status[color] = {
            "temp_f": temp_f,
            "sg": sg,
            "rssi": advertisement_data.rssi,
            "ts": timestamp,
        }

        try:
            task = loop.create_task(persist_reading(color, temp_f, sg))
        except RuntimeError:  # pragma: no cover - loop closing during shutdown
            log.debug("Event loop closed; dropping Tilt reading for %s", color)
            return

        pending.add(task)
        task.add_done_callback(pending.discard)

    while not stop_event.is_set():
        try:
            log.info("Starting Tilt BLE scanner loop.")
            async with BleakScanner(detection_callback=handle_detection):
                await stop_event.wait()
                break
        except asyncio.CancelledError:
            raise
        except Exception as exc:  # pragma: no cover - hardware/environment specific errors
            message = f"scanner error: {exc}"
            app.state.tilt_ble_last_error = message
            log.exception("Tilt BLE scanner error: %s", exc)
            if stop_event.is_set():
                break
            await asyncio.sleep(_RESTART_DELAY_SECONDS)

    if pending:
        with contextlib.suppress(Exception):
            await asyncio.gather(*pending, return_exceptions=True)
        pending.clear()

    app.state.tilt_ble_running = False
    log.info("Tilt BLE scanner stopped.")


async def stop_scanner(app: FastAPI) -> None:
    """Signal the background scanner to stop and wait for completion."""

    stop_event: asyncio.Event | None = getattr(app.state, "tilt_ble_stop_event", None)
    if stop_event and not stop_event.is_set():
        stop_event.set()

    task: asyncio.Task | None = getattr(app.state, "tilt_ble_task", None)
    if task and not task.done():
        with contextlib.suppress(asyncio.CancelledError):
            await task

    pending: set[asyncio.Task] | None = getattr(app.state, "tilt_ble_persist_tasks", None)
    if pending:
        for t in list(pending):
            if not t.done():
                t.cancel()
        with contextlib.suppress(Exception):
            await asyncio.gather(*pending, return_exceptions=True)
        pending.clear()

    app.state.tilt_ble_task = None
    app.state.tilt_ble_stop_event = None
    app.state.tilt_ble_persist_tasks = set()


__all__ = ["start_scanner", "stop_scanner", "TILT_UUID_TO_COLOR"]
