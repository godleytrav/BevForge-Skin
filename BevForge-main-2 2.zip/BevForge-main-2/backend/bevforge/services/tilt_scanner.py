from __future__ import annotations

import asyncio
import contextlib
import logging
from collections import defaultdict
from datetime import datetime
from typing import Any, Dict
from uuid import UUID

from fastapi import FastAPI
from sqlmodel import select

from ..db import session_factory
from ..models import HydrometerLatest

try:  # pragma: no cover - optional dependency guard
    from bleak import BleakScanner
except Exception as exc:  # pragma: no cover - bleak import guard
    BleakScanner = None  # type: ignore[assignment]
    _BLEAK_IMPORT_ERROR = exc
else:  # pragma: no cover - bleak import guard
    _BLEAK_IMPORT_ERROR = None


log = logging.getLogger("bevforge.services.tilt_scanner")

APPLE_MANUFACTURER_ID = 0x004C
IBEACON_PREFIX = b"\x02\x15"
_RESTART_DELAY_SECONDS = 5.0
_SCAN_ONCE_SECONDS = 7.0

TILT_UUID_TO_COLOR: Dict[str, str] = {
    "A495BB10-C5B1-4B44-B512-1370F02D74DE": "red",
    "A495BB20-C5B1-4B44-B512-1370F02D74DE": "green",
    "A495BB30-C5B1-4B44-B512-1370F02D74DE": "black",
    "A495BB40-C5B1-4B44-B512-1370F02D74DE": "purple",
    "A495BB50-C5B1-4B44-B512-1370F02D74DE": "orange",
    "A495BB60-C5B1-4B44-B512-1370F02D74DE": "blue",
    "A495BB70-C5B1-4B44-B512-1370F02D74DE": "yellow",
    "A495BB80-C5B1-4B44-B512-1370F02D74DE": "pink",
}


class TiltScannerService:
    """Manage background BLE scans and manual Tilt sweeps."""

    def __init__(self, app: FastAPI):
        self.app = app
        self.status: dict[str, dict[str, Any]] = {}
        self.running: bool = False
        self.last_error: str | None = None
        self.import_error: str | None = None
        self.task: asyncio.Task[None] | None = None
        self.stop_event: asyncio.Event | None = None
        self.persist_tasks: set[asyncio.Task[None]] = set()
        self._loop: asyncio.AbstractEventLoop | None = None
        self._scan_lock = asyncio.Lock()
        self._sync_state()

    def is_active(self) -> bool:
        task = self.task
        if task and not task.done():
            return True
        return bool(self.running)

    def _sync_state(self) -> None:
        self.app.state.tilt_scanner = self
        self.app.state.tilt_ble_status = self.status
        self.app.state.tilt_ble_running = self.is_active()
        self.app.state.tilt_ble_last_error = self.last_error
        self.app.state.tilt_ble_import_error = self.import_error
        self.app.state.tilt_ble_task = self.task
        self.app.state.tilt_ble_stop_event = self.stop_event
        self.app.state.tilt_ble_persist_tasks = self.persist_tasks

    def _set_import_error(self, message: str) -> None:
        self.import_error = message
        self.last_error = message
        self.running = False
        self.task = None
        if self.stop_event is not None:
            self.stop_event = None
        if self.persist_tasks:
            self.persist_tasks.clear()
        self._sync_state()

    def set_last_error(self, message: str | None) -> None:
        self.last_error = message
        self._sync_state()

    def _update_status(self, color: str, temp_f: float, sg: float, rssi: int | None) -> None:
        timestamp = datetime.utcnow().isoformat() + "Z"
        self.status[color] = {
            "temp_f": temp_f,
            "sg": sg,
            "rssi": rssi,
            "ts": timestamp,
        }
        self._sync_state()

    async def start(self) -> None:
        """Start the background scanner loop if possible."""

        if self.task and not self.task.done():
            log.debug("Tilt scanner already running.")
            return

        if BleakScanner is None:
            message = (
                f"bleak import failed: {_BLEAK_IMPORT_ERROR}"
                if _BLEAK_IMPORT_ERROR
                else "bleak import failed"
            )
            log.error("Tilt BLE scanner unavailable: %s", message)
            self._set_import_error(message)
            return

        self.stop_event = asyncio.Event()
        self.persist_tasks = set()
        try:
            self._loop = asyncio.get_running_loop()
        except RuntimeError:
            self._loop = None
        try:
            self.task = asyncio.create_task(self._run_loop())
        except RuntimeError as exc:
            message = f"failed to schedule scanner: {exc}"
            log.error("Tilt BLE scanner scheduling failed: %s", exc)
            self.last_error = message
            self.task = None
            self.stop_event = None
        else:
            self.import_error = None
            log.info("Tilt BLE scanner task created.")
        self._sync_state()

    async def stop(self) -> None:
        """Signal the scanner to stop and wait for completion."""

        if self.stop_event and not self.stop_event.is_set():
            self.stop_event.set()

        task = self.task
        if task and not task.done():
            with contextlib.suppress(asyncio.CancelledError):
                await task
        self.task = None

        if self.persist_tasks:
            for pending in list(self.persist_tasks):
                if not pending.done():
                    pending.cancel()
            with contextlib.suppress(Exception):
                await asyncio.gather(*self.persist_tasks, return_exceptions=True)
            self.persist_tasks.clear()

        self.running = False
        self.stop_event = None
        self._sync_state()

    async def _run_loop(self) -> None:
        assert self.stop_event is not None

        while not self.stop_event.is_set():
            try:
                log.info("Starting Tilt BLE scanner loop.")
                async with BleakScanner(detection_callback=self._handle_detection):
                    self.running = True
                    self.last_error = None
                    self._sync_state()
                    await self.stop_event.wait()
                    break
            except asyncio.CancelledError:
                raise
            except Exception as exc:  # pragma: no cover - hardware specific errors
                message = f"scanner error: {exc}"
                self.last_error = message
                self.running = False
                self._sync_state()
                log.exception("Tilt BLE scanner error: %s", exc)
                if self.stop_event.is_set():
                    break
                await asyncio.sleep(_RESTART_DELAY_SECONDS)

        if self.persist_tasks:
            with contextlib.suppress(Exception):
                await asyncio.gather(*self.persist_tasks, return_exceptions=True)
            self.persist_tasks.clear()

        self.running = False
        self._sync_state()
        log.info("Tilt BLE scanner stopped.")

    def _handle_detection(self, device: Any, advertisement_data: Any) -> None:
        if not self.stop_event or self.stop_event.is_set():
            return

        parsed = self._parse_advertisement(advertisement_data)
        if not parsed:
            return

        color, temp_f, sg = parsed
        rssi = getattr(advertisement_data, "rssi", None)
        self._update_status(color, temp_f, sg, rssi)

        loop = self._loop
        if not loop:
            try:
                loop = asyncio.get_running_loop()
            except RuntimeError:
                loop = None
        if not loop:
            log.debug("No running loop available for persistence; dropping Tilt reading for %s", color)
            return

        try:
            task = loop.create_task(self._persist_reading(color, temp_f, sg))
        except RuntimeError:
            log.debug("Event loop closed; dropping Tilt reading for %s", color)
            return
        self.persist_tasks.add(task)
        task.add_done_callback(self.persist_tasks.discard)

    @staticmethod
    def _parse_advertisement(advertisement_data: Any) -> tuple[str, float, float] | None:
        manufacturer_data = getattr(advertisement_data, "manufacturer_data", None) or {}
        payload = manufacturer_data.get(APPLE_MANUFACTURER_ID)
        if not payload:
            return None

        data = bytes(payload)
        if len(data) < 23 or data[0:2] != IBEACON_PREFIX:
            return None

        try:
            uuid = str(UUID(bytes=data[2:18])).upper()
        except Exception:  # pragma: no cover - defensive parsing guard
            return None

        color = TILT_UUID_TO_COLOR.get(uuid)
        if not color:
            return None

        major = int.from_bytes(data[18:20], "big")
        minor = int.from_bytes(data[20:22], "big")
        temp_f = float(major)
        sg = minor / 1000.0
        return color, temp_f, sg

    async def _persist_reading(self, color: str, temp_f: float, sg: float) -> None:
        def _write() -> None:
            session = session_factory()
            try:
                row = session.exec(
                    select(HydrometerLatest).where(HydrometerLatest.color == color)
                ).first()
                if not row:
                    row = HydrometerLatest(color=color, temp_f=temp_f, sg=sg)
                    session.add(row)
                else:
                    row.temp_f = temp_f
                    row.sg = sg
                row.updated_at = datetime.utcnow()
                session.commit()
            except Exception as exc:  # pragma: no cover - deployment diagnostics
                session.rollback()
                raise exc
            finally:
                session.close()

        try:
            await asyncio.to_thread(_write)
        except Exception as exc:  # pragma: no cover - deployment diagnostics
            message = f"persist failure: {exc}"
            self.last_error = message
            self._sync_state()
            log.exception("Tilt BLE persist failure for %s: %s", color, exc)
        else:
            if self.last_error:
                self.last_error = None
                self._sync_state()

    async def scan_once(self, duration: float | None = None) -> dict[str, Any]:
        """Perform a one-off scan and persist any readings."""

        if duration is None:
            duration = _SCAN_ONCE_SECONDS

        if BleakScanner is None:
            message = (
                f"bleak import failed: {_BLEAK_IMPORT_ERROR}"
                if _BLEAK_IMPORT_ERROR
                else "bleak import failed"
            )
            log.warning("Tilt scan-once unavailable: %s", message)
            return {
                "ok": False,
                "counts": {"total": 0, "colors": {}},
                "running": self.is_active(),
                "note": message,
            }

        async with self._scan_lock:
            loop = None
            try:
                loop = asyncio.get_running_loop()
            except RuntimeError:
                pass

            seen = defaultdict(int)
            manual_tasks: set[asyncio.Task[None]] = set()

            def handle_once(device: Any, advertisement_data: Any) -> None:
                parsed = self._parse_advertisement(advertisement_data)
                if not parsed:
                    return
                color, temp_f, sg = parsed
                seen[color] += 1
                rssi = getattr(advertisement_data, "rssi", None)
                self._update_status(color, temp_f, sg, rssi)
                active_loop = loop
                if active_loop is None:
                    try:
                        active_loop = asyncio.get_running_loop()
                    except RuntimeError:
                        active_loop = None
                if not active_loop:
                    return
                try:
                    task = active_loop.create_task(self._persist_reading(color, temp_f, sg))
                except RuntimeError:
                    return
                manual_tasks.add(task)
                task.add_done_callback(manual_tasks.discard)

            try:
                async with BleakScanner(detection_callback=handle_once):
                    await asyncio.sleep(duration)
            except asyncio.CancelledError:
                raise
            except Exception as exc:  # pragma: no cover - hardware/environment errors
                message = f"scan failure: {exc}"
                self.last_error = message
                self._sync_state()
                log.warning("Tilt scan-once failure: %s", exc)
                return {
                    "ok": False,
                    "counts": {"total": 0, "colors": {}},
                    "running": self.is_active(),
                    "note": message,
                }

            if manual_tasks:
                with contextlib.suppress(Exception):
                    await asyncio.gather(*manual_tasks, return_exceptions=True)
                manual_tasks.clear()

            total = sum(seen.values())
            note = "scan complete" if total else "no Tilt broadcasts detected"
            return {
                "ok": True,
                "counts": {"total": total, "colors": dict(seen)},
                "running": self.is_active(),
                "note": note,
                "last_seen": {
                    color: self.status[color]["ts"]
                    for color in seen
                    if color in self.status and "ts" in self.status[color]
                },
            }


__all__ = ["TiltScannerService", "BleakScanner", "TILT_UUID_TO_COLOR"]
