from __future__ import annotations

import asyncio
import logging
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from typing import Any, Dict

import httpx

log = logging.getLogger("bevforge.weather")


@dataclass
class WeatherPayload:
    data: Dict[str, Any]
    expires_at: datetime


_WEATHER_CODE_DESCRIPTIONS: dict[int, tuple[str, str]] = {
    0: ("Clear sky", "clear"),
    1: ("Mainly clear", "clear"),
    2: ("Partly cloudy", "cloudy"),
    3: ("Overcast", "cloudy"),
    45: ("Fog", "fog"),
    48: ("Depositing rime fog", "fog"),
    51: ("Light drizzle", "rain"),
    53: ("Moderate drizzle", "rain"),
    55: ("Dense drizzle", "rain"),
    56: ("Light freezing drizzle", "snow"),
    57: ("Dense freezing drizzle", "snow"),
    61: ("Slight rain", "rain"),
    63: ("Moderate rain", "rain"),
    65: ("Heavy rain", "rain"),
    66: ("Light freezing rain", "snow"),
    67: ("Heavy freezing rain", "snow"),
    71: ("Slight snowfall", "snow"),
    73: ("Moderate snowfall", "snow"),
    75: ("Heavy snowfall", "snow"),
    77: ("Snow grains", "snow"),
    80: ("Slight rain showers", "rain"),
    81: ("Moderate rain showers", "rain"),
    82: ("Violent rain showers", "rain"),
    85: ("Slight snow showers", "snow"),
    86: ("Heavy snow showers", "snow"),
    95: ("Thunderstorm", "thunder"),
    96: ("Thunderstorm with slight hail", "thunder"),
    99: ("Thunderstorm with heavy hail", "thunder"),
}


class WeatherService:
    """Fetch and cache weather readings from Open-Meteo."""

    def __init__(self) -> None:
        self._cache: dict[str, WeatherPayload] = {}
        self._lock = asyncio.Lock()

    @staticmethod
    def _cache_key(lat: float, lon: float, units: str) -> str:
        return f"{lat:.4f}:{lon:.4f}:{units}".lower()

    @staticmethod
    def _normalize_units(units: str | None) -> str:
        normalized = (units or "us").strip().lower()
        if normalized not in {"us", "metric"}:
            return "us"
        return normalized

    @staticmethod
    def _describe(code: int) -> tuple[str, str]:
        return _WEATHER_CODE_DESCRIPTIONS.get(code, ("Unknown", "cloudy"))

    async def _fetch_weather(self, lat: float, lon: float, units: str) -> Dict[str, Any]:
        params = {
            "latitude": lat,
            "longitude": lon,
            "current": "temperature_2m,is_day,weather_code",  # new API schema
            "daily": "sunrise,sunset",
            "timezone": "auto",
        }
        if units == "us":
            params["temperature_unit"] = "fahrenheit"
        else:
            params["temperature_unit"] = "celsius"

        async with httpx.AsyncClient(timeout=10.0) as client:
            response = await client.get("https://api.open-meteo.com/v1/forecast", params=params)
            response.raise_for_status()
            payload = response.json()

        current = payload.get("current") or payload.get("current_weather") or {}
        daily = payload.get("daily") or {}

        temp_value = current.get("temperature_2m") or current.get("temperature")
        try:
            temp = float(temp_value) if temp_value is not None else None
        except (TypeError, ValueError):
            temp = None

        raw_is_day = current.get("is_day")
        if isinstance(raw_is_day, str):
            is_day = raw_is_day.strip() not in {"0", "false", "False"}
        else:
            is_day = bool(raw_is_day)

        code_value = current.get("weather_code") or current.get("weathercode")
        try:
            cond_code = int(code_value) if code_value is not None else -1
        except (TypeError, ValueError):
            cond_code = -1

        cond_text, category = self._describe(cond_code)

        sunrise_values = daily.get("sunrise") or []
        sunset_values = daily.get("sunset") or []
        sunrise = sunrise_values[0] if sunrise_values else None
        sunset = sunset_values[0] if sunset_values else None

        updated_at = current.get("time") or datetime.now(timezone.utc).isoformat()

        return {
            "temp": temp,
            "units": units,
            "cond_code": cond_code,
            "cond_text": cond_text,
            "category": category,
            "is_day": is_day,
            "sunrise": sunrise,
            "sunset": sunset,
            "updated_at": updated_at,
            "offline": False,
            "note": None,
        }

    async def get_latest(
        self,
        *,
        lat: float,
        lon: float,
        units: str = "us",
        refresh_min: int = 10,
        force: bool = False,
    ) -> Dict[str, Any]:
        normalized_units = self._normalize_units(units)
        cache_key = self._cache_key(lat, lon, normalized_units)
        minimum_refresh = max(int(refresh_min or 0), 1)
        cache_ttl = timedelta(minutes=minimum_refresh)

        async with self._lock:
            now = datetime.now(timezone.utc)
            cached = self._cache.get(cache_key)
            if cached and not force and cached.expires_at > now:
                return cached.data

            try:
                latest = await self._fetch_weather(lat, lon, normalized_units)
            except httpx.HTTPStatusError as exc:  # pragma: no cover - defensive
                log.warning("Weather fetch failed (%s): %s", exc.response.status_code, exc)
                latest = None
            except Exception as exc:  # pragma: no cover - defensive
                log.warning("Weather fetch error: %s", exc)
                latest = None

            if latest is None:
                if cached:
                    cached.data["offline"] = True
                    cached.data["note"] = "Weather service unreachable."
                    cached.expires_at = now + cache_ttl
                    return cached.data

                fallback = {
                    "temp": None,
                    "units": normalized_units,
                    "cond_code": -1,
                    "cond_text": "Unavailable",
                    "category": "offline",
                    "is_day": False,
                    "sunrise": None,
                    "sunset": None,
                    "updated_at": None,
                    "offline": True,
                    "note": "Weather service unreachable.",
                }
                self._cache[cache_key] = WeatherPayload(data=fallback, expires_at=now + cache_ttl)
                return fallback

            latest["offline"] = False
            latest["note"] = None
            latest["updated_at"] = datetime.now(timezone.utc).isoformat()
            self._cache[cache_key] = WeatherPayload(data=latest, expires_at=now + cache_ttl)
            return latest


__all__ = ["WeatherService"]
