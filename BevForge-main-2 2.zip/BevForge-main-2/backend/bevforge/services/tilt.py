from __future__ import annotations
# Placeholder for BLE scanner; HTTP ingest is the default path.
# If USE_BLE=1 is set, you could integrate a BLE library like bleak.
# For now, this is a stub to keep the code lightweight on a Pi.
