const DRAFT_ENDPOINT = '/widgets/pos?draft=1';
const IMAGE_SAVE_DELAY = 350;
const HYDROMETER_POLL_SECONDS = 12;


const imageTileState = new WeakMap();

async function postJSON(url, body, options = {}) {
  const { headers: extraHeaders, signal } = options;
  const buildHeaders = (contentType) => {
    const base = { Accept: 'application/json' };
    if (contentType) {
      base['Content-Type'] = contentType;
    }
    return Object.assign(base, extraHeaders || {});
  };

  const jsonBody = body === undefined ? undefined : JSON.stringify(body);
  const canUseForm = body && typeof body === 'object' && !Array.isArray(body);

  const tryJson = (targetUrl) =>
    fetch(targetUrl, {
      method: 'POST',
      headers: buildHeaders('application/json'),
      body: jsonBody,
      signal,
    });

  const buildFormPayload = () => {
    const payload = new URLSearchParams();
    Object.entries(body || {}).forEach(([key, value]) => {
      if (value === undefined || value === null) {
        return;
      }
      if (typeof value === 'object') {
        payload.set(key, JSON.stringify(value));
      } else {
        payload.set(key, String(value));
      }
    });
    return payload;
  };

  let response = await tryJson(url);
  if (response.status !== 422) {
    return response;
  }

  if (canUseForm) {
    const formPayload = buildFormPayload();
    response = await fetch(url, {
      method: 'POST',
      headers: buildHeaders('application/x-www-form-urlencoded'),
      body: formPayload,
      signal,
    });
    if (response.status !== 422) {
      return response;
    }
  }

  if (!url.includes('draft=')) {
    const draftUrl = url.includes('?') ? `${url}&draft=1` : `${url}?draft=1`;
    response = await tryJson(draftUrl);
    if (response.status !== 422) {
      return response;
    }

    if (canUseForm) {
      const formPayload = buildFormPayload();
      response = await fetch(draftUrl, {
        method: 'POST',
        headers: buildHeaders('application/x-www-form-urlencoded'),
        body: formPayload,
        signal,
      });
      if (response.status !== 422) {
        return response;
      }
    }
  }

  return response;
}

function applyImageStyles(tile, options = {}) {
  if (!(tile instanceof HTMLElement)) {
    return;
  }

  const editMode =
    typeof options.isEdit === 'boolean' ? options.isEdit : tile.dataset.imageEdit === '1';
  tile.dataset.imageEdit = editMode ? '1' : '0';

  const fitRaw = (tile.dataset.imageFit || 'cover').toLowerCase();
  const fit = fitRaw === 'contain' ? 'contain' : 'cover';
  tile.dataset.imageFit = fit;

  const parsedScale = Number.parseFloat(tile.dataset.imageScale);
  const scale = Number.isFinite(parsedScale)
    ? Math.min(Math.max(parsedScale, 0.5), 2)
    : 1;
  tile.dataset.imageScale = scale.toFixed(3);

  const parsedOffsetX = Number.parseFloat(tile.dataset.imageOffsetX);
  const parsedOffsetY = Number.parseFloat(tile.dataset.imageOffsetY);
  const offsetX = Number.isFinite(parsedOffsetX)
    ? Math.max(Math.min(parsedOffsetX, 2000), -2000)
    : 0;
  const offsetY = Number.isFinite(parsedOffsetY)
    ? Math.max(Math.min(parsedOffsetY, 2000), -2000)
    : 0;
  tile.dataset.imageOffsetX = String(Math.round(offsetX));
  tile.dataset.imageOffsetY = String(Math.round(offsetY));

  const layer = tile.dataset.imageLayer === 'background' ? 'background' : 'foreground';
  tile.dataset.imageLayer = layer;

  const imageEl = tile.querySelector('[data-role="image-element"]');
  if (imageEl) {
    imageEl.style.objectFit = fit;
    imageEl.style.transform = `translate(-50%, -50%) translate(${offsetX}px, ${offsetY}px) scale(${scale})`;
  }

  const scaleValue = tile.querySelector('[data-role="image-scale-value"]');
  if (scaleValue) {
    scaleValue.textContent = scale.toFixed(2);
  }

  const stage = tile.querySelector('[data-role="image-stage"]');
  const isSvg = tile.dataset.imageSvg === '1';
  const maskEnabled = tile.dataset.imageSvgMask === '1';
  const maskColor = (tile.dataset.imageSvgColor || '').trim();

  if (stage) {
    if (isSvg && !maskEnabled) {
      stage.style.backgroundColor = 'transparent';
    } else if (isSvg && maskEnabled) {
      stage.style.backgroundColor = maskColor || '#0f172a';
    } else {
      stage.style.backgroundColor = '';
    }
  }

  const host = tile.closest('.grid-stack-item-content');
  if (host) {
    host.dataset.imageLayer = layer;
    if (!editMode && isSvg && !maskEnabled) {
      host.style.backgroundColor = 'transparent';
      host.style.borderColor = 'transparent';
      host.style.boxShadow = 'none';
    } else if (!editMode) {
      host.style.backgroundColor = '';
      host.style.borderColor = '';
      host.style.boxShadow = '';
    }
  }

  const gridItem = host?.closest('.grid-stack-item') || null;
  if (gridItem) {
    const isBackground = !editMode && layer === 'background';
    const isForeground = !editMode && layer !== 'background';
    gridItem.classList.toggle('is-image-background', isBackground);
    gridItem.classList.toggle('is-image-foreground', isForeground);
    if (isBackground) {
      gridItem.style.zIndex = '1';
    } else if (editMode) {
      gridItem.style.zIndex = '';
    } else {
      gridItem.style.zIndex = '';
    }
  }
}

async function persistImageConfig(tile, state, widgetId) {
  if (!tile) {
    return;
  }

  if (state.abortController) {
    state.abortController.abort();
  }

  const controller = typeof AbortController !== 'undefined' ? new AbortController() : null;
  state.abortController = controller;

  const payload = {
    object_fit: tile.dataset.imageFit || 'cover',
    scale: Number.parseFloat(tile.dataset.imageScale) || 1,
    offset_x: Number.parseInt(tile.dataset.imageOffsetX || '0', 10) || 0,
    offset_y: Number.parseInt(tile.dataset.imageOffsetY || '0', 10) || 0,
    layer: tile.dataset.imageLayer || 'foreground',
    svg_mask: tile.dataset.imageSvgMask === '1',
  };

  if (tile.dataset.imageSvgMask === '1') {
    const color = (tile.dataset.imageSvgColor || '').trim();
    if (color) {
      payload.svg_mask_color = color;
    }
  }

  try {
    const response = await fetch(`/widgets/${widgetId}/config`, {
      method: 'PATCH',
      headers: {
        'Content-Type': 'application/json',
        Accept: 'application/json',
      },
      body: JSON.stringify(payload),
      credentials: 'same-origin',
      signal: controller?.signal || undefined,
    });
    if (!response.ok) {
      const text = await response.text().catch(() => '');
      console.warn('Image config save failed', text);
    }
  } catch (error) {
    const isAbort =
      typeof DOMException !== 'undefined' &&
      error instanceof DOMException &&
      error.name === 'AbortError';
    if (!isAbort) {
      console.warn('Image config save error', error);
    }
  } finally {
    if (state.abortController === controller) {
      state.abortController = null;
    }
  }
}

function scheduleImageSave(tile) {
  if (!tile) {
    return;
  }
  const widgetId = Number(tile.dataset.widgetId);
  if (!widgetId) {
    return;
  }

  const state = imageTileState.get(tile) || {};
  if (state.saveTimer) {
    window.clearTimeout(state.saveTimer);
  }
  state.saveTimer = window.setTimeout(async () => {
    state.saveTimer = null;
    await persistImageConfig(tile, state, widgetId);
  }, IMAGE_SAVE_DELAY);
  imageTileState.set(tile, state);
}

function initImageTile(tile, options = {}) {
  if (!(tile instanceof HTMLElement)) {
    return;
  }

  const isEdit = typeof options.isEdit === 'boolean' ? options.isEdit : tile.dataset.imageEdit === '1';
  applyImageStyles(tile, { isEdit });

  const state = imageTileState.get(tile) || {};

  if (!isEdit) {
    if (state.bound && typeof state.cleanup === 'function') {
      state.cleanup();
    }
    state.bound = false;
    state.cleanup = null;
    imageTileState.set(tile, state);
    return;
  }

  if (state.bound) {
    return;
  }

  const scaleInput = tile.querySelector('[data-role="image-scale-control"]');
  const offsetXInput = tile.querySelector('[data-role="image-offset-x"]');
  const offsetYInput = tile.querySelector('[data-role="image-offset-y"]');
  const fitButtons = tile.querySelectorAll('[data-role="image-fit"]');
  const layerButtons = tile.querySelectorAll('[data-role="image-layer"]');
  const maskToggle = tile.querySelector('[data-role="image-mask-toggle"]');
  const maskColor = tile.querySelector('[data-role="image-mask-color"]');

  const handleScale = (event) => {
    if (!(event?.target instanceof HTMLInputElement)) {
      return;
    }
    tile.dataset.imageScale = event.target.value;
    applyImageStyles(tile, { isEdit: true });
    scheduleImageSave(tile);
  };

  const handleOffset = (event, axis) => {
    if (!(event?.target instanceof HTMLInputElement)) {
      return;
    }
    const value = Number.parseFloat(event.target.value);
    const clamped = Number.isFinite(value)
      ? Math.max(Math.min(value, 2000), -2000)
      : 0;
    tile.dataset[`imageOffset${axis}`] = String(Math.round(clamped));
    event.target.value = String(Math.round(clamped));
    applyImageStyles(tile, { isEdit: true });
    scheduleImageSave(tile);
  };

  const updateActiveButtons = (buttons, activeValue) => {
    buttons.forEach((button) => {
      if (!(button instanceof HTMLButtonElement)) {
        return;
      }
      const value = (button.dataset.value || '').toLowerCase();
      button.classList.toggle('is-active', value === activeValue);
    });
  };

  const handleOffsetX = (event) => handleOffset(event, 'X');
  const handleOffsetY = (event) => handleOffset(event, 'Y');

  const handleFitClick = (event) => {
    const button = event.currentTarget;
    if (!(button instanceof HTMLButtonElement)) {
      return;
    }
    event.preventDefault();
    const value = (button.dataset.value || '').toLowerCase();
    const normalized = value === 'contain' ? 'contain' : 'cover';
    tile.dataset.imageFit = normalized;
    updateActiveButtons(fitButtons, normalized);
    applyImageStyles(tile, { isEdit: true });
    scheduleImageSave(tile);
  };

  const handleLayerClick = (event) => {
    const button = event.currentTarget;
    if (!(button instanceof HTMLButtonElement)) {
      return;
    }
    event.preventDefault();
    const value = (button.dataset.value || '').toLowerCase();
    const normalized = value === 'background' ? 'background' : 'foreground';
    tile.dataset.imageLayer = normalized;
    updateActiveButtons(layerButtons, normalized);
    applyImageStyles(tile, { isEdit: true });
    scheduleImageSave(tile);
  };

  const handleMaskToggle = (event) => {
    if (!(event?.target instanceof HTMLInputElement)) {
      return;
    }
    const enabled = event.target.checked;
    tile.dataset.imageSvgMask = enabled ? '1' : '0';
    if (maskColor instanceof HTMLInputElement) {
      maskColor.disabled = !enabled;
    }
    applyImageStyles(tile, { isEdit: true });
    scheduleImageSave(tile);
  };

  const handleMaskColor = (event) => {
    if (!(event?.target instanceof HTMLInputElement)) {
      return;
    }
    tile.dataset.imageSvgColor = event.target.value || '#0f172a';
    applyImageStyles(tile, { isEdit: true });
    scheduleImageSave(tile);
  };

  scaleInput?.addEventListener('input', handleScale);
  offsetXInput?.addEventListener('change', handleOffsetX);
  offsetXInput?.addEventListener('blur', handleOffsetX);
  offsetYInput?.addEventListener('change', handleOffsetY);
  offsetYInput?.addEventListener('blur', handleOffsetY);

  fitButtons.forEach((button) => {
    if (button instanceof HTMLButtonElement) {
      button.addEventListener('click', handleFitClick);
    }
  });

  layerButtons.forEach((button) => {
    if (button instanceof HTMLButtonElement) {
      button.addEventListener('click', handleLayerClick);
    }
  });

  if (maskToggle instanceof HTMLInputElement) {
    maskToggle.addEventListener('change', handleMaskToggle);
    maskToggle.checked = tile.dataset.imageSvgMask === '1';
  }

  if (maskColor instanceof HTMLInputElement) {
    maskColor.addEventListener('input', handleMaskColor);
    maskColor.disabled = tile.dataset.imageSvgMask !== '1';
    if (!maskColor.value) {
      maskColor.value = tile.dataset.imageSvgColor || '#0f172a';
    }
  }

  state.bound = true;
  state.cleanup = () => {
    scaleInput?.removeEventListener('input', handleScale);
    offsetXInput?.removeEventListener('change', handleOffsetX);
    offsetXInput?.removeEventListener('blur', handleOffsetX);
    offsetYInput?.removeEventListener('change', handleOffsetY);
    offsetYInput?.removeEventListener('blur', handleOffsetY);
    fitButtons.forEach((button) => {
      if (button instanceof HTMLButtonElement) {
        button.removeEventListener('click', handleFitClick);
      }
    });
    layerButtons.forEach((button) => {
      if (button instanceof HTMLButtonElement) {
        button.removeEventListener('click', handleLayerClick);
      }
    });
    if (maskToggle instanceof HTMLInputElement) {
      maskToggle.removeEventListener('change', handleMaskToggle);
    }
    if (maskColor instanceof HTMLInputElement) {
      maskColor.removeEventListener('input', handleMaskColor);
    }
    if (state.saveTimer) {
      window.clearTimeout(state.saveTimer);
      state.saveTimer = null;
    }
    if (state.abortController) {
      state.abortController.abort();
      state.abortController = null;
    }
    state.bound = false;
    state.cleanup = null;
  };

  updateActiveButtons(fitButtons, tile.dataset.imageFit || 'cover');
  updateActiveButtons(layerButtons, tile.dataset.imageLayer || 'foreground');

  imageTileState.set(tile, state);
}

function initImageTiles(root = document, options = {}) {
  if (!root) {
    return;
  }
  const tiles = root.querySelectorAll('[data-role="image-tile"]');
  tiles.forEach((tile) => {
    if (!(tile instanceof HTMLElement)) {
      return;
    }
    const isEdit =
      typeof options.isEdit === 'boolean'
        ? options.isEdit
        : tile.dataset.imageEdit === '1';
    initImageTile(tile, { isEdit });
  });
}

function initGridstack({ isEdit }) {
  const gridEl = document.getElementById('dashboardGrid');
  if (!gridEl || typeof GridStack === 'undefined') {
    return null;
  }

  const grid = GridStack.init(
    {
      float: false,
      disableOneColumnMode: true,
      cellHeight: 110,
      margin: 6,
      column: 12,
      animate: false,
    },
    gridEl,
  );

  const toPayload = () => {
    const nodes = grid?.engine?.nodes || [];
    return nodes.map((node) => {
      const rawId = node.id ?? node.el?.getAttribute('gs-id') ?? 0;
      return {
        id: Number(rawId),
        x: node.x ?? 0,
        y: node.y ?? 0,
        w: node.w ?? 1,
        h: node.h ?? 1,
      };
    });
  };

  if (!isEdit) {
    grid.setStatic(true);
    return {
      grid,
      isEdit: false,
      getPayload: toPayload,
      scheduleDraftSave: () => {},
      persistDraftLayout: async () => {},
      cancelPendingDraft: () => {},
      flushDraftSaves: async () => {},
    };
  }

  let draftSaveTimer = null;
  let draftAbort = null;

  const persistDraftLayout = async () => {
    const payload = toPayload();
    if (draftAbort) {
      draftAbort.abort();
    }
    const controller = typeof AbortController !== 'undefined' ? new AbortController() : null;
    draftAbort = controller;
    try {
      const response = await postJSON(DRAFT_ENDPOINT, payload, { signal: controller?.signal });
      if (!response.ok) {
        const text = await response.text().catch(() => '');
        console.warn('Draft save failed', text);
      }
    } catch (error) {
      const isAbort =
        typeof DOMException !== 'undefined' &&
        error instanceof DOMException &&
        error.name === 'AbortError';
      if (!isAbort) {
        console.warn('Draft save error', error);
      }
    } finally {
      if (draftAbort === controller) {
        draftAbort = null;
      }
    }
  };

  const scheduleDraftSave = () => {
    if (draftSaveTimer) {
      clearTimeout(draftSaveTimer);
    }
    draftSaveTimer = window.setTimeout(persistDraftLayout, 300);
  };

  const handleStop = () => scheduleDraftSave();
  grid.on('dragstop', handleStop);
  grid.on('resizestop', handleStop);
  grid.on('added', handleStop);
  grid.on('removed', handleStop);

  const cancelPendingDraft = () => {
    if (draftSaveTimer) {
      clearTimeout(draftSaveTimer);
      draftSaveTimer = null;
    }
    if (draftAbort) {
      draftAbort.abort();
      draftAbort = null;
    }
  };

  const flushDraftSaves = async () => {
    if (draftSaveTimer) {
      clearTimeout(draftSaveTimer);
      draftSaveTimer = null;
      await persistDraftLayout();
    }
  };

  return {
    grid,
    isEdit: true,
    getPayload: toPayload,
    scheduleDraftSave,
    persistDraftLayout,
    cancelPendingDraft,
    flushDraftSaves,
  };
}

function formatConfigPreview(preview) {
  if (preview === null || preview === undefined) {
    return '';
  }

  if (typeof preview === 'string') {
    return preview;
  }

  if (typeof preview !== 'object') {
    return String(preview);
  }

  const lines = [];

  const visit = (value, prefix) => {
    if (value === null || value === undefined) {
      if (prefix) {
        lines.push(`${prefix}: —`);
      }
      return;
    }

    if (typeof value === 'string' || typeof value === 'number' || typeof value === 'boolean') {
      if (prefix) {
        lines.push(`${prefix}: ${String(value)}`);
      } else {
        lines.push(String(value));
      }
      return;
    }

    if (Array.isArray(value)) {
      if (value.length === 0) {
        if (prefix) {
          lines.push(`${prefix}: —`);
        }
        return;
      }
      value.forEach((entry, index) => {
        const nextPrefix = prefix ? `${prefix}[${index}]` : `[${index}]`;
        if (entry !== null && typeof entry === 'object') {
          visit(entry, nextPrefix);
        } else {
          lines.push(`${nextPrefix}: ${String(entry)}`);
        }
      });
      return;
    }

    const keys = Object.keys(value);
    if (keys.length === 0) {
      if (prefix) {
        lines.push(`${prefix}: —`);
      }
      return;
    }

    keys.forEach((key) => {
      const nextPrefix = prefix ? `${prefix}.${key}` : key;
      visit(value[key], nextPrefix);
    });
  };

  visit(preview, '');

  const cleanLines = lines
    .map((line) => line.trim())
    .filter(Boolean);

  if (cleanLines.length > 6) {
    return `${cleanLines.slice(0, 6).join('\n')}\n…`;
  }

  return cleanLines.join('\n');
}

function addWidgetToGrid(
  grid,
  { id, kind, x, y, w = 2, h = 2, title, preview },
) {
  if (!grid) {
    return null;
  }

  const safeId = String(id ?? '').trim();
  if (!safeId) {
    console.warn('Cannot add widget without an id');
    return null;
  }

  const toNumber = (value, fallback) => {
    const parsed = Number(value);
    return Number.isNaN(parsed) ? fallback : parsed;
  };

  const hasExplicitX = x !== undefined && x !== null && x !== '';
  const hasExplicitY = y !== undefined && y !== null && y !== '';
  const safeX = hasExplicitX ? toNumber(x, 0) : 0;
  const safeY = hasExplicitY ? toNumber(y, 0) : 0;
  const safeW = Math.max(toNumber(w, 2), 1);
  const safeH = Math.max(toNumber(h, 2), 1);

  const item = document.createElement('div');
  item.className = 'grid-stack-item';
  item.setAttribute('gs-id', safeId);
  item.setAttribute('gs-w', String(safeW));
  item.setAttribute('gs-h', String(safeH));
  if (hasExplicitX) {
    item.setAttribute('gs-x', String(safeX));
  }
  if (hasExplicitY) {
    item.setAttribute('gs-y', String(safeY));
  }

  const content = document.createElement('div');
  content.className = 'grid-stack-item-content';
  content.setAttribute('data-widget-id', safeId);

  const placeholder = document.createElement('div');
  placeholder.className = 'p-4 text-xs text-slate-400';
  placeholder.textContent = 'Loading…';
  content.appendChild(placeholder);

  item.appendChild(content);

  const addOptions = { w: safeW, h: safeH, id: safeId };
  if (hasExplicitX && hasExplicitY) {
    addOptions.x = safeX;
    addOptions.y = safeY;
  } else {
    addOptions.autoPosition = true;
  }

  const node = grid.addWidget(item, addOptions);

  const displayKind = (kind || 'Widget').toString();
  const titleText = title || `${displayKind.charAt(0).toUpperCase() + displayKind.slice(1)} #${safeId}`;

  const renderFallback = () => {
    content.innerHTML = '';
    const tile = document.createElement('div');
    tile.className = 'tile';

    const header = document.createElement('div');
    header.className = 'tile-header';
    header.textContent = titleText;
    tile.appendChild(header);

    const body = document.createElement('div');
    body.className = 'tile-body';
    const previewText = formatConfigPreview(preview);
    if (previewText) {
      previewText.split('\n').forEach((line) => {
        const paragraph = document.createElement('p');
        paragraph.textContent = line;
        body.appendChild(paragraph);
      });
    } else {
      const paragraph = document.createElement('p');
      paragraph.textContent = 'Widget created. Rendering will be available shortly.';
      body.appendChild(paragraph);
    }
    tile.appendChild(body);

    const footer = document.createElement('div');
    footer.className = 'tile-footer';
    footer.textContent = `ID ${safeId}`;
    tile.appendChild(footer);

    content.appendChild(tile);
  };

  const gridElement = grid?.el || document.getElementById('dashboardGrid');
  const isEditMode = (gridElement?.dataset?.edit || '') === '1' || window.dashboardGridContext?.isEdit;
  const mode = isEditMode ? 'edit' : 'view';
  const renderUrl = `/widgets/render/${encodeURIComponent(safeId)}?mode=${mode}`;

  fetch(renderUrl, {
    headers: { 'HX-Request': 'true' },
    credentials: 'same-origin',
  })
    .then((response) => {
      if (!response.ok) {
        throw new Error(`Render request failed (${response.status})`);
      }
      return response.text();
    })
    .then((html) => {
      if (!html || !html.trim()) {
        throw new Error('Render response was empty');
      }
      content.innerHTML = html;
      if (window.htmx && typeof window.htmx.process === 'function') {
        window.htmx.process(content);
      }
      initHydrometerTiles(content);
    })
    .catch((error) => {
      console.warn('Widget render fetch failed; using fallback view.', error);
      renderFallback();
    });

  return node;
}

async function createWidget({ kind, config, size = { w: 2, h: 2 }, draft = true }) {
  const width = Number(size?.w ?? 2) || 2;
  const height = Number(size?.h ?? 2) || 2;
  const payload = {
    kind,
    config_json: config ?? {},
    w: width,
    h: height,
  };

  if (draft) {
    payload.draft = 1;
  }

  const targetUrl = draft ? '/widgets?draft=1' : '/widgets';
  const response = await postJSON(targetUrl, payload);

  if (response.status === 422) {
    const message = await response.text().catch(() => null);
    throw new Error(message || 'Widget creation rejected by server.');
  }

  if (!response.ok) {
    const text = await response.text().catch(() => '');
    throw new Error(text || `Widget create failed (${response.status})`);
  }

  let widgetId = null;
  let widthResponse = width;
  let heightResponse = height;

  const data = await response.clone().json().catch(() => null);

  if (data && typeof data === 'object') {
    if (data.id !== undefined) {
      widgetId = Number(data.id);
    } else if (
      data.widget &&
      typeof data.widget === 'object' &&
      data.widget.id !== undefined
    ) {
      widgetId = Number(data.widget.id);
    }
    if (data.w !== undefined) {
      const parsedW = Number(data.w);
      if (!Number.isNaN(parsedW)) {
        widthResponse = parsedW;
      }
    }
    if (data.h !== undefined) {
      const parsedH = Number(data.h);
      if (!Number.isNaN(parsedH)) {
        heightResponse = parsedH;
      }
    }
  }

  if (!widgetId) {
    const location = response.headers.get('Location');
    if (location) {
      const match = location.match(/\/widgets\/(\d+)/i);
      if (match) {
        widgetId = Number(match[1]);
      }
    }
  }

  if (!widgetId || Number.isNaN(widgetId)) {
    const text = await response.clone().text().catch(() => '');
    alert(text || 'Widget created but no identifier was returned.');
    throw new Error('Widget creation missing id');
  }

  return {
    id: widgetId,
    kind,
    w: widthResponse,
    h: heightResponse,
  };
}

function applyRelayState(tile, nextState) {
  if (!tile) {
    return;
  }

  const normalized = typeof nextState === 'string' ? nextState.toLowerCase() : '';
  const state = normalized === 'on' || normalized === 'off' ? normalized : 'unknown';
  tile.dataset.relayState = state;

  const indicator = tile.querySelector('[data-role="relay-state-indicator"]');
  const textEl = tile.querySelector('[data-role="relay-state-text"]');
  if (textEl) {
    if (state === 'on') {
      textEl.textContent = 'Relay On';
    } else if (state === 'off') {
      textEl.textContent = 'Relay Off';
    } else {
      textEl.textContent = 'Status Unknown';
    }
  }

  if (indicator) {
    if (state === 'on') {
      indicator.style.backgroundColor = '#22c55e';
      indicator.style.boxShadow = '0 0 12px rgba(34, 197, 94, 0.45)';
    } else if (state === 'off') {
      indicator.style.backgroundColor = '#64748b';
      indicator.style.boxShadow = 'none';
    } else {
      indicator.style.backgroundColor = '#334155';
      indicator.style.boxShadow = 'none';
    }
  }

  const host = tile.closest('.grid-stack-item-content') || tile;
  if (state === 'on') {
    host.style.backgroundColor = 'rgba(6, 95, 70, 0.35)';
    host.style.borderColor = 'rgba(52, 211, 153, 0.55)';
    host.style.boxShadow = '0 0 0 1px rgba(16, 185, 129, 0.45) inset';
  } else if (state === 'off') {
    host.style.backgroundColor = '';
    host.style.borderColor = '';
    host.style.boxShadow = '';
  } else {
    host.style.backgroundColor = '';
    host.style.borderColor = '';
    host.style.boxShadow = '';
  }

  const controls = tile.querySelectorAll('[data-role="relay-control"]');
  controls.forEach((button) => {
    if (!(button instanceof HTMLButtonElement)) {
      return;
    }
    const action = (button.dataset.action || '').toLowerCase();
    if (action === 'on') {
      button.classList.toggle('opacity-60', state === 'on');
    } else if (action === 'off') {
      button.classList.toggle('opacity-60', state === 'off');
    } else {
      button.classList.remove('opacity-60');
    }
  });
}

function buildRelayPayload(tile) {
  if (!tile) {
    return {};
  }

  const dataset = tile.dataset || {};
  const payload = {
    backend: dataset.relayBackend || 'USB',
    board: dataset.relayBoard || undefined,
    channel: dataset.relayChannel ? Number(dataset.relayChannel) : undefined,
    bcm: dataset.relayBcm ? Number(dataset.relayBcm) : undefined,
    relay_label: dataset.relayLabel || undefined,
    slug: dataset.widgetSlug || undefined,
    widget_id: dataset.widgetId ? Number(dataset.widgetId) : undefined,
  };

  const cleaned = {};
  Object.entries(payload).forEach(([key, value]) => {
    if (value === undefined || value === null || value === '') {
      return;
    }
    cleaned[key] = value;
  });
  return cleaned;
}

async function sendRelayAction(tile, action) {
  if (!tile) {
    return;
  }
  const normalized = typeof action === 'string' ? action.toLowerCase() : 'toggle';
  const selected = ['on', 'off', 'toggle'].includes(normalized) ? normalized : 'toggle';

  if (tile.dataset.relayBusy === '1') {
    return;
  }

  tile.dataset.relayBusy = '1';
  tile.setAttribute('aria-busy', 'true');

  const controls = tile.querySelectorAll('[data-role="relay-control"]');
  controls.forEach((button) => {
    if (button instanceof HTMLButtonElement) {
      button.disabled = true;
    }
  });

  try {
    const response = await fetch(`/devices/relay/${selected}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Accept: 'application/json',
      },
      body: JSON.stringify(buildRelayPayload(tile)),
      credentials: 'same-origin',
    });

    if (!response.ok) {
      const message = (await response.text().catch(() => '')) || 'Relay command failed.';
      console.warn('Relay action failed', message);
      window.alert(message);
      return;
    }

    const data = (await response.json().catch(() => null)) || {};
    if (data.relay_label && !tile.dataset.relayLabel) {
      tile.dataset.relayLabel = String(data.relay_label);
    }
    if (data.state) {
      applyRelayState(tile, data.state);
    }
  } catch (error) {
    console.error('Relay action error', error);
    window.alert('Unable to control relay.');
  } finally {
    controls.forEach((button) => {
      if (button instanceof HTMLButtonElement) {
        button.disabled = false;
      }
    });
    delete tile.dataset.relayBusy;
    tile.removeAttribute('aria-busy');
  }
}

function initRelayTile(tile) {
  if (!tile || tile.dataset.relayReady === '1') {
    return;
  }
  tile.dataset.relayReady = '1';

  const stateAttr = tile.dataset.relayState || '';
  applyRelayState(tile, stateAttr || 'unknown');

  const gridEl = tile.closest('#dashboardGrid');
  const isEditMode = gridEl?.dataset?.edit === '1';

  tile.addEventListener('click', (event) => {
    if (isEditMode) {
      return;
    }
    if (!(event.target instanceof HTMLElement)) {
      return;
    }
    if (event.target.closest('[data-role="relay-control"]')) {
      return;
    }
    event.preventDefault();
    sendRelayAction(tile, 'toggle');
  });

  const controls = tile.querySelectorAll('[data-role="relay-control"]');
  controls.forEach((button) => {
    if (!(button instanceof HTMLButtonElement)) {
      return;
    }
    button.addEventListener('click', (event) => {
      event.preventDefault();
      event.stopPropagation();
      const action = button.dataset.action || 'toggle';
      sendRelayAction(tile, action);
    });
  });
}

function initRelayTiles(root = document) {
  if (!root) {
    return;
  }
  const tiles = root.querySelectorAll('[data-role="relay-tile"]');
  tiles.forEach((tile) => {
    initRelayTile(tile);
  });
}

const weatherControllers = new Map();
const WEATHER_THEME_CLASSES = [
  'weather-theme--pending',
  'weather-theme--day',
  'weather-theme--night',
  'weather-theme--rain',
  'weather-theme--snow',
  'weather-theme--cloudy',
  'weather-theme--thunder',
  'weather-theme--fog',
  'weather-theme--offline',
];

function destroyWeatherController(widgetId) {
  if (!widgetId) return;
  const controller = weatherControllers.get(widgetId);
  if (controller && typeof controller.destroy === 'function') {
    try {
      controller.destroy();
    } catch (error) {
      console.warn('Weather controller cleanup failed', error);
    }
  }
  weatherControllers.delete(widgetId);
}

function formatWeatherTemp(value, units) {
  if (value === null || value === undefined || value === '') {
    return '—';
  }
  const unitLabel = units === 'metric' ? '°C' : '°F';
  const number = Number(value);
  if (Number.isNaN(number)) {
    return String(value);
  }
  return `${number.toFixed(1)}${unitLabel}`;
}

function formatWeatherTimestamp(value) {
  if (!value) {
    return '';
  }
  try {
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) {
      return String(value);
    }
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  } catch (error) {
    return String(value);
  }
}

function readManualWeather(tile) {
  const raw = tile?.dataset?.weatherManual;
  if (!raw) {
    return null;
  }
  try {
    const parsed = JSON.parse(raw);
    if (parsed && typeof parsed === 'object') {
      return parsed;
    }
  } catch (error) {
    console.warn('Failed to parse manual weather data', error);
  }
  return null;
}

function applyWeatherTheme(tile, payload) {
  WEATHER_THEME_CLASSES.forEach((cls) => tile.classList.remove(cls));
  const category = typeof payload.category === 'string' ? payload.category.toLowerCase() : 'cloudy';
  const theme = [`weather-theme--${category}`];
  const timeClass = payload.is_day ? 'weather-theme--day' : 'weather-theme--night';
  tile.classList.add(timeClass);
  theme.forEach((cls) => tile.classList.add(cls));
  if (payload.offline) {
    tile.classList.add('weather-theme--offline');
  } else {
    tile.classList.remove('weather-theme--offline');
  }
}

function applyWeatherData(tile, payload) {
  if (!tile) return;
  const manual = readManualWeather(tile);
  const offline = Boolean(payload?.offline);
  const displayData = { ...payload };
  if (offline && manual && typeof manual === 'object') {
    if (manual.temp !== undefined && manual.temp !== '') {
      displayData.temp = manual.temp;
    }
    if (manual.cond_text) {
      displayData.cond_text = manual.cond_text;
    }
    if (manual.cond_code !== undefined && manual.cond_code !== '') {
      displayData.cond_code = manual.cond_code;
    }
    if (manual.is_day !== undefined) {
      displayData.is_day = Boolean(manual.is_day);
    }
    displayData.category = displayData.category || 'cloudy';
  }

  const units = (tile.dataset.weatherUnits || 'us').toLowerCase();
  const tempEl = tile.querySelector('[data-role="weather-temp"]');
  const conditionEl = tile.querySelector('[data-role="weather-condition"]');
  const updatedEl = tile.querySelector('[data-role="weather-updated"]');
  const offlineEl = tile.querySelector('[data-role="weather-offline"]');
  const locationEl = tile.querySelector('[data-role="weather-location"]');

  if (locationEl && tile.dataset.weatherLocation) {
    locationEl.textContent = tile.dataset.weatherLocation;
  }

  if (tempEl) {
    tempEl.textContent = formatWeatherTemp(displayData.temp, units);
  }
  if (conditionEl) {
    conditionEl.textContent = displayData.cond_text || '—';
  }
  if (updatedEl) {
    const timeText = formatWeatherTimestamp(displayData.updated_at);
    updatedEl.textContent = timeText ? `Updated ${timeText}` : '';
  }
  if (offlineEl) {
    if (offline) {
      offlineEl.hidden = false;
    } else {
      offlineEl.hidden = true;
    }
  }

  applyWeatherTheme(tile, displayData);
  tile.classList.remove('weather-theme--pending');
}

function initHydrometerTiles(root = document) {
  if (!root) return;
  const feeds = root.querySelectorAll('[data-role="hydrometer-feed"]');
  feeds.forEach((feed) => {
    if (!(feed instanceof HTMLElement)) {
      return;
    }
    const triggerValue = `load, every ${HYDROMETER_POLL_SECONDS}s`;
    if (feed.getAttribute('hx-trigger') !== triggerValue) {
      feed.setAttribute('hx-trigger', triggerValue);
      if (window.htmx && typeof window.htmx.process === 'function') {
        window.htmx.process(feed);
      }
    }
  });
}

function createWeatherController(tile) {
  if (!tile) return null;
  const widgetId = Number(tile.dataset.widgetId);
  const lat = Number(tile.dataset.weatherLat);
  const lon = Number(tile.dataset.weatherLon);
  if (!Number.isFinite(lat) || !Number.isFinite(lon)) {
    return null;
  }
  const units = (tile.dataset.weatherUnits || 'us').toLowerCase();
  const refreshMinutes = Number(tile.dataset.weatherRefresh) || 10;
  const intervalMs = Math.max(120000, Math.round(refreshMinutes * 60000));

  let timerId = null;
  let disposed = false;

  const fetchLatest = async () => {
    if (disposed) {
      return;
    }
    try {
      const url = new URL('/sensors/weather/latest', window.location.origin);
      url.searchParams.set('lat', String(lat));
      url.searchParams.set('lon', String(lon));
      url.searchParams.set('units', units);
      url.searchParams.set('refresh_min', String(refreshMinutes || 10));
      const response = await fetch(url.toString(), { credentials: 'same-origin' });
      if (!response.ok) {
        throw new Error(`Weather fetch failed (${response.status})`);
      }
      const body = await response.json();
      const payload = body && typeof body === 'object' ? body.data || body : {};
      applyWeatherData(tile, payload || {});
    } catch (error) {
      console.warn('Weather update failed', error);
      applyWeatherData(tile, { offline: true });
    }
  };

  fetchLatest();
  timerId = window.setInterval(fetchLatest, intervalMs);

  return {
    destroy() {
      disposed = true;
      if (timerId) {
        window.clearInterval(timerId);
        timerId = null;
      }
    },
    refresh: fetchLatest,
  };
}

function initWeatherTiles(root = document) {
  if (!root) return;
  const tiles = root.querySelectorAll('[data-role="weather-tile"]');
  tiles.forEach((tile) => {
    const widgetId = Number(tile.dataset.widgetId);
    if (widgetId) {
      destroyWeatherController(widgetId);
      const controller = createWeatherController(tile);
      if (controller) {
        weatherControllers.set(widgetId, controller);
      }
    }
  });
}

function initDraftControls(gridContext) {
  if (!gridContext) {
    return;
  }
  const publishButton = document.querySelector('[data-role="publish"]');
  const revertButton = document.querySelector('[data-role="revert"]');
  const publishForm = document.getElementById('publishForm');
  const publishInput = document.getElementById('publishPayload');

  const submitLegacyPublish = (payloadArray) => {
    if (!publishForm) {
      return false;
    }
    if (publishInput) {
      try {
        publishInput.value = JSON.stringify(payloadArray || []);
      } catch (err) {
        console.warn('Failed to serialize publish payload', err);
        publishInput.value = '[]';
      }
    }
    try {
      if (typeof publishForm.requestSubmit === 'function') {
        const submitter = publishForm.querySelector(
          'button[type="submit"],input[type="submit"],input[type="image"],input[type="button"],button:not([type])',
        );
        if (submitter && !submitter.disabled && submitter.type !== 'button') {
          publishForm.requestSubmit(submitter);
        } else {
          publishForm.submit();
        }


        publishForm.requestSubmit();
      } else {
        publishForm.submit();
      }
      return true;
    } catch (err) {
      console.error('Publish form submission failed', err);
      return false;
    }
  };

  publishButton?.addEventListener('click', async (event) => {
    if (!publishButton) return;
    event?.preventDefault?.();
    publishButton.disabled = true;
    gridContext.cancelPendingDraft?.();

    let fallbackTriggered = false;
    let fallbackSucceeded = false;

    const triggerFallback = (payloadArray) => {
      fallbackTriggered = true;
      const didSubmit = submitLegacyPublish(payloadArray);
      fallbackSucceeded = didSubmit;
      return didSubmit;
    };

    try {
      const payloadArray = gridContext.getPayload ? gridContext.getPayload() : [];
      await gridContext.flushDraftSaves?.();
      const draftResponse = await postJSON(DRAFT_ENDPOINT, payloadArray);
      if (!draftResponse.ok) {
        const text = await draftResponse.text().catch(() => '');
        throw new Error(text || 'Draft save failed');
      }

      const publishUrl = publishButton.getAttribute('data-url') || '/dashboard/publish';
      const publishResponse = await postJSON(publishUrl, { positions: payloadArray });

      if (publishResponse.redirected) {
        window.location.href = publishResponse.url;
      } else if (publishResponse.ok) {
        window.location.href = '/dashboard';
      } else {
        const text = await publishResponse.text().catch(() => '');
        throw new Error(text || 'Publish failed');
      }
    } catch (error) {
      console.error(error);
      const payloadArray = gridContext.getPayload ? gridContext.getPayload() : [];
      if (!triggerFallback(payloadArray)) {
        alert('Unable to publish layout.');
      }
    } finally {
      if (!fallbackTriggered || !fallbackSucceeded) {
        publishButton.disabled = false;
      }
    }
  });

  revertButton?.addEventListener('click', async () => {
    if (!revertButton) return;
    revertButton.disabled = true;
    gridContext.cancelPendingDraft?.();
    try {
      const revertUrl = revertButton.getAttribute('data-url') || '/dashboard/revert-draft';
      const response = await fetch(revertUrl, { method: 'POST' });
      if (response.ok) {
        window.location.reload();
      } else {
        alert('Failed to revert draft.');
      }
    } finally {
      revertButton.disabled = false;
    }
  });
}

function dashboardTools() {
  return {
    menuOpen: false,
    modals: {
      relay: false,
      sensor: false,
      widget: false,
      image: false,
      dummy: false,
      weather: false,
    },
    relayBackend: 'USB',
    relayBoard: 'RELAY1',
    relayChannel: 1,
    relayBcm: 17,
    sensorTiltColor: 'blue',
    sensorFieldSelection: 'both',
    widgetMode: 'text',
    widgetText: '',
    widgetBinding: '',
    imageMode: 'background',
    imageBackgroundUrl: '',
    imageUploadFile: null,
    imageUploadName: '',
    imageOffUrl: '',
    imageOnUrl: '',
    imageSkinUrl: '',
    imagePumpId: '',
    dummyKind: 'dummy_relay',
    weatherLat: '',
    weatherLon: '',
    weatherUnits: 'us',
    weatherLabel: '',
    weatherRefresh: 10,
    submittingAction: null,
    toggleMenu() {
      this.menuOpen = !this.menuOpen;
    },
    closeAll() {
      this.menuOpen = false;
      Object.keys(this.modals).forEach((key) => {
        this.modals[key] = false;
      });
    },
    closeModal(name) {
      if (this.modals[name] !== undefined) {
        this.modals[name] = false;
      }
    },
    resetRelay() {
      this.relayBackend = 'USB';
      this.relayBoard = 'RELAY1';
      this.relayChannel = 1;
      this.relayBcm = 17;
    },
    resetSensor() {
      this.sensorTiltColor = 'blue';
      this.sensorFieldSelection = 'both';
    },
    resetWidget() {
      this.widgetMode = 'text';
      this.widgetText = '';
      this.widgetBinding = '';
    },
    resetImage() {
      this.imageMode = 'background';
      this.imageBackgroundUrl = '';
      this.imageUploadFile = null;
      this.imageUploadName = '';
      this.imageOffUrl = '';
      this.imageOnUrl = '';
      this.imageSkinUrl = '';
      this.imagePumpId = '';
      if (this.$refs?.imageFileInput) {
        this.$refs.imageFileInput.value = '';
      }
    },
    resetDummy() {
      this.dummyKind = 'dummy_relay';
    },
    resetWeather() {
      this.weatherLat = '';
      this.weatherLon = '';
      this.weatherUnits = 'us';
      this.weatherLabel = '';
      this.weatherRefresh = 10;
    },
    openModal(name, preset = null) {
      this.closeAll();
      if (name === 'relay') this.resetRelay();
      if (name === 'sensor') this.resetSensor();
      if (name === 'widget') this.resetWidget();
      if (name === 'image') this.resetImage();
      if (name === 'dummy') {
        this.resetDummy();
        if (preset === 'dummy_data') {
          this.dummyKind = 'dummy_data';
        } else if (preset === 'dummy_relay') {
          this.dummyKind = 'dummy_relay';
        }
      }
      if (name === 'weather') this.resetWeather();
      if (this.modals[name] !== undefined) {
        this.modals[name] = true;
      }
    },
    isSubmitting(key) {
      return this.submittingAction === key;
    },
    helpers() {
      return window.dashboardHelpers || {};
    },
    resolveHelpers() {
      const helpers = this.helpers();
      if (!helpers || typeof helpers.createWidget !== 'function') {
        alert('Dashboard helpers are still loading. Please try again momentarily.');
        return null;
      }
      const grid = helpers.getGrid?.();
      if (!grid) {
        alert('Grid is not ready yet. Please try again in a moment.');
        return null;
      }
      return helpers;
    },
    handleImageFileChange(event) {
      const file = event?.target?.files?.[0] || null;
      this.imageUploadFile = file;
      this.imageUploadName = file ? file.name : '';
    },
    async uploadImageFile(file) {
      const formData = new FormData();
      formData.append('file', file);
      const response = await fetch('/media/upload', {
        method: 'POST',
        body: formData,
      });
      if (response.status === 413) {
        throw new Error('Upload exceeds the 8 MB limit.');
      }
      if (!response.ok) {
        const text = await response.text().catch(() => '');
        throw new Error(text || 'Image upload failed.');
      }
      const data = await response.json().catch(() => null);
      if (!data || typeof data.url !== 'string') {
        throw new Error('Upload did not return an image URL.');
      }
      return data.url;
    },
    async submitRelay() {
      if (this.isSubmitting('relay')) return;
      const helpers = this.resolveHelpers();
      if (!helpers) return;
      const backend = this.relayBackend === 'GPIO' ? 'GPIO' : 'USB';
      const config = {
        device_kind: 'relay',
        backend,
      };
      let title = 'Relay';
      if (backend === 'USB') {
        const board = (this.relayBoard || 'RELAY1').trim() || 'RELAY1';
        const channelNumber = Number(this.relayChannel);
        if (!Number.isInteger(channelNumber) || channelNumber < 1 || channelNumber > 8) {
          alert('Select a channel between 1 and 8.');
          return;
        }
        config.board = board;
        config.channel = channelNumber;
        config.relay_label = `${board}_${channelNumber}`;
        title = `Relay (USB ch ${channelNumber})`;
      } else {
        const bcm = Number(this.relayBcm);
        if (!Number.isInteger(bcm)) {
          alert('Provide a valid BCM pin number.');
          return;
        }
        config.bcm = bcm;
        title = `Relay (GPIO BCM ${bcm})`;
      }
      try {
        this.submittingAction = 'relay';
        const widget = await helpers.createWidget({ kind: 'relay', config });
        if (widget && widget.id) {
          helpers.addWidgetToGrid({ ...widget, title, preview: config });
          helpers.scheduleDraftSave?.();
          this.closeModal('relay');
          this.resetRelay();
        }
      } catch (error) {
        console.error(error);
        alert(error.message || 'Unable to create relay widget.');
      } finally {
        this.submittingAction = null;
      }
    },
    async submitSensor() {
      if (this.isSubmitting('sensor')) return;
      const helpers = this.resolveHelpers();
      if (!helpers) return;
      let fields;
      if (this.sensorFieldSelection === 'both') {
        fields = ['sg', 'temp_f'];
      } else if (this.sensorFieldSelection === 'sg' || this.sensorFieldSelection === 'temp_f') {
        fields = [this.sensorFieldSelection];
      } else {
        fields = ['sg', 'temp_f'];
      }
      const color = (this.sensorTiltColor || 'blue').toLowerCase();
      const config = {
        sensor_kind: 'hydrometer',
        tilt_color: color,
        fields,
      };
      const colorTitle = color.charAt(0).toUpperCase() + color.slice(1);
      const title = `Tilt (${colorTitle})`;
      try {
        this.submittingAction = 'sensor';
        const widget = await helpers.createWidget({ kind: 'hydrometer', config });
        if (widget && widget.id) {
          helpers.addWidgetToGrid({ ...widget, title, preview: config });
          helpers.scheduleDraftSave?.();
          this.closeModal('sensor');
          this.resetSensor();
        }
      } catch (error) {
        console.error(error);
        alert(error.message || 'Unable to create sensor widget.');
      } finally {
        this.submittingAction = null;
      }
    },
    async submitWidget() {
      if (this.isSubmitting('widget')) return;
      const helpers = this.resolveHelpers();
      if (!helpers) return;
      const mode = this.widgetMode === 'number' ? 'number' : 'text';
      let config;
      let title;
      if (mode === 'text') {
        const text = (this.widgetText || '').trim();
        if (!text) {
          alert('Enter text for the widget.');
          return;
        }
        config = { widget_kind: 'text', text, label: text };
        const previewText = text.length > 24 ? `${text.slice(0, 24)}…` : text;
        title = `Text: ${previewText}`;
      } else {
        const binding = (this.widgetBinding || '').trim();
        if (!binding) {
          alert('Enter a data binding for the number widget.');
          return;
        }
        config = { widget_kind: 'number', binding, label: binding };
        title = `Number (${binding})`;
      }
      try {
        this.submittingAction = 'widget';
        const widget = await helpers.createWidget({ kind: 'widget', config });
        if (widget && widget.id) {
          helpers.addWidgetToGrid({ ...widget, title, preview: config });
          helpers.scheduleDraftSave?.();
          this.closeModal('widget');
          this.resetWidget();
        }
      } catch (error) {
        console.error(error);
        alert(error.message || 'Unable to create widget.');
      } finally {
        this.submittingAction = null;
      }
    },
    async submitImage() {
      if (this.isSubmitting('image')) return;
      const helpers = this.resolveHelpers();
      if (!helpers) return;
      const mode = this.imageMode === 'button' ? 'button' : 'background';
      let config;
      let title;
      try {
        this.submittingAction = 'image';
        if (mode === 'background') {
          let imageUrl = (this.imageBackgroundUrl || '').trim();
          if (!imageUrl && this.imageUploadFile) {
            imageUrl = await this.uploadImageFile(this.imageUploadFile);
          }
          if (!imageUrl) {
            alert('Provide an image URL or choose a file to upload.');
            return;
          }
          config = { image_background_url: imageUrl };
          title = 'Image';
        } else {
          const offUrl = (this.imageOffUrl || '').trim();
          const onUrl = (this.imageOnUrl || '').trim();
          const skinUrl = (this.imageSkinUrl || '').trim();
          const pumpRaw = (this.imagePumpId || '').trim();
          if (!offUrl || !onUrl) {
            alert('Both off and on image URLs are required.');
            return;
          }
          let pumpId = null;
          if (pumpRaw) {
            const parsed = Number(pumpRaw);
            if (Number.isNaN(parsed)) {
              alert('Pump ID must be a number.');
              return;
            }
            pumpId = parsed;
          }
          const stateBinding = { type: 'device' };
          if (pumpId !== null) {
            stateBinding.pump_id = pumpId;
          }
          config = {
            image_states: {
              off: { url: offUrl },
              on: { url: onUrl },
            },
            state_binding: stateBinding,
            svg_skin_url: skinUrl || '',
          };
          title = 'Image Button';
        }

        const widget = await helpers.createWidget({ kind: 'image', config });
        if (widget && widget.id) {
          helpers.addWidgetToGrid({ ...widget, title, preview: config });
          helpers.scheduleDraftSave?.();
          this.closeModal('image');
          this.resetImage();
        }
      } catch (error) {
        console.error(error);
        alert(error.message || 'Unable to create image widget.');
      } finally {
        this.submittingAction = null;
      }
    },
    async submitWeather() {
      if (this.isSubmitting('weather')) return;
      const helpers = this.resolveHelpers();
      if (!helpers) return;
      const lat = Number(this.weatherLat);
      if (Number.isNaN(lat)) {
        alert('Provide a latitude (e.g., 37.7749).');
        return;
      }
      const lon = Number(this.weatherLon);
      if (Number.isNaN(lon)) {
        alert('Provide a longitude (e.g., -122.4194).');
        return;
      }
      let refresh = parseInt(this.weatherRefresh, 10);
      if (!Number.isInteger(refresh) || refresh < 1) {
        refresh = 10;
      }
      const units = this.weatherUnits === 'metric' ? 'metric' : 'us';
      const label = (this.weatherLabel || '').trim();
      const config = {
        lat,
        lon,
        units,
        refresh_min: refresh,
      };
      if (label) {
        config.location_label = label;
      }
      const title = label ? `Weather (${label})` : 'Weather';
      try {
        this.submittingAction = 'weather';
        const widget = await helpers.createWidget({ kind: 'weather', config });
        if (widget && widget.id) {
          helpers.addWidgetToGrid({ ...widget, title, preview: config });
          helpers.scheduleDraftSave?.();
          this.closeModal('weather');
          this.resetWeather();
        }
      } catch (error) {
        console.error(error);
        alert(error.message || 'Unable to create weather widget.');
      } finally {
        this.submittingAction = null;
      }
    },
    async submitDummy() {
      if (this.isSubmitting('dummy')) return;
      const helpers = this.resolveHelpers();
      if (!helpers) return;
      const selected = this.dummyKind === 'dummy_data' ? 'dummy_data' : 'dummy_relay';
      let config;
      let title;
      let preview;
      if (selected === 'dummy_data') {
        config = { dummy: true, dummy_kind: 'data', value: '' };
        title = 'Dummy Data Injector';
        preview = 'Value: —';
      } else {
        config = { dummy: true, dummy_kind: 'relay', state: false };
        title = 'Dummy Relay';
        preview = 'State: OFF';
      }
      try {
        this.submittingAction = 'dummy';
        const widget = await helpers.createWidget({ kind: selected, config });
        if (widget && widget.id) {
          helpers.addWidgetToGrid({ ...widget, title, preview });
          helpers.scheduleDraftSave?.();
          this.closeModal('dummy');
          this.resetDummy();
        }
      } catch (error) {
        console.error(error);
        alert(error.message || 'Unable to create dummy widget.');
      } finally {
        this.submittingAction = null;
      }
    },
  };
}

function createWidgetEditor(gridContext) {
  const state = {
    host: null,
    modalEl: null,
    widgetId: null,
    targetEl: null,
    keyHandler: null,
    saving: false,
    deleting: false,
    gridContext,
    bodyOverflow: '',
  };

  const ensureHost = () => {
    if (state.host && state.host.isConnected) {
      return state.host;
    }
    let host = document.getElementById('widgetEditModalHost');
    if (!host) {
      host = document.createElement('div');
      host.id = 'widgetEditModalHost';
      host.setAttribute('aria-live', 'polite');
      document.body.appendChild(host);
    }
    state.host = host;
    return host;
  };

  const setBodyScroll = (disabled) => {
    if (disabled) {
      if (!state.bodyOverflow) {
        state.bodyOverflow = document.body.style.overflow || '';
      }
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = state.bodyOverflow;
      state.bodyOverflow = '';
    }
  };

  const clearError = () => {
    if (!state.modalEl) return;
    const errorBox = state.modalEl.querySelector('[data-role="form-error"]');
    if (errorBox) {
      errorBox.textContent = '';
      errorBox.classList.add('hidden');
    }
  };

  const showError = (message) => {
    if (!state.modalEl) {
      window.alert(message);
      return;
    }
    const errorBox = state.modalEl.querySelector('[data-role="form-error"]');
    if (errorBox) {
      errorBox.textContent = message;
      errorBox.classList.remove('hidden');
    } else {
      window.alert(message);
    }
  };

  const close = () => {
    const host = ensureHost();
    host.innerHTML = '';
    if (host.dataset) {
      delete host.dataset.open;
    }
    setBodyScroll(false);
    if (state.keyHandler) {
      document.removeEventListener('keydown', state.keyHandler, true);
      state.keyHandler = null;
    }
    state.modalEl = null;
    state.widgetId = null;
    state.targetEl = null;
    state.saving = false;
    state.deleting = false;
  };

  const buildPayload = (form) => {
    const payload = {};
    const slugInput = form.querySelector('[name="slug"]');
    if (slugInput) {
      payload.slug = (slugInput.value || '').trim();
    }

    const widgetKind = (form.dataset.widgetKind || '').toLowerCase();
    if (widgetKind === 'relay') {
      const backendSelect = form.querySelector('select[name="relay_backend"]');
      const boardInput = form.querySelector('input[name="relay_board"]');
      const channelSelect = form.querySelector('select[name="relay_channel"]');
      const bcmInput = form.querySelector('input[name="relay_bcm"]');
      payload.relay_backend = backendSelect ? backendSelect.value : undefined;
      payload.relay_board = boardInput ? boardInput.value : undefined;
      if (channelSelect) {
        const channelValue = channelSelect.value;
        payload.relay_channel = channelValue ? Number(channelValue) : channelValue;
      }
      if (bcmInput) {
        const bcmValue = bcmInput.value;
        payload.relay_bcm = bcmValue ? Number(bcmValue) : bcmValue;
      }
    } else if (widgetKind === 'hydrometer' || widgetKind === 'sensor') {
      const typeSelect = form.querySelector('select[name="sensor_type"]');
      const colorSelect = form.querySelector('select[name="sensor_tilt_color"]');
      const fieldsSelect = form.querySelector('select[name="sensor_fields"]');
      const flowIdInput = form.querySelector('input[name="flow_sensor_id"]');
      const flowAliasInput = form.querySelector('input[name="flow_alias"]');
      const probeIdInput = form.querySelector('input[name="temp_probe_id"]');
      const probeAliasInput = form.querySelector('input[name="temp_alias"]');

      payload.sensor_type = typeSelect ? typeSelect.value : undefined;
      payload.sensor_tilt_color = colorSelect ? colorSelect.value : undefined;
      if (fieldsSelect) {
        payload.sensor_fields = Array.from(fieldsSelect.selectedOptions || []).map(
          (option) => option.value,
        );
      }
      payload.flow_sensor_id = flowIdInput ? flowIdInput.value : undefined;
      payload.flow_alias = flowAliasInput ? flowAliasInput.value : undefined;
      payload.temp_probe_id = probeIdInput ? probeIdInput.value : undefined;
      payload.temp_alias = probeAliasInput ? probeAliasInput.value : undefined;
    }

    const dummyKindInput = form.querySelector('input[name="dummy_kind"]:checked');
    if (dummyKindInput) {
      payload.dummy_kind = dummyKindInput.value;
    }
    const dummyStateSelect = form.querySelector('select[name="dummy_state"]');
    if (dummyStateSelect) {
      payload.dummy_state = dummyStateSelect.value;
    }
    const dummyValueInput = form.querySelector('input[name="dummy_value"]');
    if (dummyValueInput) {
      payload.dummy_value = dummyValueInput.value;
    }

    if (widgetKind === 'weather') {
      const locationInput = form.querySelector('input[name="weather_location_label"]');
      const latInput = form.querySelector('input[name="weather_lat"]');
      const lonInput = form.querySelector('input[name="weather_lon"]');
      const unitsSelect = form.querySelector('select[name="weather_units"]');
      const refreshInput = form.querySelector('input[name="weather_refresh"]');
      payload.weather_location_label = locationInput ? locationInput.value : undefined;
      payload.weather_lat = latInput ? latInput.value : undefined;
      payload.weather_lon = lonInput ? lonInput.value : undefined;
      payload.weather_units = unitsSelect ? unitsSelect.value : undefined;
      payload.weather_refresh = refreshInput ? refreshInput.value : undefined;
    }


    return payload;
  };

  const refreshWidget = async () => {
    if (!state.widgetId) {
      return;
    }
    const target =
      state.targetEl ||
      document.querySelector(
        `.grid-stack-item-content[data-widget-id="${state.widgetId}"]`,
      );
    if (!target) {
      return;
    }
    const gridEl = document.getElementById('dashboardGrid');
    const editAttr = gridEl?.dataset?.edit || '';
    const isEditMode = editAttr === '1' || !!state.gridContext?.isEdit;
    const renderUrl = `/widgets/render/${encodeURIComponent(String(state.widgetId))}?mode=${
      isEditMode ? 'edit' : 'view'
    }`;
    try {
      const response = await fetch(renderUrl, {
        headers: { 'HX-Request': 'true' },
        credentials: 'same-origin',
      });
      if (!response.ok) {
        throw new Error(`Render reload failed (${response.status})`);
      }
      const html = await response.text();
      target.innerHTML = html;
      if (window.htmx && typeof window.htmx.process === 'function') {
        window.htmx.process(target);
      }
      initImageTiles(target, { isEdit: isEditMode });
      initWeatherTiles(target);
      initRelayTiles(target);
    } catch (error) {
      console.warn('Failed to refresh widget content', error);
    }
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    if (state.saving || !state.widgetId) {
      return;
    }
    const form = event.currentTarget;
    if (!(form instanceof HTMLFormElement)) {
      return;
    }
    clearError();
    const payload = buildPayload(form);
    const saveButton = form.querySelector('[data-role="save-button"]');
    state.saving = true;
    if (saveButton) {
      saveButton.disabled = true;
      saveButton.setAttribute('data-busy', '1');
    }
    try {
      const response = await fetch(`/widgets/${state.widgetId}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Accept: 'application/json',
        },
        body: JSON.stringify(payload),
        credentials: 'same-origin',
      });
      if (!response.ok) {
        let message = 'Unable to save widget.';
        try {
          const data = await response.json();
          if (data && typeof data === 'object' && data.detail) {
            message = data.detail;
          }
        } catch (error) {
          try {
            const text = await response.text();
            if (text) {
              message = text;
            }
          } catch (error2) {
            console.warn('Save error response parsing failed', error2);
          }
        }
        showError(message);
        return;
      }
      await refreshWidget();
      close();
    } catch (error) {
      console.error('Widget save failed', error);
      showError('Unable to save widget.');
    } finally {
      state.saving = false;
      if (saveButton) {
        saveButton.disabled = false;
        saveButton.removeAttribute('data-busy');
      }
    }
  };

  const handleDelete = async (buttonEl) => {
    if (state.deleting || !state.widgetId) {
      return;
    }
    state.deleting = true;
    if (buttonEl) {
      buttonEl.disabled = true;
      buttonEl.setAttribute('data-busy', '1');
    }
    clearError();
    try {
      const response = await fetch(`/widgets/${state.widgetId}`, {
        method: 'DELETE',
        headers: { Accept: 'application/json' },
        credentials: 'same-origin',
      });
      if (!response.ok) {
        let message = 'Unable to delete widget.';
        try {
          const data = await response.json();
          if (data && typeof data === 'object' && data.detail) {
            message = data.detail;
          }
        } catch (error) {
          try {
            const text = await response.text();
            if (text) {
              message = text;
            }
          } catch (error2) {
            console.warn('Delete error response parsing failed', error2);
          }
        }
        showError(message);
        return;
      }

      const grid = state.gridContext?.grid || null;
      const widgetContent =
        state.targetEl ||
        document.querySelector(
          `.grid-stack-item-content[data-widget-id="${state.widgetId}"]`,
        );
      const gridItem = widgetContent ? widgetContent.closest('.grid-stack-item') : null;
      if (state.widgetId) {
        destroyWeatherController(Number(state.widgetId));
      }
      if (grid && gridItem) {
        grid.removeWidget(gridItem);
      } else if (gridItem) {
        gridItem.remove();
      }

      window.setTimeout(() => {
        state.gridContext?.scheduleDraftSave?.();
      }, 100);

      close();
    } catch (error) {
      console.error('Widget delete failed', error);
      showError('Unable to delete widget.');
    } finally {
      state.deleting = false;
      if (buttonEl) {
        buttonEl.disabled = false;
        buttonEl.removeAttribute('data-busy');
      }
    }
  };

  const setupRelayControls = () => {
    if (!state.modalEl) return;
    const backendSelect = state.modalEl.querySelector('select[name="relay_backend"]');
    const usbSection = state.modalEl.querySelector('[data-relay-section="USB"]');
    const gpioSection = state.modalEl.querySelector('[data-relay-section="GPIO"]');
    const boardInput = state.modalEl.querySelector('input[name="relay_board"]');
    const channelSelect = state.modalEl.querySelector('select[name="relay_channel"]');
    const previewEl = state.modalEl.querySelector('[data-role="relay-label-preview"]');

    const updatePreview = () => {
      if (!previewEl) return;
      const backendValue = (backendSelect?.value || '').toUpperCase();
      if (backendValue !== 'USB') {
        previewEl.textContent = '—';
        return;
      }
      const board = (boardInput?.value || '').trim();
      const channelValue = channelSelect ? Number(channelSelect.value) : NaN;
      if (!board || Number.isNaN(channelValue)) {
        previewEl.textContent = '—';
        return;
      }
      previewEl.textContent = `${board}_${channelValue}`;
    };

    const updateSections = () => {
      const backendValue = (backendSelect?.value || '').toUpperCase();
      if (usbSection) {
        usbSection.classList.toggle('hidden', backendValue !== 'USB');
      }
      if (gpioSection) {
        gpioSection.classList.toggle('hidden', backendValue !== 'GPIO');
      }
      updatePreview();
    };

    backendSelect?.addEventListener('change', updateSections);
    boardInput?.addEventListener('input', updatePreview);
    channelSelect?.addEventListener('change', updatePreview);
    channelSelect?.addEventListener('input', updatePreview);

    updateSections();
  };

  const setupSensorControls = () => {
    if (!state.modalEl) return;
    const typeSelect = state.modalEl.querySelector('select[name="sensor_type"]');
    const sections = state.modalEl.querySelectorAll('[data-sensor-section]');

    const updateSections = () => {
      const selected = (typeSelect?.value || '').toLowerCase();
      sections.forEach((section) => {
        const kind = (section.getAttribute('data-sensor-section') || '').toLowerCase();
        section.classList.toggle('hidden', kind !== selected);
      });
    };

    typeSelect?.addEventListener('change', updateSections);
    updateSections();
  };

  const setupDummyControls = () => {
    if (!state.modalEl) return;
    const form = state.modalEl.querySelector('[data-role="widget-edit-form"]');
    if (!form) return;
    const kindInputs = Array.from(form.querySelectorAll('input[name="dummy_kind"]'));
    if (!kindInputs.length) {
      return;
    }
    const relaySection = form.querySelector('[data-dummy-section="relay"]');
    const dataSection = form.querySelector('[data-dummy-section="data"]');
    const kindLabel = state.modalEl.querySelector('[data-role="dummy-kind-label"]');

    const updateSections = () => {
      const checked = form.querySelector('input[name="dummy_kind"]:checked');
      const raw = (checked ? checked.value : '').toLowerCase();
      const normalized = raw === 'dummy_data' || raw === 'dummy_sensor' || raw === 'data' ? 'data' : 'relay';
      if (relaySection) {
        relaySection.classList.toggle('hidden', normalized !== 'relay');
      }
      if (dataSection) {
        dataSection.classList.toggle('hidden', normalized !== 'data');
      }
      if (kindLabel) {
        kindLabel.textContent = normalized === 'relay' ? 'Dummy Relay' : 'Dummy Data Injector';
      }
    };

    kindInputs.forEach((input) => {
      input.addEventListener('change', updateSections);
    });

    updateSections();
  };


  const hydrateModal = (modal) => {
    state.modalEl = modal;
    clearError();
    const form = modal.querySelector('[data-role="widget-edit-form"]');
    form?.addEventListener('submit', handleSubmit);

    modal.querySelectorAll('[data-role="close-modal"]').forEach((button) => {
      button.addEventListener('click', (event) => {
        event.preventDefault();
        close();
      });
    });

    const backdrop = modal.querySelector('[data-role="overlay-backdrop"]');
    backdrop?.addEventListener('click', (event) => {
      event.preventDefault();
      close();
    });

    const deleteButton = modal.querySelector('[data-role="delete-button"]');
    const confirmBlock = modal.querySelector('[data-role="delete-confirm"]');
    const confirmButton = confirmBlock?.querySelector('[data-role="confirm-delete"]');
    const cancelButton = confirmBlock?.querySelector('[data-role="cancel-delete"]');

    if (deleteButton && confirmBlock) {
      deleteButton.addEventListener('click', (event) => {
        event.preventDefault();
        deleteButton.classList.add('hidden');
        confirmBlock.classList.remove('hidden');
      });
      cancelButton?.addEventListener('click', (event) => {
        event.preventDefault();
        confirmBlock.classList.add('hidden');
        deleteButton.classList.remove('hidden');
      });
      confirmButton?.addEventListener('click', (event) => {
        event.preventDefault();
        handleDelete(confirmButton);
      });
    }

    setupRelayControls();
    setupSensorControls();
    setupDummyControls();
  };

  const open = async (widgetId, targetEl) => {
    const id = Number(widgetId);
    if (!id) {
      return;
    }
    const host = ensureHost();
    state.widgetId = id;
    state.targetEl = targetEl || null;
    state.modalEl = null;
    host.dataset.open = '1';
    host.innerHTML = '';
    setBodyScroll(true);

    const loading = document.createElement('div');
    loading.className = 'fixed inset-0 z-50 flex items-center justify-center bg-slate-950/70';
    loading.innerHTML =
      '<div class="rounded-lg border border-slate-700/70 bg-slate-900 px-4 py-3 text-sm text-slate-200">Loading…</div>';
    host.appendChild(loading);

    try {
      const response = await fetch(`/widgets/${id}/edit`, {
        headers: { Accept: 'text/html', 'HX-Request': 'true' },
        credentials: 'same-origin',
      });
      if (!response.ok) {
        throw new Error(`Edit fetch failed (${response.status})`);
      }
      const html = await response.text();
      host.innerHTML = html;
      const modal = host.querySelector('[data-role="widget-edit-overlay"]');
      if (!modal) {
        throw new Error('Edit modal markup missing');
      }
      state.modalEl = modal;
      state.keyHandler = (event) => {
        if (event.key === 'Escape') {
          event.preventDefault();
          close();
        }
      };
      document.addEventListener('keydown', state.keyHandler, true);
      hydrateModal(modal);
    } catch (error) {
      console.error('Failed to open widget editor', error);
      host.innerHTML = '';
      setBodyScroll(false);
      close();
      window.alert('Unable to open widget editor.');
    }
  };

  return {
    open,
    close,
  };
}

function initTileEditTriggers(gridEl, editor) {
  if (!gridEl || !editor || typeof editor.open !== 'function') {
    return;
  }

  const getContentEl = (target) => target?.closest('.grid-stack-item-content');
  let longPressTimer = null;

  const cancelLongPress = () => {
    if (longPressTimer) {
      window.clearTimeout(longPressTimer);
      longPressTimer = null;
    }
  };

  gridEl.addEventListener('click', (event) => {
    const trigger = event.target instanceof HTMLElement ? event.target.closest('[data-role="tile-edit-trigger"]') : null;
    if (!trigger) {
      return;
    }
    event.preventDefault();
    event.stopPropagation();
    const content = getContentEl(trigger);
    if (!content) {
      return;
    }
    const widgetId = Number(trigger.dataset.widgetId || content.dataset.widgetId);
    if (!widgetId) {
      return;
    }
    editor.open(widgetId, content);
  });

  gridEl.addEventListener('dblclick', (event) => {
    const content = getContentEl(event.target);
    if (!content) {
      return;
    }
    const widgetId = Number(content.dataset.widgetId);
    if (!widgetId) {
      return;
    }
    event.preventDefault();
    editor.open(widgetId, content);
  });

  gridEl.addEventListener(
    'touchstart',
    (event) => {
      if (!event || (event.touches && event.touches.length > 1)) {
        cancelLongPress();
        return;
      }
      const content = getContentEl(event.target);
      if (!content) {
        cancelLongPress();
        return;
      }
      cancelLongPress();
      longPressTimer = window.setTimeout(() => {
        longPressTimer = null;
        const widgetId = Number(content.dataset.widgetId);
        if (widgetId) {
          editor.open(widgetId, content);
        }
      }, 550);
    },
    { passive: true },
  );

  const touchCancel = () => {
    cancelLongPress();
  };

  gridEl.addEventListener('touchmove', cancelLongPress, { passive: true });
  gridEl.addEventListener('touchend', touchCancel);
  gridEl.addEventListener('touchcancel', touchCancel);
}

function initDashboard() {
  const gridEl = document.getElementById('dashboardGrid');
  if (!gridEl) {
    return;
  }
  const isEdit = gridEl.dataset.edit === '1';
  const gridContext = initGridstack({ isEdit });

  window.dashboardGridContext = gridContext;
  window.dashboardHelpers = window.dashboardHelpers || {};
  window.dashboardHelpers.getGrid = () => window.dashboardGridContext?.grid || null;
  window.dashboardHelpers.createWidget = (options) => createWidget(options);
  window.dashboardHelpers.addWidgetToGrid = (options) => {
    const grid = window.dashboardGridContext?.grid || null;
    if (!grid) {
      return null;
    }
    return addWidgetToGrid(grid, options);
  };
  window.dashboardHelpers.scheduleDraftSave = () => {
    window.dashboardGridContext?.scheduleDraftSave?.();
  };

  const widgetEditor = createWidgetEditor(gridContext);
  window.dashboardWidgetEditor = widgetEditor;
  window.dashboardHelpers.openWidgetEditor = (widgetId, targetEl) => {
    widgetEditor.open(widgetId, targetEl);
  };

  if (gridContext && gridContext.grid) {
    window.dashboardGrid = gridContext.grid;
  }

  if (gridContext?.isEdit) {
    initDraftControls(gridContext);
    initTileEditTriggers(gridEl, widgetEditor);
  }

  initWeatherTiles(document);
  initHydrometerTiles(document);
  initRelayTiles(document);
  initImageTiles(document, { isEdit });
  initRelayTiles(document);
  initImageTiles(document, { isEdit });

}

window.dashboardTools = dashboardTools;

if (typeof document !== 'undefined') {
  document.body?.addEventListener('htmx:beforeSwap', (event) => {
    const target = event?.target;
    if (!(target instanceof HTMLElement)) {
      return;
    }
    const tiles = target.querySelectorAll('[data-role="weather-tile"]');
    tiles.forEach((tile) => {
      const widgetId = Number(tile.dataset.widgetId);
      if (widgetId) {
        destroyWeatherController(widgetId);
      }
    });
    const imageTiles = target.querySelectorAll('[data-role="image-tile"]');
    imageTiles.forEach((tile) => {
      const state = imageTileState.get(tile);
      if (state?.cleanup) {
        state.cleanup();
      }
      imageTileState.delete(tile);
    });
  });

  document.body?.addEventListener('htmx:afterSwap', (event) => {
    const target = event?.target;
    if (!(target instanceof HTMLElement)) {
      return;
    }
    initWeatherTiles(target);
    initHydrometerTiles(target);

    initRelayTiles(target);
    const gridEl = target.closest('#dashboardGrid');
    const isEdit = gridEl?.dataset?.edit === '1';
    initImageTiles(target, { isEdit });
  });
}

document.addEventListener('DOMContentLoaded', initDashboard);
