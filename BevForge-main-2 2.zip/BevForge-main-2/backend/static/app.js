async function pumpOn(id){ await fetch(`/devices/pump/${id}/on`, {method:'POST'}); document.getElementById(`pump-state-${id}`).textContent='state: ON'; }
async function pumpOff(id){ await fetch(`/devices/pump/${id}/off`, {method:'POST'}); document.getElementById(`pump-state-${id}`).textContent='state: OFF'; }
async function refreshHydro(id){
  const color = document.getElementById(`hydro-color-${id}`).value || 'red';
  const res = await fetch(`/sensors/hydrometer/latest/${color}`);
  const j = await res.json();
  document.getElementById(`hydro-out-${id}`).textContent = JSON.stringify(j, null, 2);
}
function savePositions(){
  const tiles = Array.from(document.querySelectorAll('.tile'));
  const payload = tiles.map((el, idx)=>({id: parseInt(el.dataset.id), x:0, y:idx, w:1, h:1}));
  fetch('/widgets/pos', {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(payload)}).then(()=>{
    alert('Positions saved.');
  });
}


async function allOff(){
  try{
    await fetch('/devices/all_off', {method:'POST'});
    // update any visible pump states to OFF
    document.querySelectorAll('[id^="pump-state-"]').forEach(el => el.textContent = 'state: OFF');
    alert('All pumps turned OFF');
  }catch(e){
    alert('Failed to turn all off');
  }
}
