from fastapi import APIRouter, Request
from fastapi.responses import HTMLResponse

router = APIRouter()

@router.get("/addons/ferment-tracker", response_class=HTMLResponse)
def ferment_tracker_home(request: Request):
    # Minimal HTML; we could also render a Jinja template if your loader passes templates
    return """
<!doctype html>
<html>
<head>
  <meta charset="utf-8"/>
  <title>Ferment Tracker Addon</title>
  <style>
    :root { color-scheme: dark; }
    body { font-family: system-ui, -apple-system, Segoe UI, Roboto, sans-serif;
           background:#0b0f1a; color:#e6e9ef; margin:0; padding:1rem; }
    .card { border:1px solid #1e2842; border-radius:.75rem; padding:.75rem; }
    .muted { opacity:.75; }
    a { color:#8ab4ff; text-decoration:none; }
    a:hover { text-decoration:underline; }
  </style>
</head>
<body>
  <h1>Fermentation Tracker — Addon</h1>
  <div class="card">
    <p class="muted">Hello from the add-ons framework. This page proves scanning & mounting works.</p>
    <ul>
      <li>Try the Sensors UI: <a href="/sensors/ui">/sensors/ui</a></li>
      <li>Try the Devices UI: <a href="/devices/ui">/devices/ui</a></li>
    </ul>
  </div>
</body>
</html>
    """

def mount(app, templates=None):
    # The loader calls this function. We just include our router.
    app.include_router(router)
