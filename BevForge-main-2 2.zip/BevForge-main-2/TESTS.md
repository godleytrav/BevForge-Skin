This checklist verifies a clean install on a Raspberry Pi (Debian Bookworm, Python 3.11).

Terminal A = server (start/stop Uvicorn here)

Terminal B = tests/patches (no server restarts from here)

0) Prep

In Terminal B:

cd /home/godley-ciders/bevforge-os
. .venv/bin/activate 2>/dev/null || true

1) Start the server (Terminal A)
cd /home/godley-ciders/bevforge-os
. .venv/bin/activate
uvicorn bevforge.main:app --app-dir backend --host 0.0.0.0 --port 8080 --reload


Expected: Uvicorn prints “Running on http://0.0.0.0:8080
 …” and “Automation loop running.”

2) Admin endpoints

In Terminal B:

# version
curl -sS http://127.0.0.1:8080/admin/version | jq .

# health (HTML; just verify 200)
curl -sI http://127.0.0.1:8080/admin/health | head -n1

# logs download (non-empty)
curl -sS http://127.0.0.1:8080/admin/logs/download -o backend/logs/app-snapshot.log
ls -lh backend/logs/app-snapshot.log


Expect: /admin/version returns JSON with name, version, etc. Logs file exists and >0 bytes.

3) Devices & pumps (dummy OK)
# list devices/backend
curl -sS http://127.0.0.1:8080/devices/backend | jq .

# ensure widgets list is reachable
curl -sS http://127.0.0.1:8080/widgets | jq .


Expect: A JSON object for backend driver and an array (maybe empty) for widgets.

4) Create a pump widget (id=1) if none exists
# create pump-1 if needed
curl -sS -X POST "http://127.0.0.1:8080/widgets" \
  -H 'Content-Type: application/json' \
  -d '{"kind":"pump","label":"Pump 1"}' | jq .

# verify
curl -sS http://127.0.0.1:8080/widgets | jq .


Expect: A pump widget with id (note the id; examples below assume 1).

5) Hydrometer ingest (Tilt HTTP path) + latest
# HOT sample (F=72)
curl -sS -X POST http://127.0.0.1:8080/sensors/tilt/ingest \
  -H 'Content-Type: application/json' \
  -d '{"color":"red","temp_f":72.0,"sg":1.045}' | jq .

# latest
curl -sS http://127.0.0.1:8080/sensors/hydrometer/latest/red | jq .


Expect: JSON shows temp_f≈72.0, sg≈1.045.

6) Automations: create + add rule + poke
# create an automation
AUTO_ID=$(curl -sS -X POST "http://127.0.0.1:8080/automations?label=Cooler%20Control" | jq -r .id)
echo "AUTO_ID=$AUTO_ID"

# add rule: hydro_temp_pump (on>=70, off<=68, pump_widget_id=1)
curl -sS -X POST "http://127.0.0.1:8080/automations/$AUTO_ID/rules" \
  -H 'Content-Type: application/json' \
  -d '{"kind":"hydro_temp_pump","label":"Keep cool","config":{"color":"red","units":"f","on_above":70,"off_below":68,"pump_widget_id":1}}' | jq .

# force evaluation (should decide ON for 72F)
curl -sS -X POST http://127.0.0.1:8080/automations/poke | jq .


Expect: Response includes "decided": true and an action with "action": "ON" and "pump_id": 1.

# now COOL (67F)
curl -sS -X POST http://127.0.0.1:8080/sensors/tilt/ingest \
  -H 'Content-Type: application/json' \
  -d '{"color":"red","temp_f":67.0,"sg":1.044}' | jq .

# force evaluation (should decide OFF)
curl -sS -X POST http://127.0.0.1:8080/automations/poke | jq .


Expect: "action": "OFF" for "pump_id": 1.

7) Check logs for pump actions
curl -sS http://127.0.0.1:8080/admin/logs/download | tail -n 40


Expect to see entries like:

PUMP 1 -> ON (gpiozero pin … or usbrelay … or simulated)

PUMP 1 -> OFF …

8) Automations UI + enable/disable toggle
# UI should load (200)
curl -sI http://127.0.0.1:8080/automations/ui | head -n1

# Enable/disable rule id=1 (adjust if needed)
curl -sS -X POST http://127.0.0.1:8080/automations/rules/1/disable | jq .
curl -sS -X POST http://127.0.0.1:8080/automations/rules/1/enable  | jq .


Expect: HTTP 200 for UI; JSON {"ok":true} for enable/disable.

9) Dashboard drag/persist (manual)

Open http://<pi-ip>:8080/dash/main

Toggle ?edit=1, drag a tile, click Publish.

Reload page: position should persist.

10) Add-ons: ferment-tracker
# route should respond 200
curl -sI http://127.0.0.1:8080/addons/ferment-tracker | head -n1


Expect: HTTP/1.1 200 OK.

11) DB backup (download) — Non-empty file
curl -sS http://127.0.0.1:8080/admin/db/backup -o backend/data/bevforge-backup-test.db
ls -lh backend/data/bevforge-backup-test.db


Expect: file exists and non-zero size.

12) Log rotation (optional)

If you enabled the /admin/logs/rotate endpoints:

# rotate
curl -sS -X POST http://127.0.0.1:8080/admin/logs/rotate | jq .

# list logs
ls -lh backend/logs


Expect: app.log + rotated copies (e.g., app.log.1, …) per your rotation settings.

Troubleshooting

Cannot import add-on: ensure backend/bevforge/addons/ferment_tracker/ exists with __init__.py, router.py, templates/ferment_tracker_home.html.

Pump actions “not mapped”: verify PUMP_BACKEND, PUMP_GPIO_MAP, and/or PUMP_USB_MAP env vars.

/automations/poke JSON parse errors: ensure you’re not piping curl output through jq when the endpoint returns plain text; our current version returns JSON, so jq is fine.

Server fails to start: check backend/bevforge/routers/* for stray merge text or quoting errors.

## UI Verification Checklist (Field Install)

### Phone (portrait)
- Open `http://<pi-ip>:8080/dashboard` and confirm tiles render edge-to-edge with focus outlines visible when tabbing.
- Toggle a pump or dummy relay to verify the toast notification appears and the state badge updates without a page reload.
- Rotate the device or reopen the page to ensure published positions persist and no autosave restore prompt appears outside edit mode.

### Tablet (landscape)
- Visit `/dashboard/edit`, sign in with an editor credential, and confirm the floating “Quick add” button opens relay, sensor, image, and dummy dialogs.
- Drag a tile, add a quick-add widget, publish the layout, and reload to ensure the draft cleared and the new tile persists.
- Double-click an existing tile to open the inline editor, update the slug, save, and verify the tile refreshes in place.

### Desktop
- Load `/automations/edit`, drag at least one sensor and one pump into the canvas, connect them, and publish; confirm you are redirected to `/dashboard/edit` afterward.
- Issue a POST to `/devices/test-all?seconds=0.5` from another tab or terminal and confirm the browser shows updated device toasts or status badges when the polling loop refreshes.
- Open `/admin/hardware/diag` in a separate tab to verify GPIO/USB maps, Tilt BLE status, and mapped readbacks are present for installers.
