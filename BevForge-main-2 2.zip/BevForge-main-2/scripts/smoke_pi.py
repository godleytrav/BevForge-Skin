from fastapi.testclient import TestClient

from bevforge.main import app


def main() -> None:
    with TestClient(app) as client:
        health = client.get("/healthz")
        assert health.status_code == 200, "GET /healthz did not return HTTP 200"
        payload = health.json()
        assert payload == {"ok": True}, "GET /healthz payload mismatch"

        dashboard = client.get("/dashboard")
        assert dashboard.status_code == 200, "GET /dashboard did not return HTTP 200"

    print("\u2713 smoke ok")


if __name__ == "__main__":
    main()
