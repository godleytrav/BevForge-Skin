#!/usr/bin/env bash
set -euo pipefail

repo_root=$(git rev-parse --show-toplevel 2>/dev/null || pwd)
cd "$repo_root"

conflict_output=$(git grep -nE '^(<<<<<<<|=======|>>>>>>>)' -- || true)
if [[ -n "$conflict_output" ]]; then
  echo "✖ Conflict markers detected in tracked files:"
  echo "$conflict_output"
  exit 1
fi

missing=0
while IFS='|' read -r file marker; do
  [[ -z "$file" ]] && continue
  if [[ ! -f "$file" ]]; then
    echo "✖ Missing file for sentinel '$marker': $file"
    missing=1
    continue
  fi
  if ! grep -Fq "$marker" "$file"; then
    echo "✖ Missing sentinel '$marker' in $file"
    missing=1
  fi
done <<'SENTINELS'
backend/templates/dashboard.html|SENTINEL: DASHBOARD-TEMPLATE
backend/templates/dashboard.html|SENTINEL: EDIT-TOOLS-PRESENT
backend/bevforge/routers/dash.py|SENTINEL: DASHBOARD-ROUTER
backend/bevforge/routers/devices.py|SENTINEL: DEVICES-ROUTER
backend/templates/tools_devices.html|SENTINEL: DEVICES-TEMPLATE
SENTINELS

if ((missing)); then
  exit 1
fi

echo "✓ CI guard passed"
