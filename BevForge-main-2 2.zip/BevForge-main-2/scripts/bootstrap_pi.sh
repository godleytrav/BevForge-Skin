#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"

python3 -m venv .venv
source .venv/bin/activate

pip install -U pip wheel

if [[ -f "requirements.txt" ]]; then
  pip install -r requirements.txt
elif [[ -f "backend/requirements.txt" ]]; then
  pip install -r backend/requirements.txt
elif [[ -f "pyproject.toml" ]]; then
  pip install .
else
  pip install uvicorn fastapi sqlmodel "pydantic>=2,<3"
fi

export PUMP_BACKEND="Dummy"

python scripts/smoke_pi.py

echo
echo "Next: uvicorn --app-dir backend bevforge.main:app --host 0.0.0.0 --port 8080"
