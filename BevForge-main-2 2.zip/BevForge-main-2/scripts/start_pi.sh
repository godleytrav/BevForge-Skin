#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
ENV_FILE="${HOME}/.bevforge_env"

if [[ -f "$ENV_FILE" ]]; then
  set -a
  # shellcheck disable=SC1090
  source "$ENV_FILE"
  set +a
fi

cd "$ROOT_DIR"

PORT="${PORT:-8080}"

if [[ -d ".venv" ]]; then
  source .venv/bin/activate
else
  echo "Virtual environment not found. Run scripts/bootstrap_pi.sh first." >&2
  exit 1
fi

export PYTHONPATH="${ROOT_DIR}/backend:${PYTHONPATH:-}"
export PUMP_BACKEND="${PUMP_BACKEND:-AUTO}"

exec .venv/bin/uvicorn \
  --app-dir backend \
  bevforge.main:app \
  --host 0.0.0.0 \
  --port "$PORT" \
  --log-level debug
