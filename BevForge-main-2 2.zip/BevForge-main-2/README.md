# BevForge

BevForge Suite is a modular platform for breweries, wineries, and cideries. From Raspberry Pi–powered device control to CRM, recipes, inventory, and workforce tools, BevForge lets you pick what you need: OS, Control, Flow, Lab, Connect, and WorkForce — your new BF (Best Friend).

## Raspberry Pi quick start

1. Create `/etc/udev/rules.d/99-usbrelay.rules` with:
   ```
   SUBSYSTEM=="hidraw", ATTRS{idVendor}=="16c0", ATTRS{idProduct}=="05df", MODE="0666", SYMLINK+="usbrelay%n"
   ```
   Then reload the rules (`sudo udevadm control --reload-rules && sudo udevadm trigger`) and replug the relay.
2. (Optional) Add `TILT_BLE_ENABLE=1` to `~/.bevforge_env` so the Tilt scanner starts automatically once Bluetooth is ready.
3. After running `./scripts/bootstrap_pi.sh` once to set up the virtualenv, start the app with `./scripts/start_bevforge.sh`. The script loads `~/.bevforge_env`, defaults to automatic USB relay detection, and serves on port 8080.
4. Visit `http://<pi>:8080/admin/diagnostics` and `/devices/relay/health` to confirm the relay and BLE status before wiring tiles to hardware.

## Dashboard layouts & publishing

### Draft vs. published positions
BevForge dashboards store two sets of tile coordinates. The published layout (`x`, `y`, `w`, `h`) is what production tablets and wall displays render. When you edit the board, changes are staged in the draft columns (`draft_x`, `draft_y`, `draft_w`, `draft_h`) so you can experiment without disrupting the live view. Tiles marked as having a draft appear with a pill badge until you publish.

### Editor access & workflow
Open `/dashboard` for the live board or `/dashboard/edit` to make changes. Editor-only routes require HTTP Basic credentials that map to the `admin` or `manager` roles. Set `ADMIN_BASIC` and/or `MANAGER_BASIC` in your `.env` (`username:password` pairs) to protect publishing, automation editing, device mapping, and similar tooling. If no credentials are configured the UI stays open for quick bench testing.

While in edit mode you can drag tiles, resize them, and use the floating “Quick add” launcher. Publishing writes any staged draft coordinates back to the published columns and redirects to the dashboard home. Use **Revert Draft** to discard changes. Autosave snapshots the current draft arrangement to `localStorage` every five seconds and prompts you to restore or discard the snapshot the next time you open edit mode on the same browser.

Keyboard hints: **Esc** exits edit mode, while **Enter** and **Space** toggle the currently focused device tile so screen-reader and keyboard users can test relays without a pointer.

## Quick-add tiles & config_json reference

The “Quick add” palette appears in the top-left corner of `/dashboard/edit`. Each entry submits a widget payload to `/widgets` with a pre-built `config_json`. You can double-click any tile to open the inline editor and fine-tune the JSON afterward.

Common payload shapes:

- **Relay tiles**
  ```json
  {
    "device_kind": "relay",
    "backend": "GPIO",
    "bcm": 17,
    "created_via": "quick-add"
  }
  ```
  ```json
  {
    "device_kind": "relay",
    "backend": "USB",
    "relay_label": "RELAY1_1",
    "created_via": "quick-add"
  }
  ```

- **Tilt hydrometer tiles**
  ```json
  {
    "sensor_kind": "hydrometer",
    "tilt_color": "blue",
    "fields": ["sg", "temp_f"],
    "created_via": "quick-add"
  }
  ```

- **Display widgets**
  ```json
  {
    "widget_kind": "text",
    "text": "Notes go here",
    "created_via": "quick-add"
  }
  ```
  ```json
  {
    "widget_kind": "number",
    "binding": "hydrometer.blue.sg",
    "unit": "SG",
    "created_via": "quick-add"
  }
  ```

- **Image & GIF tiles**
  ```json
  {
    "image_states": {
      "off": {"url": "https://example.com/pump-off.gif"},
      "on":  {"url": "https://example.com/pump-on.gif"}
    },
    "state_binding": {"type": "device", "pump_id": 1},
    "created_via": "quick-add"
  }
  ```

- **Dummy relays & sensors**
  ```json
  {
    "dummy": true,
    "dummy_kind": "relay",
    "state": false,
    "created_via": "quick-add"
  }
  ```
  ```json
  {
    "dummy": true,
    "dummy_kind": "sensor",
    "temp_f": 68,
    "sg": 1.050,
    "color": "dummy",
    "created_via": "quick-add"
  }
  ```

## Stateful images & SVG skins
Tiles that include `config.image_states` will swap imagery whenever their bound state changes. Supported bindings:

- **Device bindings** — set `state_binding` to an object with identifiers such as `pump_id`, `device_id`, or `slug`. Example: `{ "type": "device", "pump_id": 1 }` watches the mapped relay for widget #1. You can also rely on slugs, e.g. `{ "type": "device", "slug": "pump-1" }`.
- **Sensor bindings** — set `type: "sensor"`, specify a Tilt color, and optionally add comparison metadata. Example: `{ "type": "sensor", "color": "red", "field": "temp_f", "op": ">=", "threshold": 68 }` drives the “on” image whenever the red Tilt reads at or above 68 °F. Use `on_values`, `equals`, or `invert` to handle non-numeric comparisons.
- **Static defaults** — omit `type` and include `default_state` (`"on"`, `true`, etc.) to keep a fixed image without polling hardware.

Add an optional SVG overlay by supplying `config.skin`:

```json
{
  "image_states": {
    "off": {"url": "https://example.com/valve-closed.png"},
    "on":  {"url": "https://example.com/valve-open.png"}
  },
  "state_binding": {"type": "device", "slug": "glycol-valve"},
  "skin": {"svg_url": "https://example.com/overlay.svg", "opacity": 0.65}
}
```

The `<object type="image/svg+xml">` overlay ignores pointer events so you can still interact with the tile beneath it.

## Dummy tiles & endpoints
Dummy relays toggle entirely on the client. Each click logs to `/dashboard/dummy/log` with the widget id, label, and new state so operators can verify interaction without touching hardware. Image bindings on dummy tiles reuse the same `image_states` logic described above.

Dummy sensor tiles expose inline form controls while `/dashboard/edit` is active. Submitting the form posts to `/sensors/dummy/ingest`:

```json
{
  "widget_id": 42,
  "color": "dummy",
  "temp_f": 64.0,
  "sg": 1.032
}
```

The endpoint upserts a matching row in `HydrometerLatest`, so any hydrometer widgets (real or dummy) that poll that color update on the next refresh.

## Automation tools

### Visual editor (`/automations/edit`)
The automation graph editor requires an editor-role Basic credential. Select an automation, drag widgets from the sidebar into the canvas, and pull the blue handle on a node to connect it to another node. Click a string to expose re-route handles; double-click to delete the link. Publishing saves node layout, regenerates all rules for the chosen automation, and then redirects you back to `/dashboard/edit` so you can place the corresponding device tiles.

During synthesis the server scans sensor→device links. Hydrometer sensors linked to pump widgets emit hysteresis rules (`hydro_temp_pump`) that obey the threshold values stored in each widget’s `config_json`. PATCH `/automations/{automation_id}/graph/links/{link_id}` with `{"kind": "pid_pump"}` to flip a connector to the PID executor when you need time-proportional pump control — the evaluator maintains integral and derivative state per rule at runtime.

### Legacy list & quick creators (`/automations/ui`)
The legacy automations list remains available for bulk edits and quick rule creation. Use the “Add pid_pump” row to seed PID rules with default gains, targets, and window sizing without building a graph first. Any rules created here appear alongside graph-synthesized rules under the selected automation.

## Diagnostics & device testing
- Visit `/admin/hardware/diag` to inspect the active pump backend, GPIO/USB mapping tables, best-effort readbacks for each mapped device, detected USB relay candidates, and Tilt BLE heartbeat (`USE_BLE` flag plus the last scan timestamp when implemented).
- POST to `/devices/test-all?seconds=0.5` to cycle every mapped relay for the provided dwell time. The response includes per-device success/error details while the server log records ON/OFF transitions for the sequence.


## Optional pre-commit hook
To run the CI guard locally before every commit, create `.git/hooks/pre-commit` with:

```bash
#!/usr/bin/env bash
# docs: .git/hooks/pre-commit
exec bash scripts/ci_guard.sh
```

Make the hook executable (`chmod +x .git/hooks/pre-commit`) and git will block commits if the conflict-marker or sentinel checks fail.
