# Repo: /home/godley-ciders/bevforge-os
# Save as: tests/run_all.sh
# Usage (Terminal B):
#   cd /home/godley-ciders/bevforge-os
#   mkdir -p tests
#   nano tests/run_all.sh   # paste this file
#   chmod +x tests/run_all.sh
#   ./tests/run_all.sh

#!/usr/bin/env bash
set -euo pipefail

BASE="http://127.0.0.1:8080"
LOG_DIR="backend/logs"
DATA_DIR="backend/data"
PUMP_ID=1
COLOR="red"

RED='\033[0;31m'; GRN='\033[0;32m'; YLW='\033[1;33m'; NC='\033[0m'
pass(){ echo -e "${GRN}✔ $*${NC}"; }
fail(){ echo -e "${RED}✘ $*${NC}"; exit 1; }
info(){ echo -e "${YLW}➜ $*${NC}"; }

jq >/dev/null 2>&1 || { fail "jq not found. Install: sudo apt-get install -y jq"; }

info "Checking server is reachable on ${BASE}"
curl -fsS "$BASE/admin/version" >/dev/null || fail "Server not responding. Start it in Terminal A."

info "Admin: /admin/version"
curl -fsS "$BASE/admin/version" | jq . >/dev/null && pass "/admin/version OK"

info "Admin: /admin/health (HTML)"
code=$(curl -s -o /dev/null -w "%{http_code}" "$BASE/admin/health")
[ "$code" = "200" ] && pass "/admin/health 200" || fail "/admin/health $code"

mkdir -p "$LOG_DIR" "$DATA_DIR"

info "Logs download -> $LOG_DIR/app-snapshot.log"
curl -fsS "$BASE/admin/logs/download" -o "$LOG_DIR/app-snapshot.log"
[ -s "$LOG_DIR/app-snapshot.log" ] && pass "logs non-empty" || fail "logs empty"

info "Widgets list"
curl -fsS "$BASE/widgets" | jq . >/dev/null && pass "widgets reachable"

info "Ensure Pump widget exists (id may vary; we try to create one if missing)"
WCOUNT=$(curl -fsS "$BASE/widgets" | jq '[.[] | select(.kind=="pump")] | length')
if [ "$WCOUNT" -eq 0 ]; then
  curl -fsS -X POST "$BASE/widgets" \
    -H 'Content-Type: application/json' \
    -d '{"kind":"pump","label":"Pump 1"}' | jq . >/dev/null
  pass "Created Pump 1"
else
  pass "Pump widget already exists"
fi

# Try to discover the first pump id (fallback to 1)
PID=$(curl -fsS "$BASE/widgets" | jq '[.[] | select(.kind=="pump")][0].id // 1')
PUMP_ID=${PID:-1}
info "Using pump id: $PUMP_ID"

info "Hydrometer ingest HOT (72F)"
curl -fsS -X POST "$BASE/sensors/tilt/ingest" \
  -H 'Content-Type: application/json' \
  -d "{\"color\":\"$COLOR\",\"temp_f\":72.0,\"sg\":1.045}" | jq . >/dev/null && pass "HOT ingest OK"

info "Hydrometer latest"
curl -fsS "$BASE/sensors/hydrometer/latest/$COLOR" | jq . >/dev/null && pass "latest OK"

info "Create automation 'Cooler Control' (id capture)"
AUTO_ID=$(curl -fsS -X POST "$BASE/automations?label=Cooler%20Control" | jq -r .id)
[ -n "$AUTO_ID" ] && pass "automation id=$AUTO_ID" || fail "automation create failed"

info "Add hydro_temp_pump rule (on>=70, off<=68, pump=$PUMP_ID)"
curl -fsS -X POST "$BASE/automations/$AUTO_ID/rules" \
  -H 'Content-Type: application/json' \
  -d "{\"kind\":\"hydro_temp_pump\",\"label\":\"Keep cool\",\"config\":{\"color\":\"$COLOR\",\"units\":\"f\",\"on_above\":70,\"off_below\":68,\"pump_widget_id\":$PUMP_ID}}" \
  | jq . >/dev/null && pass "rule added"

info "Poke (expect ON)"
POKE_ON=$(curl -fsS -X POST "$BASE/automations/poke")
echo "$POKE_ON" | jq . >/dev/null || fail "poke returned non-JSON"
echo "$POKE_ON" | grep -q '"action": *"ON"' && pass "rule decided ON" || fail "expected ON action"

info "Hydrometer ingest COOL (67F)"
curl -fsS -X POST "$BASE/sensors/tilt/ingest" \
  -H 'Content-Type: application/json' \
  -d "{\"color\":\"$COLOR\",\"temp_f\":67.0,\"sg\":1.044}" | jq . >/dev/null && pass "COOL ingest OK"

info "Poke (expect OFF)"
POKE_OFF=$(curl -fsS -X POST "$BASE/automations/poke")
echo "$POKE_OFF" | jq . >/dev/null || fail "poke returned non-JSON"
echo "$POKE_OFF" | grep -q '"action": *"OFF"' && pass "rule decided OFF" || fail "expected OFF action"

info "Automations UI reachable"
code=$(curl -s -o /dev/null -w "%{http_code}" "$BASE/automations/ui")
[ "$code" = "200" ] && pass "/automations/ui 200" || fail "/automations/ui $code"

info "Enable/Disable toggle (rule id=1 best effort)"
curl -fsS -X POST "$BASE/automations/rules/1/disable" | jq . >/dev/null && pass "disable OK" || pass "disable skipped"
curl -fsS -X POST "$BASE/automations/rules/1/enable"  | jq . >/dev/null && pass "enable OK"  || pass "enable skipped"

info "Addon: ferment-tracker"
code=$(curl -s -o /dev/null -w "%{http_code}" "$BASE/addons/ferment-tracker")
[ "$code" = "200" ] && pass "addon 200" || fail "addon $code"

info "DB backup (non-empty)"
curl -fsS "$BASE/admin/db/backup" -o "$DATA_DIR/bevforge-backup-test.db"
[ -s "$DATA_DIR/bevforge-backup-test.db" ] && pass "backup OK" || fail "backup empty"

echo
pass "ALL CHECKS PASSED"
